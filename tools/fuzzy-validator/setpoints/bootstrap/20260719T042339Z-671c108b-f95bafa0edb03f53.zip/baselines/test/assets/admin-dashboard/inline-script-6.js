
var wnVersion = "2026-07-15";
var wnUir = 'http://127.0.0.1:19080/orkui/index.php?Route=';
function wnDismiss() {
  document.getElementById('wn-overlay').classList.remove('wn-open');
  $.post(wnUir + 'WnAjax/dismiss', { version: wnVersion });
}
document.getElementById('wn-overlay').addEventListener('click', function(e) {
  if (e.target === this) wnDismiss();
});
