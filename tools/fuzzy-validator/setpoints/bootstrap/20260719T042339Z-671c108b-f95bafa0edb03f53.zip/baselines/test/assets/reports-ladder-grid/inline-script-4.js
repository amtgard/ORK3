
(function () {
	var showInactive   = false;
	var statFilter     = null; // null | 'knights' | 'masters'
	var rankMin = 1, rankMax = 10;
	var selectedAwards = new Set(); // empty = all awards
	var table;

	// Custom filters — run on every DataTables draw
	$.fn.dataTable.ext.search.push(function (settings, data, dataIndex) {
		if (!table || settings.nTable.id !== 'lg-grid-table') return true;
		var row = table.row(dataIndex).node();
		if (!row) return true;
		if (!showInactive && row.getAttribute('data-recent') !== '1') return false;
		if (statFilter === 'knights' && row.getAttribute('data-is-knight') !== '1') return false;
		if (statFilter === 'masters' && row.getAttribute('data-is-master') !== '1') return false;
		if (selectedAwards.size > 0) {
			// AND: player must have rank > 0 in every selected award.
			// Rank slider then applies to the highest rank across those awards.
			var awardData = JSON.parse(row.getAttribute('data-awards') || '{}');
			var effectiveMax = rankMax === 10 ? 999 : rankMax;
			var mr = 0;
			var allPresent = true;
			selectedAwards.forEach(function (aid) {
				var r = awardData[aid] || 0;
				if (r === 0) allPresent = false;
				if (r > mr) mr = r;
			});
			if (!allPresent) return false;                       // missing at least one selected award
			if (mr < rankMin || mr > effectiveMax) return false; // outside rank range
		} else if (rankMin > 1 || rankMax < 10) {
			var effectiveMax = rankMax === 10 ? 999 : rankMax;
			var mr = parseInt(row.getAttribute('data-max-rank')) || 0;
			if (mr < rankMin || mr > effectiveMax) return false;
		}
		return true;
	});

	$(function () {
		var isKingdom = true;
		var colDefs = [
			{ targets: '_all', type: 'num',    orderSequence: ['desc', 'asc'] },
			{ targets: 0,      type: 'string', orderSequence: ['asc', 'desc'] }
		];
		if (isKingdom) {
			colDefs.push({ targets: 1, type: 'string', orderSequence: ['asc', 'desc'] });
		}
		table = $('#lg-grid-table').DataTable({
			dom       : 'rt',
			paging    : false,
			info      : false,
			columnDefs: colDefs
		});

		// Apply sort and inactive filter on load
		table.order(isKingdom ? [[1, 'asc'], [0, 'asc']] : [[0, 'asc']]).draw();

		// Player name search
		$('#lg-search').on('input', function () {
			table.search(this.value).draw();
		});

		// Inactive toggle
		$('#lg-btn-inactive').on('click', function () {
			showInactive = !showInactive;
			$(this)
				.toggleClass('lg-pill-active', showInactive)
				.html(showInactive
					? '<i class="fas fa-eye-slash"></i> Showing All'
					: '<i class="fas fa-eye"></i> Include Inactive');
			$('#lg-grid-table').toggleClass('lg-showing-inactive', showInactive);
			table.draw();
		});

		// Dual rank-range slider
		function updateRangeUI() {
			var lo = parseInt($('#lg-range-lo').val());
			var hi = parseInt($('#lg-range-hi').val());
			var pctLo = (lo - 1) / 9 * 100;
			var pctHi = (hi - 1) / 9 * 100;
			$('#lg-range-fill').css({ left: pctLo + '%', right: (100 - pctHi) + '%' });
			$('#lg-range-lo-val').text(lo);
			$('#lg-range-hi-val').text(hi === 10 ? '10+' : hi);
			rankMin = lo;
			rankMax = hi;
			// When lo has reached hi, raise lo's z-index so the user can drag it back left
			$('#lg-range-lo').css('z-index', lo >= hi ? 5 : 3);
			$('#lg-range-hi').css('z-index', lo >= hi ? 4 : 5);
		}
		updateRangeUI();

		$('#lg-range-lo').on('input', function () {
			if (parseInt($(this).val()) > parseInt($('#lg-range-hi').val()))
				$(this).val($('#lg-range-hi').val());
			updateRangeUI();
			table.draw();
		});
		$('#lg-range-hi').on('input', function () {
			if (parseInt($(this).val()) < parseInt($('#lg-range-lo').val()))
				$(this).val($('#lg-range-lo').val());
			updateRangeUI();
			table.draw();
		});

		// Knights / Masters stat card filters
		$('#lg-filter-knights, #lg-filter-masters').on('click', function () {
			var key = this.id === 'lg-filter-knights' ? 'knights' : 'masters';
			statFilter = (statFilter === key) ? null : key;
			$('#lg-filter-knights').toggleClass('lg-stat-active', statFilter === 'knights');
			$('#lg-filter-masters').toggleClass('lg-stat-active', statFilter === 'masters');
			table.draw();
		});

		// Award filter pills
		$('#lg-award-pills').on('click', '.lg-award-pill', function () {
			var aid = String($(this).data('award-id'));
			if (selectedAwards.has(aid)) {
				selectedAwards.delete(aid);
				$(this).removeClass('lg-award-pill-active');
			} else {
				selectedAwards.add(aid);
				$(this).addClass('lg-award-pill-active');
			}
			$('#lg-award-clear').toggle(selectedAwards.size > 0);
			table.draw();
		});
		$('#lg-award-clear').on('click', function () {
			selectedAwards.clear();
			$('#lg-award-pills .lg-award-pill').removeClass('lg-award-pill-active');
			$(this).hide();
			table.draw();
		});

		$('#lg-btn-print').on('click', function () { window.print(); });

		$('#lg-btn-csv').on('click', function () {
			var scopeLabel = "";
			var slug = scopeLabel.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
			var d = new Date();
			var dateStr = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
			var filename = (slug || 'ladder') + '-ladder-grid-' + dateStr + '.csv';

			// Headers injected from PHP — avoids any DataTables DOM manipulation confusion
			var headers = ["Persona","Park","Mundane ID"];
			var mundaneIdInsertPos = 2;

			// Build rows — all rows regardless of active/search filter
			var lines = [headers.map(csvCell).join(',')];
			table.rows().nodes().each(function (tr) {
				var cols = [];
				$(tr).find('td').each(function () {
					var text = $(this).text().trim().replace(/·/g, '');
					cols.push(csvCell(text));
				});
				cols.splice(mundaneIdInsertPos, 0, csvCell($(tr).data('mundane-id') || ''));
				lines.push(cols.join(','));
			});

			var blob = new Blob([lines.join('\n')], { type: 'text/csv' });
			var a = document.createElement('a');
			a.href = URL.createObjectURL(blob);
			a.download = filename;
			a.click();
		});
	});

	function csvCell(v) {
		return '"' + String(v).replace(/"/g, '""') + '"';
	}
})();
