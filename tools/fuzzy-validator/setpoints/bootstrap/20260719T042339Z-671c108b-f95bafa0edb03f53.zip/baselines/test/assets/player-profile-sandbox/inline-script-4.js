
window.OrkRsCfg = {
	uir:         'http://127.0.0.1:19080/orkui/index.php?Route=',
	userId:      4,
	userPersona: "",
	reload:      function() { if (typeof window.pnReloadRecs === 'function') window.pnReloadRecs(); else location.reload(); }
};
