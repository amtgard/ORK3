
(function() {
    var btn = document.querySelector('.pna-tenure-info-btn');
    if (!btn) return;
    var tip = btn.querySelector('.pna-tenure-info-text');
    if (!tip) return;
    function show() {
        var r = btn.getBoundingClientRect();
        tip.style.display = 'block';
        var left = r.left + r.width / 2 - 130;
        if (left < 8) left = 8;
        if (left + 260 > window.innerWidth - 8) left = window.innerWidth - 268;
        var top = r.top - tip.offsetHeight - 8;
        if (top < 8) top = r.bottom + 8;
        tip.style.left = left + 'px';
        tip.style.top  = top + 'px';
    }
    function hide() { tip.style.display = 'none'; }
    btn.addEventListener('mouseenter', show);
    btn.addEventListener('focus',      show);
    btn.addEventListener('mouseleave', hide);
    btn.addEventListener('blur',       hide);
})();

var PnConfig = {
	uir:            'http://127.0.0.1:19080/orkui/index.php?Route=',
	httpService:    'http://127.0.0.1:19080/orkservice/',
	playerId:       1,
	parkId:         0,
	parkName:       "Highspire",
	kingdomId:      100004,
	recError:       false,
	canEditImages:  false,
	canEditAccount: false,
	canEditAdmin:   false,
	canManageAwards:false,
	classList:      [{"ClassId":1,"ClassName":"Anti-Paladin","Credits":0,"Reconciled":0},{"ClassId":2,"ClassName":"Archer","Credits":0,"Reconciled":0},{"ClassId":3,"ClassName":"Assassin","Credits":0,"Reconciled":0},{"ClassId":4,"ClassName":"Barbarian","Credits":0,"Reconciled":0},{"ClassId":5,"ClassName":"Bard","Credits":0,"Reconciled":0},{"ClassId":6,"ClassName":"Color","Credits":0,"Reconciled":0},{"ClassId":7,"ClassName":"Druid","Credits":0,"Reconciled":0},{"ClassId":8,"ClassName":"Healer","Credits":0,"Reconciled":0},{"ClassId":9,"ClassName":"Monk","Credits":0,"Reconciled":0},{"ClassId":10,"ClassName":"Monster","Credits":0,"Reconciled":0},{"ClassId":11,"ClassName":"Paladin","Credits":0,"Reconciled":0},{"ClassId":12,"ClassName":"Peasant","Credits":0,"Reconciled":0},{"ClassId":14,"ClassName":"Reeve","Credits":0,"Reconciled":0},{"ClassId":15,"ClassName":"Scout","Credits":0,"Reconciled":0},{"ClassId":16,"ClassName":"Warrior","Credits":0,"Reconciled":0},{"ClassId":17,"ClassName":"Wizard","Credits":0,"Reconciled":0}],
	awardRanks:     [],
	heldAwardIds:        [],
	heldKingdomAwardIds: [],
	ladderMasterMap:     {"21":{"MasterAwardIds":[1],"LadderName":"Order of the Rose","MasterName":"Master Rose","MaxRank":10},"22":{"MasterAwardIds":[2],"LadderName":"Order of the Smith","MasterName":"Master Smith","MaxRank":10},"23":{"MasterAwardIds":[3],"LadderName":"Order of the Lion","MasterName":"Master Lion","MaxRank":10},"24":{"MasterAwardIds":[4],"LadderName":"Order of the Owl","MasterName":"Master Owl","MaxRank":10},"25":{"MasterAwardIds":[5],"LadderName":"Order of the Dragon","MasterName":"Master Dragon","MaxRank":10},"26":{"MasterAwardIds":[6],"LadderName":"Order of the Garber","MasterName":"Master Garber","MaxRank":10},"27":{"MasterAwardIds":[12],"LadderName":"Order of the Warrior","MasterName":"Warlord","MaxRank":10},"28":{"MasterAwardIds":[7],"LadderName":"Order of the Jovius","MasterName":"Master Jovius","MaxRank":10},"29":{"MasterAwardIds":[9],"LadderName":"Order of the Mask","MasterName":"Master Mask","MaxRank":10},"30":{"MasterAwardIds":[8],"LadderName":"Order of the Zodiac","MasterName":"Master Zodiac","MaxRank":12},"32":{"MasterAwardIds":[10],"LadderName":"Order of the Hydra","MasterName":"Master Hydra","MaxRank":10},"33":{"MasterAwardIds":[11],"LadderName":"Order of the Griffin","MasterName":"Master Griffin","MaxRank":10},"239":{"MasterAwardIds":[240],"LadderName":"Order of the Crown","MasterName":"Master Crown","MaxRank":10},"243":{"MasterAwardIds":[244],"LadderName":"Order of Battle","MasterName":"Battlemaster","MaxRank":10}},
	playerName:          "admin",
	awardOptHTML:   "<option value=\"\">Select award...<\/option><optgroup label='Ladder Awards'><option value='607' data-is-ladder='1' data-award-id='243'>Order of Battle<\/option><option value='603' data-is-ladder='1' data-award-id='239'>Order of the Crown<\/option><option value='485' data-is-ladder='1' data-award-id='25'>Order of the Dragon<\/option><option value='494' data-is-ladder='1' data-award-id='34'>Order of the Flame<\/option><option value='486' data-is-ladder='1' data-award-id='26'>Order of the Garber<\/option><option value='493' data-is-ladder='1' data-award-id='33'>Order of the Griffin<\/option><option value='492' data-is-ladder='1' data-award-id='32'>Order of the Hydra<\/option><option value='488' data-is-ladder='1' data-award-id='28'>Order of the Jovius<\/option><option value='483' data-is-ladder='1' data-award-id='23'>Order of the Lion<\/option><option value='489' data-is-ladder='1' data-award-id='29'>Order of the Mask<\/option><option value='484' data-is-ladder='1' data-award-id='24'>Order of the Owl<\/option><option value='481' data-is-ladder='1' data-award-id='21'>Order of the Rose<\/option><option value='482' data-is-ladder='1' data-award-id='22'>Order of the Smith<\/option><option value='491' data-is-ladder='1' data-award-id='31'>Order of the Walker in the Middle<\/option><option value='487' data-is-ladder='1' data-award-id='27'>Order of the Warrior<\/option><option value='490' data-is-ladder='1' data-award-id='30'>Order of the Zodiac<\/option><\/optgroup><option value='554' data-custom-award='1' data-award-id='94'>Custom Award<\/option><option value='610' data-custom-title='1' data-award-id='246'>Custom Title<\/option><optgroup label='Knighthoods'><option value='609'>Knight of Battle<\/option><option value='478'>Knight of the Crown<\/option><option value='477'>Knight of the Flame<\/option><option value='479'>Knight of the Serpent<\/option><option value='480'>Knight of the Sword<\/option><\/optgroup><optgroup label='Masterhoods'><option value='608' data-award-id='244' data-peerage='Master'>Battlemaster<\/option><option value='612' data-award-id='2' data-peerage='Master'>Golden Quill<\/option><option value='604' data-award-id='240' data-peerage='Master'>Master Crown<\/option><option value='465' data-award-id='5' data-peerage='Master'>Master Dragon<\/option><option value='466' data-award-id='6' data-peerage='Master'>Master Garber<\/option><option value='471' data-award-id='11' data-peerage='Master'>Master Griffin<\/option><option value='470' data-award-id='10' data-peerage='Master'>Master Hydra<\/option><option value='467' data-award-id='7' data-peerage='Master'>Master Jovius<\/option><option value='463' data-award-id='3' data-peerage='Master'>Master Lion<\/option><option value='469' data-award-id='9' data-peerage='Master'>Master Mask<\/option><option value='464' data-award-id='4' data-peerage='Master'>Master Owl<\/option><option value='461' data-award-id='1' data-peerage='Master'>Master Rose<\/option><option value='462' data-award-id='2' data-peerage='Master'>Master Smith<\/option><option value='468' data-award-id='8' data-peerage='Master'>Master Zodiac<\/option><option value='613' data-award-id='3' data-peerage='Master'>Obsidian Ring<\/option><option value='611' data-award-id='1' data-peerage='Master'>Silver Oak<\/option><option value='472' data-award-id='12' data-peerage='Master'>Warlord<\/option><\/optgroup><optgroup label='Paragons'><option value='497'>Paragon Anti-Paladin<\/option><option value='498'>Paragon Archer<\/option><option value='499'>Paragon Assassin<\/option><option value='500'>Paragon Barbarian<\/option><option value='501'>Paragon Bard<\/option><option value='605'>Paragon Color<\/option><option value='502'>Paragon Druid<\/option><option value='503'>Paragon Healer<\/option><option value='504'>Paragon Monk<\/option><option value='505'>Paragon Monster<\/option><option value='506'>Paragon Paladin<\/option><option value='507'>Paragon Peasant<\/option><option value='508'>Paragon Raider<\/option><option value='606'>Paragon Reeve<\/option><option value='509'>Paragon Scout<\/option><option value='510'>Paragon Warrior<\/option><option value='511'>Paragon Wizard<\/option><\/optgroup><optgroup label='Noble Titles'><option value='527'>Archduchess<\/option><option value='526'>Archduke<\/option><option value='516'>Baron<\/option><option value='517'>Baroness<\/option><option value='514'>Baronet<\/option><option value='515'>Baronetess<\/option><option value='520'>Count<\/option><option value='521'>Countess<\/option><option value='495'>Defender<\/option><option value='525'>Duchess<\/option><option value='524'>Duke<\/option><option value='576'>Esquire<\/option><option value='529'>Grand Duchess<\/option><option value='528'>Grand Duke<\/option><option value='513'>Lady<\/option><option value='512'>Lord<\/option><option value='523'>Marquess<\/option><option value='522'>Marquis<\/option><option value='593'>Master<\/option><option value='518'>Viscount<\/option><option value='519'>Viscountess<\/option><\/optgroup><optgroup label='Associate Titles'><option value='570'>Apprentice<\/option><option value='473'>Lord&#039;s Page<\/option><option value='474'>Man-at-Arms<\/option><option value='475'>Page<\/option><option value='476'>Squire<\/option><\/optgroup><optgroup label='Other'><option value='585'>Autocrat, Interkingdom<\/option><option value='589'>Autocrat, Interpark<\/option><option value='583'>Autocrat, Kingdom<\/option><option value='587'>Autocrat, Park<\/option><option value='571'>COM Executive Committee<\/option><option value='575'>Cultural Olympian<\/option><option value='574'>Dragonmaster<\/option><option value='591'>Grand Olympian<\/option><option value='586'>Subcrat, Interkingdom<\/option><option value='590'>Subcrat, Interpark<\/option><option value='584'>Subcrat, Kingdom<\/option><option value='588'>Subcrat, Park<\/option><option value='596'>War Event Winner<\/option><option value='597'>War Olympian<\/option><option value='598'>Warmaster<\/option><option value='496'>Weaponmaster<\/option><\/optgroup>",
	officerOptHTML: "<option value=\"\">Select title...<\/option><optgroup label='Other'><option value='546'>Baronial Champion<\/option><option value='538'>Baronial Regent<\/option><option value='542'>Baronial Seneschal<\/option><option value='572'>Champion, Principality<\/option><option value='573'>Champion, Shire<\/option><option value='553'>Director of the Board<\/option><option value='543'>Ducal Chancellor<\/option><option value='547'>Ducal Defender<\/option><option value='539'>Ducal Regent<\/option><option value='548'>Grand Ducal Defender<\/option><option value='544'>Grand Ducal General Minister<\/option><option value='540'>Grand Ducal Regent<\/option><option value='577'>Guildmaster of Anti-Paladins<\/option><option value='556'>Guildmaster of Archers<\/option><option value='557'>Guildmaster of Assassins<\/option><option value='558'>Guildmaster of Barbarians<\/option><option value='559'>Guildmaster of Bards<\/option><option value='560'>Guildmaster of Druids<\/option><option value='561'>Guildmaster of Healers<\/option><option value='555'>Guildmaster of Knights<\/option><option value='562'>Guildmaster of Monks<\/option><option value='563'>Guildmaster of Monsters<\/option><option value='564'>Guildmaster of Paladins<\/option><option value='569'>Guildmaster of Reeves<\/option><option value='579'>Guildmaster of Reeves, Barony<\/option><option value='580'>Guildmaster of Reeves, Duchy<\/option><option value='581'>Guildmaster of Reeves, Grand Duchy<\/option><option value='582'>Guildmaster of Reeves, Principality<\/option><option value='578'>Guildmaster of Reeves, Shire<\/option><option value='566'>Guildmaster of Scouts<\/option><option value='567'>Guildmaster of Warriors<\/option><option value='568'>Guildmaster of Wizards<\/option><option value='549'>Kingdom Champion<\/option><option value='552'>Kingdom Monarch<\/option><option value='551'>Kingdom Prime Minister<\/option><option value='550'>Kingdom Regent<\/option><option value='594'>Monarch, Principality<\/option><option value='565'>Plagueservant of Peasants<\/option><option value='601'>Principality Champion<\/option><option value='599'>Principality Monarch<\/option><option value='602'>Principality Prime Minister<\/option><option value='600'>Principality Regent<\/option><option value='531'>Provincial Baron<\/option><option value='532'>Provincial Baroness<\/option><option value='545'>Provincial Champion<\/option><option value='534'>Provincial Duchess<\/option><option value='533'>Provincial Duke<\/option><option value='536'>Provincial Grand Duchess<\/option><option value='535'>Provincial Grand Duke<\/option><option value='595'>Regent, Principality<\/option><option value='592'>Rules Representative<\/option><option value='530'>Sheriff<\/option><option value='541'>Shire Clerk<\/option><option value='537'>Shire Regent<\/option><\/optgroup>",
	preloadOfficers:[{"MundaneId":100000181,"Persona":"Finn Greycloak","Role":"Kingdom Monarch"},{"MundaneId":100000182,"Persona":"Gwen Ash","Role":"Kingdom Regent"}],
	playerParkName:   "Highspire",
	playerPersona:    "admin",
	duesPeriodType:   "month",
	duesPeriod:       6,
	canCreateUnit:    false,
	lastClassId:      0,
	attendanceDates:  [],  // populated async by PlayerAjax/attendance
	canEditAnyAttendance: false,
	customAwardId:      94,
	customTitleAwardId: 246,
	isOwnProfile:     false,
	canEditDesign:    false,
	kingdomUrl:       "http:\/\/127.0.0.1:19080\/orkui\/index.php?Route=Kingdom\/profile\/100004",
	classToParagon:   {"1":37,"2":38,"3":39,"4":40,"5":41,"6":241,"7":42,"8":43,"9":44,"10":45,"11":46,"12":47,"14":242,"15":49,"16":50,"17":51},
	heldAwardIds:     [],
	canDeleteRec:   false,
	showRecsTab:    true,
	loggedInUserId: 4,
	aboutPersona:   "",
	aboutStory:     "",
	colorPrimary:   "",
	colorAccent:    "",
	namePrefix:     "",
	nameSuffix:     "",
	photoFocusX:    50,
	photoFocusY:    50,
	photoFocusSize: 100,
	hasImage:       false,
	imageUrl:       "http:\/\/127.0.0.1:19080\/assets\/heraldry\/player\/000000.jpg",
	playerTitles:   [],
	milestoneConfig: {},
	customMilestones: [],
	nameFont:        "",
	viewerBasicFonts: false,
	viewerDyslexiaFonts: false,
};
// Use the viewed player's kingdom for nav search prioritization if the user has no home kingdom
if (typeof nsKid !== 'undefined' && nsKid === 0 && PnConfig.kingdomId) nsKid = PnConfig.kingdomId;
