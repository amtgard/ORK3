
(function() {
	'use strict';
	$(function() {
		var startCol = 2;
		var dt = $('#ea-table').DataTable({
			order: [[startCol, 'desc']],
			orderClasses: false,
			pageLength: 25,
			dom: 'lfrtip',
			scrollX: true,
			buttons: [
				{ extend: 'csv',   text: 'Export CSV' },
				{ extend: 'print', text: 'Print' }
			],
			language: { search: 'Filter:' },
			initComplete: function() {
				$('#ea-table-loading').hide();
				$('#ea-table-wrap').css('opacity', '1');
			}
		});
				dt.search("Spring War").draw();
		$('#ea-table_filter input').val("Spring War");
				function syncStatsMuted() {
			var active = $('#ea-table_filter input').val() !== '';
			$('#ea-stats-row').toggleClass('ea-stats-muted', active);
			$('#ea-stats-notice').toggleClass('ea-visible', active);
		}
		syncStatsMuted();
		dt.on('search.dt', syncStatsMuted);
		$('.rp-btn-export').on('click', function() { dt.button('.buttons-csv').trigger(); });
		$('.rp-btn-print').on('click', function() { dt.button('.buttons-print').trigger(); });
	});
})();
