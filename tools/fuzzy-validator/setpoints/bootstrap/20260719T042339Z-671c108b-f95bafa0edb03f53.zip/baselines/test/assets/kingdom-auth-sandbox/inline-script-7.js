
window.knRecActiveFilter = 'open';
$.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
	if (settings.nTable.id !== 'kn-rec-table') return true;
	var filter = window.knRecActiveFilter || 'all';
	if (filter === 'all') return true;
	var row = settings.aoData[dataIndex].nTr;
	var rowFilter = row ? row.getAttribute('data-filter') : '';
	if (filter === 'open') return rowFilter !== 'already';
	if (filter === 'mycircles') {
		if (rowFilter === 'already') return false;
		var aid = parseInt(row.getAttribute('data-award-id') || '0', 10);
		return (window.knRecCircleAwardIds || []).indexOf(aid) !== -1;
	}
	return rowFilter === filter;
});
// Initialise the rec-table DataTable + filter bar. Idempotent so the lazy-loader
// can call it again after injecting the rec-tab HTML on first tab activation.
window.knInitRecsTab = function() {
	var $tbl = $('#kn-rec-table');
	if (!$tbl.length) return;
	window.knRecCircleAwardIds = (function() { try { return JSON.parse($tbl.attr('data-circle-ids') || '[]'); } catch (e) { return []; } })();
	if ($.fn.dataTable.isDataTable('#kn-rec-table')) {
		$tbl.DataTable().destroy();
	}
	window.knRecDT = $tbl.DataTable({
		// Columns: 0 Player · 1 Park · 2 Award · 3 Rank · 4 Rec By · 5 Date · 6 Notes · (-1 actions)
		order: [[5, 'desc']],
		columnDefs: [
			{ targets: [5], type: 'date' },
					],
		dom: "<'ork-dt-top'lf>rt<'ork-dt-bot'ip>",
		lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'All']],
		language: { searchPlaceholder: 'Search…', search: '', lengthMenu: 'Show _MENU_' },
		pageLength: 25,
		scrollX: true
	});
	// Filter bar: re-bind in case the HTML is freshly injected.
	var bar = document.querySelector('#kn-tab-recommendations .kn-rec-filter-bar');
	if (bar && !bar.__knFilterBound) {
		bar.__knFilterBound = true;
		bar.addEventListener('click', function(e) {
			var btn = e.target.closest('.kn-rec-filter-btn');
			if (!btn) return;
			var filter = btn.dataset.filter;
			bar.querySelectorAll('.kn-rec-filter-btn').forEach(function(b) {
				b.classList.toggle('kn-rec-filter-active', b.dataset.filter === filter);
			});
			window.knRecActiveFilter = filter;
			if (window.knRecDT) window.knRecDT.draw();
		});
	}
};
$(function() { window.knInitRecsTab(); });
window.knRecPrint = function() { if (window.knRecDT) window.recsExportPrint(window.knRecDT, 'Award Recommendations \u2014 Empire of Ashkara'); };
window.knRecCsv   = function() { if (window.knRecDT) window.recsExportCsv(window.knRecDT, 'recs-Empire-of-Ashkara.csv'); };
initEmailSpellCheck('kn-addplayer-email', 'kn-addplayer-email-suggestion');
window.knUsernameCheck = initUsernameAvailabilityCheck({
	inputId:     'kn-addplayer-username',
	statusId:    'kn-addplayer-username-status',
	submitBtnId: 'kn-addplayer-submit',
	endpointUrl: 'http://127.0.0.1:19080/orkui/index.php?Route=PlayerAjax/check_username',
	gateMode:    'soft'
});
(function() {
	var _origOpen = window.knOpenAddPlayerModal;
	if (typeof _origOpen !== 'function') return;
	window.knOpenAddPlayerModal = function() {
		var r = _origOpen.apply(this, arguments);
		if (window.knUsernameCheck && window.knUsernameCheck.reset) window.knUsernameCheck.reset();
		return r;
	};
})();
