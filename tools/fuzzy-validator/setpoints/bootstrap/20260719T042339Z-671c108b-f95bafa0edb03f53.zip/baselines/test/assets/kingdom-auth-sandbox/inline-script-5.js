
(function() {
	var kingdomId = 100001;
	if (!kingdomId) return;

	function knCopyEventLink(el) {
		var url = el.getAttribute('data-url');
		navigator.clipboard.writeText(url).then(function() {
			el.classList.add('kn-copied');
			setTimeout(function() { el.classList.remove('kn-copied'); }, 1500);
		});
	}

	// ---- Park averages + player counts (AJAX) ----
	// Fill tile/row averages for a given park_averages_json payload.
	// opts = { scope: Element|null (default document),
	//          footer: {avgwk, avgmo, tp, tm} element-ids | null,
	//          statCards: bool }
	function knFillAverages(data, opts) {
		opts = opts || {};
		var scope = opts.scope || document;
		var totalAtt = 0, totalTp = 0, totalTm = 0;
		var wkCount = (data._kingdom && data._kingdom.wk_count) ? data._kingdom.wk_count : 26;
		var kingdomAtt = (data._kingdom && data._kingdom.att) ? data._kingdom.att : null;
		function knTrend(cur, prev, decimals) {
			if (prev === undefined) return '';
			if (cur > prev) return ' <span class="kn-trend kn-trend-up" title="Up from ' + prev.toFixed(decimals) + ' (prev period)">&#9650;</span>';
			if (cur < prev) return ' <span class="kn-trend kn-trend-dn" title="Down from ' + prev.toFixed(decimals) + ' (prev period)">&#9660;</span>';
			return '';
		}
		for (var parkId in data) {
			if (parkId === '_kingdom') continue;
			var att = data[parkId].att || 0, mo = data[parkId].mo || 0;
			var tp  = data[parkId].tp  || 0, tm = data[parkId].tm  || 0;
			var prevAtt = data[parkId].prev_att, prevMo = data[parkId].prev_mo;
			totalAtt += att; totalTp += tp; totalTm += tm;
			// Tile view
			var tile = scope.querySelector('.kn-park-tile[data-park-id="' + parkId + '"]');
			if (tile) {
				var wkEl = tile.querySelector('.kn-avgwk-tile');
				var moEl = tile.querySelector('.kn-avgmo-tile');
				if (wkEl) wkEl.innerHTML = (att / wkCount).toFixed(1) + knTrend(att / wkCount, prevAtt !== undefined ? prevAtt / wkCount : undefined, 1);
				if (moEl) moEl.innerHTML = mo.toFixed(1) + knTrend(mo, prevMo !== undefined ? prevMo : undefined, 1);
			}
			// List view row
			var row = scope.querySelector('tr[data-park-id="' + parkId + '"]');
			if (row) {
				var wkTd = row.querySelector('.kn-avgwk-row');
				var moTd = row.querySelector('.kn-avgmo-row');
				var tpTd = row.querySelector('.kn-tp-row');
				var tmTd = row.querySelector('.kn-tm-row');
				if (wkTd) { wkTd.innerHTML = (att / wkCount).toFixed(2) + knTrend(att / wkCount, prevAtt !== undefined ? prevAtt / wkCount : undefined, 2); wkTd.setAttribute('data-sortval', att / wkCount); }
				if (moTd) { moTd.innerHTML = mo.toFixed(1) + knTrend(mo, prevMo !== undefined ? prevMo : undefined, 1); moTd.setAttribute('data-sortval', mo); }
				if (tpTd) { tpTd.textContent = tp;  tpTd.setAttribute('data-sortval', tp); }
				if (tmTd) { tmTd.textContent = tm;  tmTd.setAttribute('data-sortval', tm); }
			}
		}
		// Stat cards — use kingdom-level deduped values (avoids double-counting multi-park players)
		var wkBase = kingdomAtt !== null ? kingdomAtt : totalAtt;
		var moBase = (data._kingdom && data._kingdom.mo) ? data._kingdom.mo : 0;
		if (opts.statCards) {
			var statWk = document.getElementById('kn-stat-avgwk');
			var statMo = document.getElementById('kn-stat-avgmo');
			if (statWk) statWk.textContent = (wkBase / wkCount).toFixed(1);
			if (statMo) statMo.textContent = moBase.toFixed(1);
		}
		// Footer totals
		if (opts.footer) {
			var footWk = document.getElementById(opts.footer.avgwk);
			var footMo = document.getElementById(opts.footer.avgmo);
			var footTp = document.getElementById(opts.footer.tp);
			var footTm = document.getElementById(opts.footer.tm);
			if (footWk) footWk.textContent = (wkBase / wkCount).toFixed(2);
			if (footMo) footMo.textContent = moBase.toFixed(1);
			if (footTp) footTp.textContent = totalTp;
			if (footTm) footTm.textContent = totalTm;
		}
	}

	// Kingdom's own parks (stat cards + kingdom footer)
	fetch('http://127.0.0.1:19080/orkui/index.php?Route=Kingdom/park_averages_json/' + kingdomId)
		.then(function(r) { return r.json(); })
		.then(function(data) {
			knFillAverages(data, {
				scope: document,
				footer: { avgwk: 'kn-total-avgwk', avgmo: 'kn-total-avgmo', tp: 'kn-total-tp', tm: 'kn-total-tm' },
				statCards: true
			});
		})
		.catch(function(err) { console.error('Kingdom park_averages_json failed:', err); });

	// Principality parks — one fetch per principality id; park ids are globally unique so
	// document-scoped fills land on the right tiles/rows, and per-section footer ids keep totals separate.
	var knPrinzIds = (KnConfig.principalityIds || []);
	knPrinzIds.forEach(function(prId) {
		fetch('http://127.0.0.1:19080/orkui/index.php?Route=Kingdom/park_averages_json/' + prId)
			.then(function(r) { return r.json(); })
			.then(function(data) {
				knFillAverages(data, {
					scope: document,
					footer: { avgwk: 'kn-prinz-' + prId + '-avgwk', avgmo: 'kn-prinz-' + prId + '-avgmo', tp: 'kn-prinz-' + prId + '-tp', tm: 'kn-prinz-' + prId + '-tm' },
					statCards: false
				});
			})
			.catch(function(err) { console.error('Principality park_averages_json failed (' + prId + '):', err); });
	});

	// ---- Players tab: lazy-load on first click ----
	function knHtmlEsc(s) {
		return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
	}
	function knFmtDate(s, long) {
		if (!s || s === '1970-01-01') return '—';
		var d = new Date(s + 'T00:00:00');
		return long
			? d.toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'})
			: d.toLocaleDateString('en-US', {month:'short', day:'numeric'});
	}
	function knPlayerCardHtml(p, uir) {
		var initial = (p.persona || '?').charAt(0).toUpperCase();
		var avatarHtml = p.avatarUrl
			? '<img src="' + knHtmlEsc(p.avatarUrl) + '" loading="lazy" alt="" onerror="knAvatarFallback(this,\'' + initial + '\')">'
			: initial;
		var hbgAttr  = p.heraldryUrl ? ' style="--hbg:url(\'' + knHtmlEsc(p.heraldryUrl) + '\')"' : '';
		var hbgClass = p.heraldryUrl ? ' kn-player-card-hbg' : '';
		var pills = (p.officerRoles || '').split(', ').filter(Boolean).map(function(r) {
			return '<span class="kn-officer-pill">' + knHtmlEsc(r.trim()) + '</span>';
		}).join('');
		var classSpan = p.lastClass ? '<span><i class="fas fa-shield-alt" style="color:#b794f4;width:14px"></i> ' + knHtmlEsc(p.lastClass) + '</span>' : '';
		var mnAttr = p.mundaneName ? ' data-mundane-name="' + knHtmlEsc(p.mundaneName.toLowerCase()) + '"' : '';
		return '<a class="kn-player-card' + hbgClass + '"' + hbgAttr + mnAttr + ' data-signin-count="' + p.signinCount + '" href="' + uir + 'Player/profile/' + p.id + '">'
			+ '<div class="kn-player-card-top"><div class="kn-player-avatar">' + avatarHtml + '</div>'
			+ '<div><div class="kn-player-name">' + knHtmlEsc(p.persona) + '</div>' + pills + '</div></div>'
			+ '<div class="kn-player-stats">'
			+ '<span><i class="fas fa-map-marker-alt" style="color:#68d391;width:14px"></i> ' + knHtmlEsc(p.parkName) + '</span>'
			+ '<span><i class="fas fa-check-circle" style="color:#68d391;width:14px"></i> ' + p.signinCount + ' six month sign-in' + (p.signinCount !== 1 ? 's' : '') + '</span>'
			+ '<span><i class="fas fa-calendar-check" style="color:#63b3ed;width:14px"></i> ' + knFmtDate(p.lastSignin) + '</span>'
			+ classSpan + '</div></a>';
	}
	function knPlayerRowHtml(p, uir) {
		var pills = (p.officerRoles || '').split(', ').filter(Boolean).map(function(r) {
			return '<span class="kn-officer-pill">' + knHtmlEsc(r.trim()) + '</span>';
		}).join('');
		var mnAttr = p.mundaneName ? ' data-mundane-name="' + knHtmlEsc(p.mundaneName.toLowerCase()) + '"' : '';
		return '<tr' + mnAttr + ' data-signin-count="' + p.signinCount + '" onclick=\'window.location.href="' + uir + 'Player/profile/' + p.id + '"\'>'
			+ '<td>' + knHtmlEsc(p.persona) + pills + '</td>'
			+ '<td>' + knHtmlEsc(p.parkName || '') + '</td>'
			+ '<td data-sortval="' + p.signinCount + '">' + p.signinCount + '</td>'
			+ '<td class="kn-date-col" data-sortval="' + knHtmlEsc(p.lastSignin) + '">' + knFmtDate(p.lastSignin, true) + '</td>'
			+ '<td>' + knHtmlEsc(p.lastClass || '') + '</td>'
			+ '<td>' + knHtmlEsc(p.officerRoles || '') + '</td>'
			+ '</tr>';
	}

	var knPlayersLoaded = false;
	function knLoadPlayers() {
		if (knPlayersLoaded) return;
		var uir = 'http://127.0.0.1:19080/orkui/index.php?Route=';
		fetch(uir + 'Kingdom/players_json/' + kingdomId)
			.then(function(r) { return r.json(); })
			.then(function(data) {
				knPlayersLoaded = true;
				var players = data.players || [];
				var total   = players.length;

				// Bucket by year of last sign-in. Use a sentinel "Inactive" bucket for
				// players whose last_signin is the 1970 default (never attended).
				var byYear = {};
				var nowYear = new Date().getFullYear();
				var sixMoCutoff = Date.now() - 6 * 30.44 * 24 * 3600 * 1000;
				var activeRecent = 0;
				players.forEach(function(p) {
					var raw = p.lastSignin || '1970-01-01';
					var key;
					if (raw === '1970-01-01' || raw.indexOf('1970') === 0) {
						key = 'never';
					} else {
						key = raw.slice(0, 4); // YYYY
					}
					(byYear[key] = byYear[key] || []).push(p);
					var ts = new Date(raw + 'T00:00:00').getTime();
					if (ts >= sixMoCutoff) activeRecent++;
				});

				// Sort keys: real years descending (newest first), 'never' last.
				var yearKeys = Object.keys(byYear).filter(function(k){ return k !== 'never'; })
					.sort(function(a,b){ return b.localeCompare(a); });
				if (byYear.never) yearKeys.push('never');

				// Update tab count + summary line
				var tabCount = document.getElementById('kn-players-tab-count');
				if (tabCount) tabCount.textContent = '(' + total + ')';
				var summEl = document.getElementById('kn-players-summary');
				if (summEl) {
					summEl.textContent = activeRecent + ' active member' + (activeRecent!==1?'s':'')
						+ ' (past 6 months)' + (total > activeRecent ? ' · ' + total + ' total' : '');
				}

				// Build year-bucketed cards + list sections in one pass.
				var cardsEl = document.getElementById('kn-players-cards');
				var listEl  = document.getElementById('kn-players-list');
				var cardsHtml = [];
				var listHtml  = [];
				yearKeys.forEach(function(yk, idx) {
					var bucket = byYear[yk];
					var label  = (yk === 'never') ? 'No recorded sign-ins' : yk;
					if (yk !== 'never' && yk == nowYear) label = yk + ' (current)';
					var openAttr = idx === 0 ? ' open' : '';
					var count    = bucket.length;
					var summary  =
						'<summary class="kn-year-summary">'
						+ '<span class="kn-year-label">' + label + '</span>'
						+ '<span class="kn-year-count">' + count + ' member' + (count!==1?'s':'') + '</span>'
						+ '</summary>';

					cardsHtml.push(
						'<details class="kn-year-section"' + openAttr + ' data-year="' + yk + '">'
						+ summary
						+ '<div class="kn-players-grid">'
						+ bucket.map(function(p){ return knPlayerCardHtml(p, uir); }).join('')
						+ '</div></details>'
					);
					listHtml.push(
						'<details class="kn-year-section"' + openAttr + ' data-year="' + yk + '">'
						+ summary
						+ '<table class="kn-table kn-year-table kn-sortable"><thead><tr>'
						+ '<th data-sorttype="text">Persona</th>'
						+ '<th data-sorttype="text">Park</th>'
						+ '<th data-sorttype="numeric">6mo Sign-ins</th>'
						+ '<th data-sorttype="date">Last Visit</th>'
						+ '<th data-sorttype="text">Last Class</th>'
						+ '<th data-sorttype="text">Role</th>'
						+ '</tr></thead><tbody>'
						+ bucket.map(function(p){ return knPlayerRowHtml(p, uir); }).join('')
						+ '</tbody></table></details>'
					);
				});

				if (cardsEl) { cardsEl.innerHTML = cardsHtml.join(''); cardsEl.style.display = ''; }
				if (listEl)  { listEl.innerHTML  = listHtml.join('');  /* keeps display:none until view toggle */ }

				// Hide spinner
				var loadEl = document.getElementById('kn-players-loading');
				if (loadEl) loadEl.style.display = 'none';
			})
			.catch(function() {
				knPlayersLoaded = false;
				var loadEl = document.getElementById('kn-players-loading');
				if (loadEl) loadEl.innerHTML = '<span style="color:#e53e3e">Failed to load players.</span>';
			});
	}

	// Trigger on first Players tab click; also extend search to cover list rows
	document.addEventListener('DOMContentLoaded', function() {
		var btn = document.querySelector('[data-kntab="players"]');
		if (btn) btn.addEventListener('click', knLoadPlayers, {once: true});

		function knApplyPlayerFilters() {
			var qInput = document.getElementById('kn-player-search');
			var q = (qInput ? qInput.value : '').trim().toLowerCase();
			var aoBtn = document.getElementById('kn-active-only-btn');
			var activeOnly = aoBtn && aoBtn.classList.contains('kn-view-active');
			var roots = [
				document.getElementById('kn-players-cards'),
				document.getElementById('kn-players-list')
			];
			roots.forEach(function(root) {
				if (!root) return;
				root.querySelectorAll('.kn-player-card').forEach(function(card) {
					var nameEl = card.querySelector('.kn-player-name');
					var pName  = nameEl ? nameEl.textContent.toLowerCase() : '';
					var mn     = (card.dataset.mundaneName || '').toLowerCase();
					var sc     = parseInt(card.dataset.signinCount || '0', 10);
					var match  = (!q || pName.indexOf(q) !== -1 || mn.indexOf(q) !== -1) && (!activeOnly || sc > 0);
					card.style.display = match ? '' : 'none';
				});
				root.querySelectorAll('.kn-year-table tbody tr').forEach(function(row) {
					var persona = row.cells[0] ? row.cells[0].textContent.toLowerCase() : '';
					var mn      = (row.dataset.mundaneName || '').toLowerCase();
					var sc      = parseInt(row.dataset.signinCount || '0', 10);
					var match   = (!q || persona.indexOf(q) !== -1 || mn.indexOf(q) !== -1) && (!activeOnly || sc > 0);
					row.style.display = match ? '' : 'none';
				});
				var filtering = q || activeOnly;
				root.querySelectorAll('.kn-year-section').forEach(function(sec) {
					if (!filtering) { sec.style.display = ''; return; }
					var hasMatch = sec.querySelector('.kn-player-card:not([style*="display: none"]), .kn-year-table tbody tr:not([style*="display: none"])');
					sec.style.display = hasMatch ? '' : 'none';
					if (hasMatch) sec.open = true;
				});
			});
		}

		var searchInput = document.getElementById('kn-player-search');
		if (searchInput) searchInput.addEventListener('input', knApplyPlayerFilters);
		var aoBtn = document.getElementById('kn-active-only-btn');
		if (aoBtn) aoBtn.addEventListener('click', function() {
			this.classList.toggle('kn-view-active');
			knApplyPlayerFilters();
		});
	});

	window.knCopyIcsUrl = function() {
		var inp = document.getElementById('kn-sub-url-input');
		if (!inp) return;
		inp.select();
		inp.setSelectionRange(0, 99999);
		try {
			navigator.clipboard.writeText(inp.value).then(function() {
				var btn = document.querySelector('.kn-sub-copy-btn');
				if (btn) { btn.innerHTML = '<i class="fas fa-check"></i>'; setTimeout(function(){ btn.innerHTML = '<i class="fas fa-copy"></i>'; }, 1500); }
			});
		} catch(e) { document.execCommand('copy'); }
	}

	// Close subscribe popover on outside click
	document.addEventListener('click', function(e) {
		var wrap = document.getElementById('kn-sub-wrap');
		if (wrap && !wrap.contains(e.target)) {
			var pop = document.getElementById('kn-sub-pop');
			if (pop) pop.style.setProperty('display', 'none', 'important');
		}
	});

})();
