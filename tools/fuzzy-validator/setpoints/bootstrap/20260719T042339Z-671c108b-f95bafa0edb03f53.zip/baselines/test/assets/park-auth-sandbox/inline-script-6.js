
function pkCopyEventLink(el) {
	var url = el.getAttribute('data-url');
	navigator.clipboard.writeText(url).then(function() {
		el.classList.add('pk-copied');
		setTimeout(function() { el.classList.remove('pk-copied'); }, 1500);
	});
}
window.pkRecActiveFilter = 'open';
window.pkRecCircleAwardIds = [];
$.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
	if (settings.nTable.id !== 'pk-rec-table') return true;
	var filter = window.pkRecActiveFilter || 'all';
	if (filter === 'all') return true;
	var row = settings.aoData[dataIndex].nTr;
	var rowFilter = row ? row.getAttribute('data-filter') : '';
	if (filter === 'open') return rowFilter !== 'already';
	if (filter === 'mycircles') {
		if (rowFilter === 'already') return false;
		var aid = parseInt(row.getAttribute('data-award-id') || '0', 10);
		return (window.pkRecCircleAwardIds || []).indexOf(aid) !== -1;
	}
	return rowFilter === filter;
});
$(function() {
	if ($('#pk-rec-table').length) {
		window.pkRecDT = $('#pk-rec-table').DataTable({
			order: [[4, 'desc']],
			columnDefs: [
				{ targets: [4], type: 'date' },
							],
			pageLength: 25,
			scrollX: true,
			dom: "<'ork-dt-top'lf>rt<'ork-dt-bot'ip>",
			lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'All']],
			language: { searchPlaceholder: 'Search…', search: '', lengthMenu: 'Show _MENU_' }
		});
	}
});
window.pkRecPrint = function() { if (window.pkRecDT) window.recsExportPrint(window.pkRecDT, 'Award Recommendations \u2014 Silver Fen'); };
window.pkRecCsv   = function() { if (window.pkRecDT) window.recsExportCsv(window.pkRecDT, 'recs-Silver-Fen.csv'); };
initEmailSpellCheck('pk-addplayer-email', 'pk-addplayer-email-suggestion');
window.pkUsernameCheck = initUsernameAvailabilityCheck({
	inputId:     'pk-addplayer-username',
	statusId:    'pk-addplayer-username-status',
	submitBtnId: 'pk-addplayer-submit',
	endpointUrl: 'http://127.0.0.1:19080/orkui/index.php?Route=PlayerAjax/check_username',
	gateMode:    'soft'  // host form has its own required/min-length validation
});
// Patch the modal-open function so a stale "X is taken" doesn't linger across
// closes. Defined in revised.js; we wrap to call reset() after the original.
(function() {
	var _origOpen = window.pkOpenAddPlayerModal;
	if (typeof _origOpen !== 'function') return;
	window.pkOpenAddPlayerModal = function() {
		var r = _origOpen.apply(this, arguments);
		if (window.pkUsernameCheck && window.pkUsernameCheck.reset) window.pkUsernameCheck.reset();
		return r;
	};
})();
