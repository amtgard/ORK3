
(function() {
	var UIR = 'http://127.0.0.1:19080/orkui/index.php?Route=';
	// Server-computed today in the server's local timezone — use this wherever
	// JS code needs to know "is this date today?". JS's new Date().toISOString()
	// returns UTC and will be off by one for users west of UTC late at night.
	var WX_TODAY = '2026-07-18';
	var wxIcon = function(c) {
		c = +c;
		if (c === 0)                  return '☀️';
		if (c === 1)                  return '🌤️';
		if (c === 2)                  return '⛅';
		if (c === 3)                  return '☁️';
		if (c === 45 || c === 48)     return '🌫️';
		if (c >= 51 && c <= 57)       return '🌦️';
		if (c >= 61 && c <= 67)       return '🌧️';
		if (c >= 71 && c <= 77)       return '❄️';
		if (c >= 80 && c <= 82)       return '🌦️';
		if (c === 85 || c === 86)     return '🌨️';
		if (c >= 95 && c <= 99)       return '⛈️';
		return '🌡️';
	};
	function esc(s) { return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
	function tempPair(f) { var c = Math.round((f - 32) * 5 / 9); return Math.round(f) + '/' + c + '°'; }
	// "(feels 107/41°)" tail when apparent temp diverges by ≥5°F — heat index
	// on hot+humid days, wind chill on cold+windy days. Silent otherwise.
	function feelsTail(f, appF) {
		if (f == null || appF == null) return '';
		if (Math.abs(appF - f) < 5) return '';
		return ' <span class="wx-feels">(feels ' + tempPair(appF) + ')</span>';
	}

	// Kingdom-name shortener mirrors Weather::short_kingdom in PHP
	function shortKingdom(name) {
		if (!name) return '';
		if (/Freeholds/i.test(name)) return '';
		var m = name.match(/^The (.+ Kingdom)$/i);
		if (m) return 'the ' + m[1];
		return name.replace(/^The /i, '').replace(/^(Kingdom|Empire|Principality) of /i, '');
	}

	function rollupKingdoms(map, max) {
		max = max || 5;
		if (!map) return '';
		var arr = Object.keys(map).map(function(k) { return [k, map[k]]; });
		arr.sort(function(a, b) { return b[1] - a[1]; });
		arr = arr.slice(0, max);
		var names = arr.map(function(e) { return shortKingdom(e[0]); }).filter(function(s) { return s; });
		if (names.length === 0) return '';
		if (names.length === 1) return names[0];
		if (names.length === 2) return names[0] + ' and ' + names[1];
		return names.slice(0, -1).join(', ') + ', and ' + names[names.length - 1];
	}

	// JS mirror of $wxKingdomPhrase — see PHP comment.
	function kingdomPhrase(n, map, multiPrefix) {
		if (!map) return '';
		var names = rollupKingdoms(map);
		if (!names) return '';
		var kc = 0;
		for (var k in map) {
			if (Object.prototype.hasOwnProperty.call(map, k) && shortKingdom(k) !== '') kc++;
		}
		if (n === 1 || kc === 1) return ' in ' + names;
		return multiPrefix + names;
	}

	function renderRundown(r, dayLabel) {
		var bc = r.badge_counts || {}, bk = r.badge_kingdoms || {};
		var standout = r.standout_park || null;
		var leadParts = [];
		var noPlay = r.no_play_today;
		var noFlags = Object.keys(bc).length === 0;
		if (noPlay) {
			leadParts.push('No parks have in-person play scheduled for ' + dayLabel + '.');
		} else if (noFlags) {
			leadParts.push('Of the parks playing ' + dayLabel + ', conditions look favorable across the board — no warnings flagged.');
		} else {
			if (bc['Thunderstorms']) {
				var n = bc['Thunderstorms'];
				var suffix = kingdomPhrase(n, bk['Thunderstorms'], ' — primarily in ');
				leadParts.push('Of parks playing ' + dayLabel + ', ' + n + ' ' + (n === 1 ? 'faces' : 'face') + ' thunderstorms' + suffix + '.');
			}
			if (bc['Extreme heat']) {
				var n = bc['Extreme heat'];
				leadParts.push((n === 1 ? 'One park playing ' + dayLabel + ' is' : n + ' parks playing ' + dayLabel + ' are') + ' facing extreme heat.');
			}
			if (bc['Frostbite risk']) {
				var n = bc['Frostbite risk'];
				leadParts.push((n === 1 ? 'One park playing ' + dayLabel + ' is' : n + ' parks playing ' + dayLabel + ' are') + ' under frostbite-risk conditions.');
			}
			if (bc['Severe wind']) {
				var n = bc['Severe wind'];
				var suffix = kingdomPhrase(n, bk['Severe wind'], ', across ');
				leadParts.push('Severe wind gusts (40+ mph / 65+ km/h) at ' + n + ' ' + (n === 1 ? 'park' : 'parks') + ' playing ' + dayLabel + suffix + '.');
			}
			if (bc['Very high UV']) {
				var n = bc['Very high UV'];
				var suffix = kingdomPhrase(n, bk['Very high UV'], ' in ');
				leadParts.push('Very high UV at ' + n + ' ' + (n === 1 ? 'park' : 'parks') + ' playing ' + dayLabel + suffix + '.');
			}
		}

		var standoutLine = '';
		if (standout) {
			var icons = { 'Extreme heat':'🥵', 'Frostbite risk':'🥶', 'Thunderstorms':'⛈️', 'Severe wind':'💨', 'Very high UV':'🌞' };
			var pieces = (standout.flags || []).map(function(f) { return (icons[f] || '⚠️') + ' ' + esc(f); });
			standoutLine = '<a href="' + UIR + 'Park/profile/' + standout.park_id + '" class="wx-jump-park" data-park-id="' + standout.park_id + '" target="_blank" rel="noopener">' + esc(standout.name) + '</a> carries the worst forecast — ' + pieces.join(' · ');
			if (standout.app_hi_f != null) {
				standoutLine += ' (' + tempPair(standout.app_hi_f) + ' apparent).';
			} else {
				standoutLine += '.';
			}
		}

		// Coming-up: ALWAYS today-relative — keep this constant even when pills shift.
		// We don't have the event count in the per-day response (we only computed it
		// for today on initial load), so leave the existing paragraph untouched.

		var html = '';
		if (leadParts.length) html += '<p>' + leadParts.join(' ') + '</p>';
		if (standoutLine)     html += '<p>' + standoutLine + '</p>';
		// "N events in the week ahead" — always relative to "now", shows on
		// every day pill so users see upcoming event concerns regardless of
		// which day they're inspecting.
		if (window.WX_COMING_UP_HTML) {
			html += window.WX_COMING_UP_HTML;
		}
		document.getElementById('wx-rundown-body').innerHTML = html;
	}

	// Severity tier from the highest-severity badge — drives map marker color.
	function rowTier(p) {
		if (!p.forecast || p.forecast.hi_f == null) return 'none';
		if (p.badges && p.badges.length) {
			for (var i = 0; i < p.badges.length; i++) {
				if (p.badges[i].severity === 'warning') return 'warning';
			}
			return 'caution';
		}
		return 'favorable';
	}
	var TIER_COLOR = { warning: '#e53e3e', caution: '#dd6b20', favorable: '#48bb78', none: '#a0aec0' };
	var TIER_ORDER = { warning: 0, caution: 1, favorable: 2, none: 3 };
	function statusText(s) {
		if (s === 'dormant')     return 'no recent activity — weather not tracked';
		if (s === 'no_coords')   return 'park location not set';
		return 'forecast unavailable';
	}

	var wxMap = null, wxTileLayer = null, wxMarkers = [], wxMarkersByPark = {};
	var wxTempMarker = null; // ephemeral marker for event-only venues (no park marker)
	var wxBounds = null;    // last fitted bounds — Esc flies back to this
	var wxZoomedIn = false; // true while user is zoomed into a specific park/event
	var wxOpeningPopup = false; // true in the instant before openPopup fires, so
	                            // popupclose can tell "replaced by another" vs "× clicked"
	var wxFitting = false;  // true during programmatic flyToBounds/fitBounds — suppresses
	                        // the zoomend listener so it doesn't re-show the button
	function setZoomedIn(v) {
		wxZoomedIn = v;
		var btn = document.getElementById('wx-zoom-out');
		if (btn) btn.classList.toggle('visible', !!v);
	}
	function fitWxMap() {
		if (wxMap && wxBounds) {
			wxFitting = true;
			wxMap.flyToBounds(wxBounds, { padding: [30, 30], maxZoom: 9, duration: 0.6 });
			wxMap.once('moveend', function() { wxFitting = false; });
		}
		setZoomedIn(false);
	}
	function isDarkTheme() { return document.documentElement.getAttribute('data-theme') === 'dark'; }
	function wxApplyMapTheme() {
		if (!wxMap) return;
		var url = isDarkTheme()
			? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
			: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png';
		if (wxTileLayer) wxMap.removeLayer(wxTileLayer);
		wxTileLayer = L.tileLayer(url, { maxZoom: 19, subdomains: 'abcd' }).addTo(wxMap);
	}
	function ensureMap() {
		if (wxMap || typeof L === 'undefined') return wxMap;
		wxMap = L.map('wx-map', { zoomControl: true, attributionControl: false }).setView([39.5, -98.35], 4);
		wxApplyMapTheme();
		new MutationObserver(wxApplyMapTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
		onMapReady();
		return wxMap;
	}
	function renderMap(rows, dayLabel) {
		var shortDay = dayLabel === 'today' ? 'Today' : dayLabel.slice(0,1).toUpperCase() + dayLabel.slice(1,3);
		document.getElementById('wx-map-title').textContent = '🗺️ Conditions Map — ' + shortDay;
		if (!ensureMap()) return;
		// Close any open popup and reset zoom state when the user switches dates.
		wxMap.closePopup();
		setZoomedIn(false);
		// Clear old markers
		wxMarkers.forEach(function(m) { wxMap.removeLayer(m); });
		wxMarkers = [];
		wxMarkersByPark = {};
		if (wxTempMarker) { wxMap.removeLayer(wxTempMarker); wxTempMarker = null; }
		// Place worst tiers on top by sorting ascending by TIER_ORDER then adding in order
		// (Leaflet stacks later-added markers above earlier ones)
		var plot = rows.filter(function(p) { return p.lat != null && p.lng != null; })
			.slice()
			.sort(function(a, b) { return TIER_ORDER[rowTier(b)] - TIER_ORDER[rowTier(a)]; });
		var bounds = [];
		plot.forEach(function(p) {
			var tier = rowTier(p);
			var color = TIER_COLOR[tier];
			var marker = L.circleMarker([p.lat, p.lng], {
				radius: tier === 'warning' ? 8 : (tier === 'caution' ? 7 : 6),
				color: color, weight: 1, fillColor: color,
				fillOpacity: tier === 'none' ? 0.4 : 0.8
			}).addTo(wxMap);
			var fc = p.forecast;
			var wxLine = '';
			if (fc && fc.hi_f != null) {
				var loPart = fc.lo_f != null ? ' / L ' + tempPair(fc.lo_f) + feelsTail(fc.lo_f, fc.app_lo_f) : '';
				wxLine = '<div class="wx-pp-wx">' + wxIcon(fc.code) + ' ' + tempPair(fc.hi_f) + feelsTail(fc.hi_f, fc.app_hi_f) + loPart + '</div>';
				wxLine += renderBadgeChips(p.badges);
			} else {
				wxLine = '<div class="wx-pp-meta">' + esc(statusText(p.forecast_status)) + '</div>';
			}
			var k = shortKingdom(p.kingdom_name || '');
			marker.bindPopup(
				'<div class="wx-map-popup">' +
					'<div class="wx-pp-name"><a href="' + UIR + 'Park/profile/' + p.park_id + '" target="_blank" rel="noopener">' + esc(p.park_name) + '</a></div>' +
					(k ? '<div class="wx-pp-meta">' + esc(k) + '</div>' : '') +
					wxLine +
				'</div>'
			);
			var tip = p.park_name;
			if (tier === 'none') tip += ' — ' + statusText(p.forecast_status);
			marker.bindTooltip(tip, { direction: 'top', opacity: 0.9 });
			wxMarkers.push(marker);
			wxMarkersByPark[p.park_id] = marker;
			bounds.push([p.lat, p.lng]);
		});
		if (bounds.length) {
			wxBounds = bounds;
			wxFitting = true;
			wxMap.fitBounds(bounds, { padding: [30, 30], maxZoom: 9 });
			wxMap.once('moveend', function() { wxFitting = false; });
		}
		setTimeout(function() { wxMap.invalidateSize(); }, 50);
	}

	function renderPlay(rows, dayLabel) {
		var shortDay = dayLabel === 'today' ? 'Today' : dayLabel.slice(0,1).toUpperCase() + dayLabel.slice(1,3);
		document.getElementById('wx-play-title').textContent = '🏕️ Play ' + shortDay;
		var body = document.getElementById('wx-play-body');
		if (!rows.length) {
			body.innerHTML = '<div class="wx-empty">No in-person play scheduled.</div>';
			document.getElementById('wx-play-count').textContent = '0 parks';
			ensurePlayToggle(0, 0);
			return;
		}
		var flaggedCount = 0;
		rows.forEach(function(p) { if (p.badges && p.badges.length) flaggedCount++; });
		// Reset the toggle to the default mode for the new day: flagged when
		// any exist, otherwise all. Re-create the button via ensurePlayToggle.
		var existingBtn = document.getElementById('wx-play-toggle');
		if (existingBtn) existingBtn.remove();
		var html = '';
		rows.forEach(function(p, i) {
			var k = shortKingdom(p.kingdom_name || '');
			var fc = p.forecast || null;
			var scheds = (p.schedules || []).map(function(s) {
				var t = '';
				if (s.time) {
					var parts = s.time.split(':');
					var d = new Date(); d.setHours(+parts[0], +parts[1] || 0, 0, 0);
					t = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
				}
				return esc(s.purpose) + (t ? ' at ' + t : '');
			});
			var wx = '';
			if (fc && fc.hi_f != null) {
				var loPart = fc.lo_f != null ? ' · L ' + tempPair(fc.lo_f) + feelsTail(fc.lo_f, fc.app_lo_f) : '';
				wx = '<div class="wx-play-temps">' + wxIcon(fc.code) + ' ' + tempPair(fc.hi_f) + feelsTail(fc.hi_f, fc.app_hi_f) + loPart + '</div>';
				if (p.badges && p.badges.length) {
					wx += '<div class="wx-play-meta">' +
						p.badges.map(function(b) { return '<span class="wx-event-badge wx-event-badge-' + b.severity + '" title="' + esc(b.label) + '"' + wxSafetyAttrs(b.label) + '>' + b.icon + '</span>'; }).join(' ') +
						'</div>';
				}
			} else {
				wx = '<div class="wx-play-empty">' + esc(statusText(p.forecast_status)) + '</div>';
			}
			var coordAttrs = (p.lat != null && p.lng != null)
				? ' data-lat="' + p.lat + '" data-lng="' + p.lng + '"' : '';
			var sev = +p._score || 0;
			var nameAttr = (p.park_name || '').toLowerCase();
			var flag = (p.badges && p.badges.length) ? '1' : '0';
			html += '<div class="wx-play-row" data-park-id="' + p.park_id + '"' +
				' data-park-name="' + esc(nameAttr) + '" data-severity="' + sev + '"' +
				' data-flagged="' + flag + '"' + coordAttrs + '>' +
				'<div class="wx-play-main">' +
					'<div class="wx-play-park"><a href="' + UIR + 'Park/profile/' + p.park_id + '" class="wx-jump" target="_blank" rel="noopener">' + esc(p.park_name) + '</a></div>' +
					'<div class="wx-play-meta">' + scheds.join(' &middot; ') + (k ? ' &middot; ' + esc(k) : '') + '</div>' +
				'</div>' +
				'<div class="wx-play-wx">' + wx + '</div>' +
			'</div>';
		});
		body.innerHTML = html;
		ensurePlayToggle(flaggedCount, rows.length);
		applyPlayState();
	}

	// Label the toggle based on the current mode + whether toggling makes sense.
	// Modes:
	//   "flagged" → show only parks with badges, severity-sorted. Default when
	//               any flagged parks exist.
	//   "all"     → show every park, alphabetical. Default when nothing's flagged.
	// Button only appears when both modes would show different content (i.e.
	// at least one flagged AND at least one unflagged).
	function labelToggle(btn, flaggedCount, total) {
		if (!btn) return;
		var mode = btn.dataset.mode || 'flagged';
		var hasUnflagged = flaggedCount < total;
		if (mode === 'flagged') {
			// Toggle would either reveal unflagged rows OR just re-sort.
			btn.textContent = hasUnflagged ? 'Show all ' + total : 'A–Z';
		} else {
			btn.textContent = hasUnflagged ? 'Show concerns only' : 'By severity';
		}
		btn.classList.toggle('active', mode === 'all');
	}

	function ensurePlayToggle(flaggedCount, total) {
		var controls = document.querySelector('#wx-play .wx-play-controls');
		if (!controls) return;
		var existing = document.getElementById('wx-play-toggle');
		// Hide toggle only when there's nothing flagged — in that case the
		// flagged mode would be empty, so default 'all' (alphabetical) and
		// drop the button.
		if (flaggedCount <= 0) {
			if (existing) existing.remove();
			return;
		}
		if (!existing) {
			existing = document.createElement('button');
			existing.id = 'wx-play-toggle';
			existing.className = 'wx-play-toggle';
			existing.dataset.mode = 'flagged';
			controls.appendChild(existing);
			existing.addEventListener('click', function() {
				existing.dataset.mode = existing.dataset.mode === 'flagged' ? 'all' : 'flagged';
				var rows = document.querySelectorAll('#wx-play-body .wx-play-row');
				var f = 0;
				rows.forEach(function(r) { if (r.dataset.flagged === '1') f++; });
				labelToggle(existing, f, rows.length);
				applyPlayState();
				var body = document.getElementById('wx-play-body');
				if (body) body.scrollTop = 0;
			});
		}
		labelToggle(existing, flaggedCount, total);
	}

	// Single source of truth for play-list visibility/order.
	//   - "flagged" mode (no search): severity-sorted, only data-flagged="1" visible
	//   - "all" mode OR any search: alphabetical, every matching row visible
	function applyPlayState() {
		var body = document.getElementById('wx-play-body');
		if (!body) return;
		var rows = Array.prototype.slice.call(body.querySelectorAll('.wx-play-row'));
		if (!rows.length) return;
		var searchEl = document.getElementById('wx-play-search');
		var query = (searchEl && searchEl.value || '').trim().toLowerCase();
		var toggle = document.getElementById('wx-play-toggle');
		// Default to 'all' when no toggle present (nothing flagged), 'flagged' otherwise.
		var mode = toggle ? toggle.dataset.mode : 'all';
		// Search always shows everything matching, alphabetically — overrides mode.
		var effectiveMode = query ? 'all' : mode;

		rows.sort(function(a, b) {
			if (effectiveMode === 'all') {
				return (a.dataset.parkName || '').localeCompare(b.dataset.parkName || '');
			}
			var ds = (+b.dataset.severity || 0) - (+a.dataset.severity || 0);
			if (ds !== 0) return ds;
			return (a.dataset.parkName || '').localeCompare(b.dataset.parkName || '');
		});
		rows.forEach(function(r) { body.appendChild(r); });

		var flaggedTotal = 0, shown = 0;
		rows.forEach(function(r) {
			if (r.dataset.flagged === '1') flaggedTotal++;
			r.classList.remove('wx-hidden', 'wx-filtered');
			var name = r.dataset.parkName || '';
			var matchesQuery = !query || name.indexOf(query) !== -1;
			if (!matchesQuery) { r.classList.add('wx-filtered'); return; }
			if (effectiveMode === 'flagged' && r.dataset.flagged !== '1') {
				r.classList.add('wx-hidden');
				return;
			}
			shown++;
		});

		// Count: "5 of 162" when filtered, "162 parks" when all, "3 / 162" while searching.
		var countEl = document.getElementById('wx-play-count');
		if (countEl) {
			if (query)                          countEl.textContent = shown + ' / ' + rows.length;
			else if (effectiveMode === 'flagged') countEl.textContent = shown + ' of ' + rows.length;
			else                                countEl.textContent = rows.length + (rows.length === 1 ? ' park' : ' parks');
		}

		// Banner: only visible in flagged mode (not while searching either —
		// search results aren't a "weather concerns" filter).
		var card = document.getElementById('wx-play');
		if (card) card.classList.toggle('is-flagged-mode', effectiveMode === 'flagged');

		// Toggle button: invisible (but space reserved) while searching. The
		// search already shows "all matching parks" regardless of mode, so the
		// button would either be a no-op or set stale state for when the
		// search is cleared. Reserving space prevents header reflow.
		if (toggle) toggle.classList.toggle('wx-invisible', !!query);
	}

	// Filter the events list to only show events that haven't ended before the
	// selected date. Multi-day events remain visible as long as their end date
	// is on or after the selected date.
	function applyEventsFilter(date) {
		var isToday = (date === WX_TODAY);
		var rows = document.querySelectorAll('#upcoming-events .wx-event');
		var shown = 0;
		rows.forEach(function(r) {
			var end = r.dataset.eventEnd || r.dataset.eventStart || '';
			var visible = !end || end >= date;
			r.classList.toggle('wx-hidden', !visible);
			if (visible) shown++;
		});
		var title = document.getElementById('wx-events-title');
		if (title) {
			if (isToday) {
				title.textContent = '📅 Upcoming Events — in the week ahead';
			} else {
				var d = new Date(date + 'T00:00:00');
				var lbl = d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
				title.textContent = '📅 Upcoming Events — from ' + lbl;
			}
		}
		var body = document.querySelector('#upcoming-events .wx-events-body');
		if (body) {
			var emptyEl = body.querySelector('.wx-events-empty-state');
			if (shown === 0 && rows.length > 0) {
				if (!emptyEl) {
					emptyEl = document.createElement('div');
					emptyEl.className = 'wx-empty wx-events-empty-state';
					body.appendChild(emptyEl);
				}
				emptyEl.textContent = 'No events on or after this date.';
			} else if (emptyEl) {
				emptyEl.remove();
			}
		}
	}

	function activatePill(date) {
		document.querySelectorAll('.wx-pill').forEach(function(b) {
			b.classList.toggle('active', b.dataset.date === date);
		});
		document.querySelector('.wx-root').dataset.selectedDate = date;
	}

	function fetchAndRender(date, dayLabel) {
		document.getElementById('wx-play-body').innerHTML = '<div class="wx-loading">Loading…</div>';
		fetch(UIR + 'Weather/day/' + date, { credentials: 'same-origin' })
			.then(function(r) { return r.json(); })
			.then(function(d) {
				if (!d || d.status !== 0) {
					document.getElementById('wx-play-body').innerHTML = '<div class="wx-empty">Could not load weather.</div>';
					return;
				}
				renderRundown(d.rundown || {}, dayLabel);
				renderMap(d.play || [], dayLabel);
				renderPlay(d.play || [], dayLabel);
			})
			.catch(function() {
				document.getElementById('wx-play-body').innerHTML = '<div class="wx-empty">Request failed.</div>';
			});
	}

	document.querySelectorAll('.wx-pill').forEach(function(btn) {
		btn.addEventListener('click', function() {
			var date = this.dataset.date;
			var dayLabel = (date === WX_TODAY) ? 'today' :
				new Date(date + 'T00:00:00').toLocaleDateString([], { weekday: 'long' });
			activatePill(date);
			applyEventsFilter(date);
			fetchAndRender(date, dayLabel);
		});
	});

	// Stash the server-rendered "coming up" paragraph so we can re-insert it
	// when the user comes back to Today after viewing another day.
	(function() {
		var p = document.querySelector('#wx-rundown-body p:last-child');
		if (p && p.querySelector('a[href="#upcoming-events"]')) {
			window.WX_COMING_UP_HTML = p.outerHTML;
		}
	})();

	// Wire the server-rendered header toggle (initial page load — today's data)
	(function() {
		var initialToggle = document.getElementById('wx-play-toggle');
		if (initialToggle) {
			initialToggle.addEventListener('click', function() {
				initialToggle.dataset.mode = initialToggle.dataset.mode === 'flagged' ? 'all' : 'flagged';
				var rows = document.querySelectorAll('#wx-play-body .wx-play-row');
				var f = 0;
				rows.forEach(function(r) { if (r.dataset.flagged === '1') f++; });
				labelToggle(initialToggle, f, rows.length);
				applyPlayState();
				var body = document.getElementById('wx-play-body');
				if (body) body.scrollTop = 0;
			});
		}
		// Search input: debounced filter
		var search = document.getElementById('wx-play-search');
		if (search) {
			var timer = null;
			search.addEventListener('input', function() {
				clearTimeout(timer);
				timer = setTimeout(applyPlayState, 80);
			});
		}
		// Banner "Show all parks" — delegates to the header toggle so a single
		// state owns the mode.
		var modeClear = document.getElementById('wx-play-mode-clear');
		if (modeClear) {
			modeClear.addEventListener('click', function() {
				var t = document.getElementById('wx-play-toggle');
				if (t) t.click();
			});
		}
		// Normalize count text + banner visibility on first paint
		applyPlayState();
		// Apply event date filter for the initially selected date (today on first
		// load, but correct if someone navigates back with a stale pill state).
		applyEventsFilter("2026-07-18");
	})();

	// Esc: close any open popup and fly back to the full-map view.
	document.addEventListener('keydown', function(e) {
		if (e.key !== 'Escape') return;
		if (e.target.closest('input, textarea, [contenteditable]')) return;
		if (wxMap) wxMap.closePopup();
		fitWxMap();
	});

	// "Zoom out" button in the map header — same as Esc.
	document.getElementById('wx-zoom-out').addEventListener('click', function() {
		if (wxMap) wxMap.closePopup();
		fitWxMap();
	});

	// Closing a popup via its × button also zooms back out (only when we
	// triggered the zoom — wxZoomedIn tracks this).
	function onMapReady() {
		// Clear the flag once the new popup is actually open.
		wxMap.on('popupopen', function() { wxOpeningPopup = false; });
		// Only zoom out when the popup was closed by the user (× or Esc), not
		// when it was replaced by another popup (wxOpeningPopup is true then).
		wxMap.on('popupclose', function() {
			if (wxZoomedIn && !wxOpeningPopup) fitWxMap();
		});
		// Show the "zoom out" button whenever the user manually zooms or pans.
		// wxFitting suppresses this during our own programmatic flyToBounds calls.
		wxMap.on('zoomend dragend', function() {
			if (!wxFitting && wxBounds) setZoomedIn(true);
		});
	}

	// Make Leaflet recompute size after the flex layout settles, and on resize.
	window.addEventListener('resize', function() {
		if (wxMap) wxMap.invalidateSize();
	});

	// Render badges as the same colored chips used in the list rows — same
	// emoji, label visible (since the popup has room), severity-tinted background.
	function renderBadgeChips(badges) {
		if (!badges || !badges.length) return '';
		return '<div class="wx-pp-badges">' + badges.map(function(b) {
			return '<span class="wx-event-badge wx-event-badge-' + b.severity + '"' + wxSafetyAttrs(b.label) + '>' + b.icon + ' ' + esc(b.label) + wxSafetyIconHtml(b.label) + '</span>';
		}).join('') + '</div>';
	}

	// Build the same popup body the map markers use, for an event jumped to
	// without a corresponding park marker. Same .wx-map-popup classes →
	// matches the styling, dark-mode rules, etc.
	function buildEventPopup(ev) {
		var fc = ev.forecast;
		var wxLine = '';
		if (fc && fc.hi_f != null) {
			var loPart = fc.lo_f != null ? ' / L ' + tempPair(fc.lo_f) : '';
			wxLine = '<div class="wx-pp-wx">' + wxIcon(fc.code) + ' ' + tempPair(fc.hi_f) + loPart + '</div>';
			wxLine += renderBadgeChips(ev.badges);
		} else {
			wxLine = '<div class="wx-pp-meta">forecast unavailable</div>';
		}
		var parts = [];
		if (ev.park_id && ev.park_name) {
			parts.push('<a href="' + UIR + 'Park/profile/' + ev.park_id + '" target="_blank" rel="noopener">' + esc(ev.park_name) + '</a>');
		}
		var k = shortKingdom(ev.kingdom_name || '');
		if (k) parts.push(esc(k));
		var locLine = parts.length ? '<div class="wx-pp-meta">' + parts.join(' · ') + '</div>' : '';
		var dateLine = '';
		var startStr = ev.event_start ? ev.event_start.slice(0, 10) : '';
		var endStr   = ev.event_end   ? ev.event_end.slice(0, 10)   : startStr;
		if (startStr) {
			var dtS = new Date(startStr + 'T00:00:00');
			if (!isNaN(dtS)) {
				var startLabel = dtS.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
				if (endStr && endStr > startStr) {
					var dtE = new Date(endStr + 'T00:00:00');
					var endLabel = !isNaN(dtE) ? dtE.toLocaleDateString([], { month: 'short', day: 'numeric' }) : '';
					dateLine = '<div class="wx-pp-meta">' + esc(startLabel) + (endLabel ? ' – ' + esc(endLabel) : '') + '</div>';
				} else {
					dateLine = '<div class="wx-pp-meta">' + esc(startLabel) + '</div>';
				}
			}
		}
		return '<div class="wx-map-popup">' +
			'<div class="wx-pp-name"><a href="' + UIR + 'Event/detail/' + ev.event_id + '/' + ev.event_calendardetail_id + '" target="_blank" rel="noopener">' + esc(ev.name) + '</a></div>' +
			dateLine + locLine + wxLine +
		'</div>';
	}

	// Map-jump: clicking a park/event row (or its link) zooms the map instead
	// of navigating away. Modifier-key clicks still follow the link so users
	// can open the profile in a new tab if they want.
	function flyToPark(parkId) {
		var pid = parseInt(parkId, 10);
		var marker = pid ? wxMarkersByPark[pid] : null;
		if (!marker || !wxMap) return false;
		var ll = marker.getLatLng();
		wxMap.flyTo([ll.lat, ll.lng], Math.max(wxMap.getZoom(), 9), { duration: 0.6 });
		setZoomedIn(true);
		setTimeout(function() { wxOpeningPopup = true; marker.openPopup(); }, 650);
		return true;
	}

	function flyToEvent(ev) {
		if (!wxMap || !ev) return false;
		// Anchor the event popup to the host park's marker when that park is
		// playing today (no duplicate pin), otherwise drop a blue marker at
		// the event's own coords (cd.lat/lng or at_park).
		var hostMarker = ev.park_id ? wxMarkersByPark[ev.park_id] : null;
		var ll;
		if (hostMarker) {
			var p = hostMarker.getLatLng();
			ll = [p.lat, p.lng];
		} else if (ev.lat != null && ev.lng != null) {
			ll = [+ev.lat, +ev.lng];
		} else {
			return false;
		}
		wxMap.flyTo(ll, Math.max(wxMap.getZoom(), 9), { duration: 0.6 });
		setZoomedIn(true);
		if (wxTempMarker) { wxMap.removeLayer(wxTempMarker); wxTempMarker = null; }
		var popup = L.popup({ offset: hostMarker ? [0, -8] : [0, 0] })
			.setLatLng(ll)
			.setContent(buildEventPopup(ev));
		if (!hostMarker) {
			// Visual anchor for event-only venues
			wxTempMarker = L.circleMarker(ll, {
				radius: 9, color: '#3182ce', weight: 2, fillColor: '#3182ce', fillOpacity: 0.6
			}).addTo(wxMap);
		}
		setTimeout(function() { wxOpeningPopup = true; popup.openOn(wxMap); }, 650);
		return true;
	}

	function jumpClickHandler(e) {
		// Let modifier-clicks fall through (open in new tab etc.)
		if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;

		// Rundown park link (top-of-page summary)
		var jumpLink = e.target.closest('.wx-jump-park');
		if (jumpLink && jumpLink.dataset.parkId) {
			if (flyToPark(jumpLink.dataset.parkId)) {
				e.preventDefault();
				e.stopPropagation();
			}
			return;
		}

		var row = e.target.closest('.wx-play-row, .wx-event');
		if (!row || !row.closest('.wx-root')) return;
		var handled = false;
		if (row.classList.contains('wx-event')) {
			var cd = parseInt(row.dataset.eventCdId || '0', 10);
			var ev = cd && window.WX_EVENTS ? window.WX_EVENTS[cd] : null;
			if (ev) handled = flyToEvent(ev);
		} else {
			handled = flyToPark(row.dataset.parkId);
		}
		if (handled) {
			e.preventDefault();
			e.stopPropagation();
			var mapEl = document.getElementById('wx-map');
			if (mapEl) {
				var r = mapEl.getBoundingClientRect();
				if (r.top < 0 || r.bottom > window.innerHeight) {
					mapEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
				}
			}
		}
	}
	document.querySelector('.wx-root').addEventListener('click', jumpClickHandler);

	// Render the map for the initial date using the server-supplied play list
	function whenLeafletReady(cb) {
		if (typeof L !== 'undefined') return cb();
		var s = document.querySelector('script[src*="leaflet.js"]');
		if (s) s.addEventListener('load', cb);
		else window.addEventListener('load', cb);
	}
	// Events stay the same across date pills (always next-7-days from now), so
	// dump them once for the click→map-popup flow. Keep as an array (avoids
	// JSON_FORCE_OBJECT recursing into badges) and build the cd_id lookup in JS.
	(function() {
		var rows = [];
		window.WX_EVENTS = {};
		rows.forEach(function(r) { window.WX_EVENTS[r.event_calendardetail_id] = r; });
	})();

	whenLeafletReady(function() {
		var initialPlay = [];
		renderMap(initialPlay, 'today');
	});
})();
