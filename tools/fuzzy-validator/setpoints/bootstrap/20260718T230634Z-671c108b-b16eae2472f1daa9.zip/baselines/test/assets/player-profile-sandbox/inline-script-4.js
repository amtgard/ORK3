
(function() {
    var btn = document.querySelector('.pna-tenure-info-btn');
    if (!btn) return;
    var tip = btn.querySelector('.pna-tenure-info-text');
    if (!tip) return;
    function show() {
        var r = btn.getBoundingClientRect();
        tip.style.display = 'block';
        var left = r.left + r.width / 2 - 130;
        if (left < 8) left = 8;
        if (left + 260 > window.innerWidth - 8) left = window.innerWidth - 268;
        var top = r.top - tip.offsetHeight - 8;
        if (top < 8) top = r.bottom + 8;
        tip.style.left = left + 'px';
        tip.style.top  = top + 'px';
    }
    function hide() { tip.style.display = 'none'; }
    btn.addEventListener('mouseenter', show);
    btn.addEventListener('focus',      show);
    btn.addEventListener('mouseleave', hide);
    btn.addEventListener('blur',       hide);
})();

var PnConfig = {
	uir:            'http://127.0.0.1:19080/orkui/index.php?Route=',
	httpService:    'http://127.0.0.1:19080/orkservice/',
	playerId:       1,
	parkId:         0,
	parkName:       "",
	kingdomId:      0,
	recError:       false,
	canEditImages:  false,
	canEditAccount: false,
	canEditAdmin:   false,
	canManageAwards:false,
	classList:      [{"ClassId":1,"ClassName":"Anti-Paladin","Credits":0,"Reconciled":0},{"ClassId":2,"ClassName":"Archer","Credits":0,"Reconciled":0},{"ClassId":3,"ClassName":"Assassin","Credits":0,"Reconciled":0},{"ClassId":4,"ClassName":"Barbarian","Credits":0,"Reconciled":0},{"ClassId":5,"ClassName":"Bard","Credits":0,"Reconciled":0},{"ClassId":6,"ClassName":"Color","Credits":0,"Reconciled":0},{"ClassId":7,"ClassName":"Druid","Credits":0,"Reconciled":0},{"ClassId":8,"ClassName":"Healer","Credits":0,"Reconciled":0},{"ClassId":9,"ClassName":"Monk","Credits":0,"Reconciled":0},{"ClassId":10,"ClassName":"Monster","Credits":0,"Reconciled":0},{"ClassId":11,"ClassName":"Paladin","Credits":0,"Reconciled":0},{"ClassId":12,"ClassName":"Peasant","Credits":0,"Reconciled":0},{"ClassId":14,"ClassName":"Reeve","Credits":0,"Reconciled":0},{"ClassId":15,"ClassName":"Scout","Credits":0,"Reconciled":0},{"ClassId":16,"ClassName":"Warrior","Credits":0,"Reconciled":0},{"ClassId":17,"ClassName":"Wizard","Credits":0,"Reconciled":0}],
	awardRanks:     [],
	heldAwardIds:        [],
	heldKingdomAwardIds: [],
	ladderMasterMap:     {"21":{"MasterAwardIds":[1],"LadderName":"Order of the Rose","MasterName":"Master Rose","MaxRank":10},"22":{"MasterAwardIds":[2],"LadderName":"Order of the Smith","MasterName":"Master Smith","MaxRank":10},"23":{"MasterAwardIds":[3],"LadderName":"Order of the Lion","MasterName":"Master Lion","MaxRank":10},"24":{"MasterAwardIds":[4],"LadderName":"Order of the Owl","MasterName":"Master Owl","MaxRank":10},"25":{"MasterAwardIds":[5],"LadderName":"Order of the Dragon","MasterName":"Master Dragon","MaxRank":10},"26":{"MasterAwardIds":[6],"LadderName":"Order of the Garber","MasterName":"Master Garber","MaxRank":10},"27":{"MasterAwardIds":[12],"LadderName":"Order of the Warrior","MasterName":"Warlord","MaxRank":10},"28":{"MasterAwardIds":[7],"LadderName":"Order of the Jovius","MasterName":"Master Jovius","MaxRank":10},"29":{"MasterAwardIds":[9],"LadderName":"Order of the Mask","MasterName":"Master Mask","MaxRank":10},"30":{"MasterAwardIds":[8],"LadderName":"Order of the Zodiac","MasterName":"Master Zodiac","MaxRank":12},"32":{"MasterAwardIds":[10],"LadderName":"Order of the Hydra","MasterName":"Master Hydra","MaxRank":10},"33":{"MasterAwardIds":[11],"LadderName":"Order of the Griffin","MasterName":"Master Griffin","MaxRank":10},"239":{"MasterAwardIds":[240],"LadderName":"Order of the Crown","MasterName":"Master Crown","MaxRank":10},"243":{"MasterAwardIds":[244],"LadderName":"Order of Battle","MasterName":"Battlemaster","MaxRank":10}},
	playerName:          "admin",
	awardOptHTML:   "<option value=\"\">Select award...<\/option><optgroup label='Ladder Awards'><option value='94' data-is-ladder='1' data-award-id='0'>Custom Award<\/option><option value='243' data-is-ladder='1' data-award-id='243'>Order of Battle<\/option><option value='239' data-is-ladder='1' data-award-id='239'>Order of the Crown<\/option><option value='25' data-is-ladder='1' data-award-id='25'>Order of the Dragon<\/option><option value='34' data-is-ladder='1' data-award-id='34'>Order of the Flame<\/option><option value='26' data-is-ladder='1' data-award-id='26'>Order of the Garber<\/option><option value='33' data-is-ladder='1' data-award-id='33'>Order of the Griffin<\/option><option value='32' data-is-ladder='1' data-award-id='32'>Order of the Hydra<\/option><option value='28' data-is-ladder='1' data-award-id='28'>Order of the Jovius<\/option><option value='23' data-is-ladder='1' data-award-id='23'>Order of the Lion<\/option><option value='29' data-is-ladder='1' data-award-id='29'>Order of the Mask<\/option><option value='24' data-is-ladder='1' data-award-id='24'>Order of the Owl<\/option><option value='21' data-is-ladder='1' data-award-id='21'>Order of the Rose<\/option><option value='22' data-is-ladder='1' data-award-id='22'>Order of the Smith<\/option><option value='31' data-is-ladder='1' data-award-id='31'>Order of the Walker in the Middle<\/option><option value='27' data-is-ladder='1' data-award-id='27'>Order of the Warrior<\/option><option value='30' data-is-ladder='1' data-award-id='30'>Order of the Zodiac<\/option><\/optgroup><option value='246' data-custom-title='1' data-award-id='246'>Custom Title<\/option><optgroup label='Knighthoods'><option value='245'>Knight of Battle<\/option><option value='18'>Knight of the Crown<\/option><option value='17'>Knight of the Flame<\/option><option value='19'>Knight of the Serpent<\/option><option value='20'>Knight of the Sword<\/option><\/optgroup><optgroup label='Masterhoods'><option value='244' data-award-id='244' data-peerage='Master'>Battlemaster<\/option><option value='240' data-award-id='240' data-peerage='Master'>Master Crown<\/option><option value='5' data-award-id='5' data-peerage='Master'>Master Dragon<\/option><option value='6' data-award-id='6' data-peerage='Master'>Master Garber<\/option><option value='11' data-award-id='11' data-peerage='Master'>Master Griffin<\/option><option value='10' data-award-id='10' data-peerage='Master'>Master Hydra<\/option><option value='7' data-award-id='7' data-peerage='Master'>Master Jovius<\/option><option value='3' data-award-id='3' data-peerage='Master'>Master Lion<\/option><option value='9' data-award-id='9' data-peerage='Master'>Master Mask<\/option><option value='4' data-award-id='4' data-peerage='Master'>Master Owl<\/option><option value='1' data-award-id='1' data-peerage='Master'>Master Rose<\/option><option value='2' data-award-id='2' data-peerage='Master'>Master Smith<\/option><option value='8' data-award-id='8' data-peerage='Master'>Master Zodiac<\/option><option value='12' data-award-id='12' data-peerage='Master'>Warlord<\/option><\/optgroup><optgroup label='Paragons'><option value='37'>Paragon Anti-Paladin<\/option><option value='38'>Paragon Archer<\/option><option value='39'>Paragon Assassin<\/option><option value='40'>Paragon Barbarian<\/option><option value='41'>Paragon Bard<\/option><option value='241'>Paragon Color<\/option><option value='42'>Paragon Druid<\/option><option value='43'>Paragon Healer<\/option><option value='44'>Paragon Monk<\/option><option value='45'>Paragon Monster<\/option><option value='46'>Paragon Paladin<\/option><option value='47'>Paragon Peasant<\/option><option value='48'>Paragon Raider<\/option><option value='242'>Paragon Reeve<\/option><option value='49'>Paragon Scout<\/option><option value='50'>Paragon Warrior<\/option><option value='51'>Paragon Wizard<\/option><\/optgroup><optgroup label='Noble Titles'><option value='67'>Archduchess<\/option><option value='66'>Archduke<\/option><option value='56'>Baron<\/option><option value='57'>Baroness<\/option><option value='54'>Baronet<\/option><option value='55'>Baronetess<\/option><option value='60'>Count<\/option><option value='61'>Countess<\/option><option value='35'>Defender<\/option><option value='65'>Duchess<\/option><option value='64'>Duke<\/option><option value='209'>Esquire<\/option><option value='69'>Grand Duchess<\/option><option value='68'>Grand Duke<\/option><option value='53'>Lady<\/option><option value='52'>Lord<\/option><option value='63'>Marquess<\/option><option value='62'>Marquis<\/option><option value='226'>Master<\/option><option value='58'>Viscount<\/option><option value='59'>Viscountess<\/option><\/optgroup><optgroup label='Associate Titles'><option value='203'>Apprentice<\/option><option value='13'>Lord&#039;s Page<\/option><option value='14'>Man-at-Arms<\/option><option value='15'>Page<\/option><option value='16'>Squire<\/option><\/optgroup><optgroup label='Other'><option value='218'>Autocrat, Interkingdom<\/option><option value='222'>Autocrat, Interpark<\/option><option value='216'>Autocrat, Kingdom<\/option><option value='220'>Autocrat, Park<\/option><option value='204'>COM Executive Committee<\/option><option value='208'>Cultural Olympian<\/option><option value='207'>Dragonmaster<\/option><option value='224'>Grand Olympian<\/option><option value='219'>Subcrat, Interkingdom<\/option><option value='223'>Subcrat, Interpark<\/option><option value='217'>Subcrat, Kingdom<\/option><option value='221'>Subcrat, Park<\/option><option value='229'>War Event Winner<\/option><option value='230'>War Olympian<\/option><option value='231'>Warmaster<\/option><option value='36'>Weaponmaster<\/option><\/optgroup>",
	officerOptHTML: "<option value=\"\">Select title...<\/option><optgroup label='Other'><option value='86'>Baronial Champion<\/option><option value='78'>Baronial Regent<\/option><option value='82'>Baronial Seneschal<\/option><option value='205'>Champion, Principality<\/option><option value='206'>Champion, Shire<\/option><option value='93'>Director of the Board<\/option><option value='83'>Ducal Chancellor<\/option><option value='87'>Ducal Defender<\/option><option value='79'>Ducal Regent<\/option><option value='88'>Grand Ducal Defender<\/option><option value='84'>Grand Ducal General Minister<\/option><option value='80'>Grand Ducal Regent<\/option><option value='210'>Guildmaster of Anti-Paladins<\/option><option value='189'>Guildmaster of Archers<\/option><option value='190'>Guildmaster of Assassins<\/option><option value='191'>Guildmaster of Barbarians<\/option><option value='192'>Guildmaster of Bards<\/option><option value='193'>Guildmaster of Druids<\/option><option value='194'>Guildmaster of Healers<\/option><option value='188'>Guildmaster of Knights<\/option><option value='195'>Guildmaster of Monks<\/option><option value='196'>Guildmaster of Monsters<\/option><option value='197'>Guildmaster of Paladins<\/option><option value='202'>Guildmaster of Reeves<\/option><option value='212'>Guildmaster of Reeves, Barony<\/option><option value='213'>Guildmaster of Reeves, Duchy<\/option><option value='214'>Guildmaster of Reeves, Grand Duchy<\/option><option value='215'>Guildmaster of Reeves, Principality<\/option><option value='211'>Guildmaster of Reeves, Shire<\/option><option value='199'>Guildmaster of Scouts<\/option><option value='200'>Guildmaster of Warriors<\/option><option value='201'>Guildmaster of Wizards<\/option><option value='89'>Kingdom Champion<\/option><option value='92'>Kingdom Monarch<\/option><option value='91'>Kingdom Prime Minister<\/option><option value='90'>Kingdom Regent<\/option><option value='227'>Monarch, Principality<\/option><option value='198'>Plagueservant of Peasants<\/option><option value='236'>Principality Champion<\/option><option value='234'>Principality Monarch<\/option><option value='237'>Principality Prime Minister<\/option><option value='235'>Principality Regent<\/option><option value='71'>Provincial Baron<\/option><option value='72'>Provincial Baroness<\/option><option value='85'>Provincial Champion<\/option><option value='74'>Provincial Duchess<\/option><option value='73'>Provincial Duke<\/option><option value='76'>Provincial Grand Duchess<\/option><option value='75'>Provincial Grand Duke<\/option><option value='228'>Regent, Principality<\/option><option value='225'>Rules Representative<\/option><option value='70'>Sheriff<\/option><option value='81'>Shire Clerk<\/option><option value='77'>Shire Regent<\/option><\/optgroup>",
	preloadOfficers:[],
	playerParkName:   "",
	playerPersona:    "admin",
	duesPeriodType:   "month",
	duesPeriod:       6,
	canCreateUnit:    false,
	lastClassId:      0,
	attendanceDates:  [],  // populated async by PlayerAjax/attendance
	canEditAnyAttendance: false,
	customAwardId:      94,
	customTitleAwardId: 246,
	isOwnProfile:     false,
	canEditDesign:    false,
	kingdomUrl:       "http:\/\/127.0.0.1:19080\/orkui\/index.php?Route=Kingdom\/profile\/0",
	classToParagon:   {"1":37,"2":38,"3":39,"4":40,"5":41,"6":241,"7":42,"8":43,"9":44,"10":45,"11":46,"12":47,"14":242,"15":49,"16":50,"17":51},
	heldAwardIds:     [],
	canDeleteRec:   false,
	showRecsTab:    true,
	loggedInUserId: 0,
	aboutPersona:   "",
	aboutStory:     "",
	colorPrimary:   "",
	colorAccent:    "",
	namePrefix:     "",
	nameSuffix:     "",
	photoFocusX:    50,
	photoFocusY:    50,
	photoFocusSize: 100,
	hasImage:       false,
	imageUrl:       "http:\/\/127.0.0.1:19080\/assets\/heraldry\/player\/000000.jpg",
	playerTitles:   [],
	milestoneConfig: {},
	customMilestones: [],
	nameFont:        "",
	viewerBasicFonts: false,
	viewerDyslexiaFonts: false,
};
// Use the viewed player's kingdom for nav search prioritization if the user has no home kingdom
if (typeof nsKid !== 'undefined' && nsKid === 0 && PnConfig.kingdomId) nsKid = PnConfig.kingdomId;
