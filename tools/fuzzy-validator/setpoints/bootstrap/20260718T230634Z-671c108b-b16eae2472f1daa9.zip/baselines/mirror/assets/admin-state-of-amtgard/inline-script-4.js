
// Max reporting-window span enforced in production (server-crash guard); 0 = unlimited (local/dev).
window.SOR_RANGE_LIMIT_MONTHS = 0;
(function () {
	function sorKingdomSelect(predicate) {
		var sel = document.getElementById('sor-kingdoms');
		if (!sel) return;
		for (var i = 0; i < sel.options.length; i++) {
			sel.options[i].selected = predicate(sel.options[i]);
		}
	}
	window.sorSelectAll = function () { sorKingdomSelect(function () { return true; }); };
	window.sorClearAll  = function () { sorKingdomSelect(function () { return false; }); };
	window.sorSelectAllExceptFreeholds = function () {
		sorKingdomSelect(function (opt) {
			return opt.text.toLowerCase().indexOf('freeholds') === -1;
		});
	};
	// "All Time": set the date range to the full attendance history (data-min/data-max
	// are emitted server-side from MIN/MAX(attendance.date)).
	window.sorAllTime = function () {
		var btn = document.getElementById('sor-btn-all-time');
		var s = document.getElementById('sor-start');
		var e = document.getElementById('sor-end');
		if (!btn || !s || !e) return;
		if (btn.dataset.min) s.value = btn.dataset.min;
		if (btn.dataset.max) e.value = btn.dataset.max;
	};
	var bind = function (id, fn) {
		var el = document.getElementById(id);
		if (el) el.addEventListener('click', fn);
	};
	bind('sor-btn-select-all',                  window.sorSelectAll);
	bind('sor-btn-select-all-except-freeholds', window.sorSelectAllExceptFreeholds);
	bind('sor-btn-clear-all',                   window.sorClearAll);
	bind('sor-btn-all-time',                    window.sorAllTime);
}());
