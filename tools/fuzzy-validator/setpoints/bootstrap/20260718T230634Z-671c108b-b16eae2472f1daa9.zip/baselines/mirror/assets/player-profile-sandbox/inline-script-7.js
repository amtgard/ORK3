
var PnBannerConfig = {
	uir:            'http://127.0.0.1:19080/orkui/index.php?Route=',
	canManage:      true,
	entityId:       1,
	hasBanner:      false,
	bannerShowLogo: true,
	bannerVignette: true,
	bannerOffsetX:  50,
	bannerOffsetY:  50,
	bannerUrl:      "",
};
