
(function () {

  /* Class color palette */
  var SOR_CLASS_COLORS = {
    "Anti-Paladin": "#a0a0a0",
    "Archer":       "#FFA500",
    "Assassin":     "#333333",
    "Barbarian":    "#cccccc",
    "Bard":         "#ADD8E6",
    "Color":        "#ff6b6b",
    "Druid":        "#8B4513",
    "Healer":       "#e74c3c",
    "Monk":         "#808080",
    "Monster":      "#000080",
    "Paladin":      "#f1c40f",
    "Peasant":      "#27ae60",
    "Reeve":        "#2c3e50",
    "Scout":        "#2ecc71",
    "Warrior":      "#9b59b6",
    "Wizard":       "#f39c12"
  };

  function colorForClass(name) {
    return SOR_CLASS_COLORS[name] || "#888888";
  }

  function fmtNumber(n) {
    return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  function fmtPct(p) {
    return p.toFixed(1) + "%";
  }

  /**
   * renderSorClasses(data)
   * Called with the AJAX JSON payload.
   * data.classes = array of class objects (sorted by rank ascending from server,
   * but we sort defensively here too).
   */
  // FIX B: local HTML-escape helper for innerHTML concatenation in this IIFE
  function esc(s) {
    if (s == null) return "";
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  window.renderSorClasses = function (data) {
    var classes = (data && data.classes) ? data.classes.slice() : [];

    // T-4: No-data empty state
    if (!classes || classes.length === 0) {
      document.getElementById('sor-classes-skeleton').style.display = 'none';
      document.getElementById('sor-classes-content').style.display = 'block';
      document.getElementById('sor-classes-tbody').innerHTML = '<tr><td colspan="4" style="text-align:center;color:#999;padding:20px">No data for the selected period.</td></tr>';
      document.getElementById('sor-classes-chart').innerHTML = '<p style="color:#999;padding:20px;text-align:center">No data available.</p>';
      return;
    }

    /* Sort by rank for the table */
    classes.sort(function (a, b) { return a.rank - b.rank; });

    /* Max pct for bar scaling */
    var maxPct = 0;
    for (var i = 0; i < classes.length; i++) {
      if (classes[i].percentage > maxPct) maxPct = classes[i].percentage;
    }

    /* ---- Build table rows ---- */
    var tbody = document.getElementById("sor-classes-tbody");
    tbody.innerHTML = "";

    for (var i = 0; i < classes.length; i++) {
      var c = classes[i];
      var color = colorForClass(c.class_name);
      var barWidthPct = maxPct > 0 ? (c.percentage / maxPct * 100).toFixed(1) : 0;
      var isTop3 = c.rank <= 3;

      var warnHtml = "";
      if (c.inflated_note) {
        warnHtml = "<span class=\'sor-warn-icon\' tabindex=\'0\' aria-label=\'Warning\'>"
          + "&#x26A0;"
          + "<span class=\'sor-tooltip\'>May be inflated due to individual kingdom corpora requirements.</span>"
          + "</span>";
      }

      var tr = document.createElement("tr");
      tr.innerHTML =
        "<td class=\'sor-col-rank\'>"
          + "<span class=\'sor-rank-badge" + (isTop3 ? " sor-rank-top3" : "") + "\'>#" + c.rank + "</span>"
        + "</td>"
        + "<td>"
          + "<span class=\'sor-class-name-cell\'>"
            + "<span class=\'sor-class-dot\' style=\'background:" + color + "\'></span>"
            + "<span>" + esc(c.class_name) + "</span>"
            + warnHtml
          + "</span>"
        + "</td>"
        + "<td class=\'sor-col-signins\'><span class=\'sor-signins-val\'>" + fmtNumber(c.sign_in_count) + "</span></td>"
        + "<td class=\'sor-col-pct\'>"
          + "<div class=\'sor-pct-cell\'>"
            + "<div class=\'sor-pct-bar-bg\'>"
              + "<div class=\'sor-pct-bar-fill\' style=\'width:" + barWidthPct + "%;background:" + color + "\'></div>"
            + "</div>"
            + "<span class=\'sor-pct-label\'>" + fmtPct(c.percentage) + "</span>"
          + "</div>"
        + "</td>";

      tbody.appendChild(tr);
    }

    /* ---- Build chart data (ranked descending) ---- */
    var sorted = classes.slice().sort(function (a, b) { return b.sign_in_count - a.sign_in_count; });

    // Compute class diversity index (Shannon entropy, normalised 0-1)
    var totalPct = 0;
    for (var di = 0; di < classes.length; di++) totalPct += classes[di].percentage / 100;
    var entropy = 0;
    for (var di = 0; di < classes.length; di++) {
      var pp = classes[di].percentage / 100;
      if (pp > 0) entropy -= pp * Math.log2(pp);
    }
    var maxEntropy = classes.length > 1 ? Math.log2(classes.length) : 1;
    var diversityIdx = maxEntropy > 0 ? (entropy / maxEntropy).toFixed(2) : "0.00";
    // Inject diversity card before the table
    var divWrap = document.getElementById('sor-diversity-card-wrap');
    if (divWrap) {
      divWrap.innerHTML = '<div class="sor-diversity-card" id="sor-diversity-card">' +
        '<strong>Class Diversity Index:</strong> ' + diversityIdx +
        ' / 1.00 <span style="font-size:0.78rem;color:#888">(higher = more even spread across classes)</span>' +
        '</div>';
    }

    var chartCategories = [];
    var chartData = [];

    for (var j = 0; j < sorted.length; j++) {
      var cls = sorted[j];
      chartCategories.push(cls.class_name);
      chartData.push({
        y: cls.percentage,
        color: colorForClass(cls.class_name),
        borderColor: cls.inflated_note ? '#e67e22' : 'transparent',
        borderWidth: cls.inflated_note ? 2 : 0
      });
    }

    /* ---- Show content, hide skeleton (before chart so Highcharts can measure dimensions) ---- */
    document.getElementById("sor-classes-skeleton").style.display = "none";
    document.getElementById("sor-classes-content").style.display = "";

    /* ---- Render Highcharts bar chart ---- */
    // T-4: Guard: Highcharts availability check
    if (typeof Highcharts === 'undefined') {
      document.getElementById('sor-classes-chart').innerHTML = '<p style="color:#999;padding:20px">Chart unavailable.</p>';
    } else {
    window.sorDestroyChart('sor-classes-chart');
    new Highcharts.Chart({
      chart: {
        renderTo: "sor-classes-chart",
        type: "bar",
        height: Math.max(300, chartCategories.length * 28 + 80),
        style: { fontFamily: "inherit" },
        backgroundColor: "transparent",
        margin: [10, 80, 20, 130]
      },
      title: { text: null },
      credits: { enabled: false },
      legend: { enabled: false },
      xAxis: {
        categories: chartCategories,
        labels: { style: { fontSize: "11px", color: "#333" } },
        lineColor: "#ddd",
        tickColor: "#ddd"
      },
      yAxis: {
        title: { text: "% of Sign-Ins", style: { fontSize: "11px", color: "#777" } },
        gridLineColor: "#f0f0f0",
        labels: { formatter: function () { return this.value + "%"; },
                  style: { fontSize: "10px", color: "#777" } },
        min: 0
      },
      tooltip: {
        backgroundColor: "#1a1a2e",
        borderColor: "#c0392b",
        style: { color: "#fff" },
        formatter: function () {
          var note = this.point.borderWidth > 0
            ? '<br/><span style="color:#e67e22">&#9888; May be inflated</span>' : "";
          return "<b>" + this.x + "</b><br/>" + this.y.toFixed(1) + "% of sign-ins" + note;
        }
      },
      plotOptions: {
        bar: {
          borderRadius: 2,
          pointPadding: 0.05,
          groupPadding: 0.04,
          dataLabels: {
            enabled: true,
            formatter: function () { return this.y.toFixed(1) + "%"; },
            align: "right",
            inside: false,
            style: { fontSize: "10px", fontWeight: "600",
                     color: "#444", textShadow: "none" }
          }
        }
      },
      series: [{
        name: "Sign-In %",
        data: chartData
      }]
    });
    } // end Highcharts guard
  };

})();
