
$(function() {
	// Voting eligibility badge — loaded async so it doesn't block page render
	if (PnConfig.playerId) {
		$.getJSON(PnConfig.uir + 'PlayerAjax/voting_eligible/' + PnConfig.playerId, function(r) {
			if (r.status === 0 && r.eligible) {
				var sub = '';
				if (r.province_mode)     sub = r.province_eligible ? 'Province &amp; Kingdom' : 'Kingdom';
				else if (r.active_knight) sub = 'Active Knight';
				else if (r.active_member === false) sub = 'Contributing';
				var $sub = $('#pn-voting-badge-sub');
				if (sub) { $sub.html(sub).show(); }
				$('#pn-voting-badge').show();
			}
		});
	}

	// ---- Attendance lazy loading (fires immediately on page load) ----
	(function() {
		if (!PnConfig.playerId) return;
		$.getJSON(PnConfig.uir + 'PlayerAjax/attendance/' + PnConfig.playerId, function(r) {
			if (r.status !== 0) return;
			var att = r.attendance || [];
			var total = r.total || 0;

			// Update PnConfig for use by other modals/JS
			PnConfig.attendanceDates = att.map(function(a) { return a.Date || ''; }).filter(Boolean);
			PnConfig.canEditAnyAttendance = !!r.canEditAnyAttendance;
			PnConfig.lastClassId = att.length && att[0].ClassId ? parseInt(att[0].ClassId) : 0;

			// Update stat card and tab count
			var statEl = document.getElementById('pn-att-stat-count');
			if (statEl) statEl.textContent = total;
			var tabEl = document.getElementById('pn-att-tab-count');
			if (tabEl) tabEl.textContent = '(' + total + ')';
			var lastEl = document.getElementById('pn-att-last-class');
			if (lastEl) lastEl.textContent = r.lastClass || '—';

			// Re-render sparkline now that dates are populated
			if (typeof pnRenderSparkline === 'function') pnRenderSparkline();

			// ---- Inject "Reached Level 6" milestones into the timeline ----
			// We compute these client-side (instead of server-side) because they
			// need full attendance history, which is fetched async to keep the
			// initial page render fast. Honors the user's milestone toggle config.
			(function() {
				var msCfg = PnConfig.milestoneConfig || {};
				if (msCfg.level6 === 0) return; // disabled in user prefs
				var newestFirst = msCfg.newest_first === 1;
				var classList = PnConfig.classList || [];
				if (!classList.length || !att.length) return;

				// classId → { name, reconciled, history: [{date, credits}, ...] }
				var classData = {};
				classList.forEach(function(c) {
					classData[c.ClassId] = { name: c.ClassName, reconciled: parseInt(c.Reconciled || 0), history: [] };
				});
				// Credit rule (mirror GetPlayerClasses): at most ONE class credit per
				// calendar date, attributed to the earliest-entered (lowest AttendanceId)
				// sign-in on that date. The raw feed can hold several sign-ins per day
				// (multiple parks/classes); summing them all over-counted credits, which
				// pushed the Level-6 date earlier than reality and could even report a
				// level the player never actually reached.
				var bestByDate = {};
				att.forEach(function(a) {
					if (!a.Date || a.Date === '0000-00-00') return;
					var cid = parseInt(a.ClassId || 0);
					if (!cid) return;
					var aid = parseInt(a.AttendanceId || 0);
					var prev = bestByDate[a.Date];
					if (!prev || aid < prev.aid) {
						bestByDate[a.Date] = { aid: aid, cid: cid, date: a.Date, credits: parseFloat(a.Credits || 0) };
					}
				});
				Object.keys(bestByDate).forEach(function(d) {
					var rec = bestByDate[d];
					if (classData[rec.cid]) classData[rec.cid].history.push({ date: rec.date, credits: rec.credits });
				});

				var newMilestones = [];
				Object.keys(classData).forEach(function(cid) {
					var cd = classData[cid];
					if (!cd.history.length) return;
					cd.history.sort(function(a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; });
					var cum = cd.reconciled;
					for (var i = 0; i < cd.history.length; i++) {
						cum += cd.history[i].credits;
						if (cum >= 53) {
							newMilestones.push({ date: cd.history[i].date, name: cd.name });
							break;
						}
					}
				});
				if (!newMilestones.length) return;

				// Build a DOM node for one milestone matching the server template structure
				function fmtDate(iso) {
					var d = new Date(iso + 'T00:00:00');
					if (isNaN(d.getTime())) return iso;
					return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
				}
				function makeTlItem(date, desc) {
					var item = document.createElement('div');
					item.className = 'pn-tl-item';
					item.setAttribute('data-tl-date', date);
					var human = fmtDate(date);
					item.innerHTML = ''
						+ '<div class="pn-tl-left"><div class="pn-tl-date">' + human + '</div></div>'
						+ '<div class="pn-tl-node"><i class="fas fa-hat-wizard"></i></div>'
						+ '<div class="pn-tl-right">'
						+   '<div class="pn-tl-desc">' + $('<div>').text(desc).html() + '</div>'
						+   '<span class="pn-tl-date-mobile">' + human + '</span>'
						+ '</div>';
					return item;
				}
				function makeCmsItem(date, desc) {
					var item = document.createElement('div');
					item.className = 'pn-cms-item';
					item.setAttribute('data-tl-date', date);
					var d = new Date(date + 'T00:00:00');
					var my = isNaN(d.getTime()) ? date : (String(d.getMonth()+1).padStart(2,'0') + '/' + String(d.getFullYear()).slice(-2));
					item.innerHTML = ''
						+ '<i class="fas fa-hat-wizard pn-cms-icon"></i>'
						+ '<div class="pn-cms-line"><strong>' + my + '</strong> &ndash; ' + $('<div>').text(desc).html() + '</div>';
					return item;
				}

				function injectInto(container, itemSelector, factory) {
					if (!container) return;
					// Backfill data-tl-date on existing items (server template doesn't emit it).
					var existing = container.querySelectorAll(itemSelector);
					for (var k = 0; k < existing.length; k++) {
						if (existing[k].getAttribute('data-tl-date')) continue;
						var label = existing[k].querySelector('.pn-tl-date, .pn-cms-line strong');
						if (!label) continue;
						var txt = label.textContent.trim();
						// Compact label is "MM/YY" — assume day=01 for sort.
						var iso = null;
						var m = txt.match(/^(\d{2})\/(\d{2})$/);
						if (m) {
							var yr = parseInt(m[2]); yr += yr < 70 ? 2000 : 1900;
							iso = yr + '-' + m[1] + '-01';
						} else {
							var parsed = Date.parse(txt);
							if (!isNaN(parsed)) {
								var d2 = new Date(parsed);
								iso = d2.getFullYear() + '-' + String(d2.getMonth()+1).padStart(2,'0') + '-' + String(d2.getDate()).padStart(2,'0');
							}
						}
						if (iso) existing[k].setAttribute('data-tl-date', iso);
					}
					newMilestones.forEach(function(m) {
						var node = factory(m.date, 'Reached Level 6 in ' + m.name);
						var siblings = container.querySelectorAll(itemSelector);
						var inserted = false;
						for (var j = 0; j < siblings.length; j++) {
							var sd = siblings[j].getAttribute('data-tl-date') || '';
							if (sd && (newestFirst ? sd < m.date : sd > m.date)) {
								container.insertBefore(node, siblings[j]);
								inserted = true;
								break;
							}
						}
						if (!inserted) container.appendChild(node);
					});
				}

				// Center-timeline view (default) and compact-sidebar view (opt-in).
				injectInto(document.querySelector('.pn-timeline'), '.pn-tl-item', makeTlItem);
				injectInto(document.querySelector('.pn-cms-card'), '.pn-cms-item', makeCmsItem);

				// If we emitted an empty skeleton (no server-side milestones) and JS injected
				// any level6 items, hide the empty-state placeholder so it doesn't show alongside.
				var emptyTarget = document.getElementById('pn-timeline-empty-target');
				var emptyState = document.getElementById('pn-timeline-empty-state');
				if (emptyTarget && emptyState && emptyTarget.querySelector('.pn-tl-item')) {
					emptyState.style.display = 'none';
				}
			})();

			// ---- Attendance tab ----
			var body = document.getElementById('pn-attendance-body');
			if (body) {
				var canEditAny = !!r.canEditAnyAttendance;
				var parkAuth   = r.parkEditAuth || {};
				var esc = function(s) { return $('<div>').text(s || '').html(); };
				var uir = PnConfig.uir;
				if (!att.length) {
					body.innerHTML = '<div class="pn-empty">No attendance records</div>';
				} else {
					var html = '<table class="pn-table display" id="pn-attendance-table"><thead><tr>'
						+ '<th data-sorttype="date">Date</th><th data-sorttype="text">Kingdom</th>'
						+ '<th data-sorttype="text">Park</th><th data-sorttype="text">Event</th>'
						+ '<th data-sorttype="text">Class</th><th data-sorttype="numeric">Credits</th>'
						+ '<th data-sorttype="text">By</th>'
						+ (canEditAny ? '<th class="pn-nosort" style="width:52px;min-width:52px"></th>' : '')
						+ '</tr></thead><tbody>';
					att.forEach(function(d) {
						var pid = parseInt(d.ParkId) || 0;
						var eid = parseInt(d.EventId) || 0;
						var ecid = parseInt(d.EventCalendarDetailId) || 0;
						var dateLink = pid > 0
							? '<a href="' + uir + 'Attendance/park/' + pid + '&AttendanceDate=' + esc(d.Date) + '">' + esc(d.Date) + '</a>'
							: '<a href="' + uir + 'Event/detail/' + eid + '/' + ecid + '">' + esc(d.Date) + '</a>';
						var classLabel = (d.Flavor && d.Flavor.trim()) ? esc(d.Flavor) : esc(d.ClassName);
						var canEditThis = !!(parkAuth[pid] && eid === 0);
						// "By" cell: show the entry source. signin_link / self_reg
						// surface as labels (not a link to the player themselves —
						// that would be redundant and look like "John entered
						// John's credit"). manual shows the officer's name linked.
						var byCell;
						if (d.EntryMethod === 'signin_link') {
							byCell = '<em title="Player signed in via PM-issued QR / link" style="color:var(--ork-text-muted)">Self via Sign-in Link</em>';
						} else if (d.EntryMethod === 'self_reg') {
							byCell = '<em title="Awarded on account creation" style="color:var(--ork-text-muted)">Self-registration</em>';
						} else if (parseInt(d.EnteredById) > 0 && d.EnteredBy) {
							byCell = '<a href="' + uir + 'Player/profile/' + parseInt(d.EnteredById) + '">' + esc(d.EnteredBy) + '</a>';
						} else {
							byCell = '<span style="color:var(--ork-text-muted)">—</span>';
						}
						html += '<tr>'
							+ '<td class="pn-col-nowrap">' + dateLink + '</td>'
							+ '<td><a href="' + uir + 'Kingdom/profile/' + esc(d.KingdomId) + '">' + esc(d.KingdomName) + '</a></td>'
							+ '<td><a href="' + uir + 'Park/profile/' + pid + '">' + esc(d.ParkName) + '</a></td>'
							+ '<td>' + (eid > 0 ? '<a href="' + uir + 'Event/detail/' + eid + '/' + ecid + '">' + esc(d.EventName) + '</a>' : '') + '</td>'
							+ '<td>' + classLabel + '</td>'
							+ '<td class="pn-col-numeric">' + esc(d.Credits) + '</td>'
							+ '<td>' + byCell + '</td>';
						if (canEditAny) {
							html += '<td class="pn-award-actions-cell">';
							if (canEditThis) {
								html += '<button class="pn-award-action-btn pn-award-edit-btn pn-att-edit-btn"'
									+ ' data-att-id="' + parseInt(d.AttendanceId) + '"'
									+ ' data-date="' + esc(d.Date) + '"'
									+ ' data-credits="' + parseFloat(d.Credits) + '"'
									+ ' data-class-id="' + parseInt(d.ClassId) + '"'
									+ ' data-mundane-id="' + parseInt(d.MundaneId) + '"'
									+ ' title="Edit attendance"><i class="fas fa-pencil-alt"></i></button>'
									+ ' <button class="pn-award-action-btn pn-award-del-btn pn-att-del-btn"'
									+ ' data-att-id="' + parseInt(d.AttendanceId) + '"'
									+ ' data-mundane-id="' + parseInt(d.MundaneId) + '"'
									+ ' title="Delete attendance"><i class="fas fa-trash"></i></button>';
							}
							html += '</td>';
						}
						html += '</tr>';
					});
					body.innerHTML = html + '</tbody></table>';
					pnInitDataTable('#pn-attendance-table', { order: [[0, 'desc']], filename: 'Attendance' });
				}
			}

			// ---- My Amtgard sections (own profile only) ----
			if (!PnConfig.isOwnProfile) return;

			// Class Progress
			var cpBody = document.getElementById('pna-class-progress-body');
			if (cpBody) {
				var recentClassIds = [], seen = {};
				att.forEach(function(a) {
					var cid = parseInt(a.ClassId) || 0;
					if (cid > 0 && !seen[cid]) { seen[cid] = true; recentClassIds.push(cid); }
				});
				recentClassIds = recentClassIds.slice(0, 3);
				var classList = PnConfig.classList || [];
				var classMap = {};
				classList.forEach(function(c) { classMap[parseInt(c.ClassId)] = c; });
				var classToParagon = PnConfig.classToParagon || {};
				var heldAwardIds = {};
				(PnConfig.heldAwardIds || []).forEach(function(id) { heldAwardIds[parseInt(id)] = true; });
				var maClasses = recentClassIds.map(function(cid) { return classMap[cid]; }).filter(function(c) {
					return c && ((parseInt(c.Credits||0) + parseInt(c.Reconciled||0)) > 0);
				});
				if (!maClasses.length) { cpBody.innerHTML = ''; return; }
				var maHtml = '<div class="pna-card"><div class="pna-card-title"><i class="fas fa-shield-alt"></i> Class Progress <a class="pna-card-more" href="#" onclick="pnActivateTab(\'classes\');return false;">All &rarr;</a></div><div style="font-size:11px;color:#a0aec0;margin-bottom:6px;">Your recent classes&hellip;</div>';
				var thresholds = [0,5,12,21,34,53];
				maClasses.forEach(function(mc) {
					var total = parseInt(mc.Credits||0) + parseInt(mc.Reconciled||0);
					var lvl = total>=53?6:total>=34?5:total>=21?4:total>=12?3:total>=5?2:1;
					var pct = total>=53?100:Math.round((total/thresholds[lvl])*100);
					var isMax = total >= 53;
					var next = thresholds[lvl] || 53;
					var parId = classToParagon[parseInt(mc.ClassId)] || 0;
					var hasPar = parId > 0 && !!heldAwardIds[parId];
					maHtml += '<div class="pna-class-row">'
						+ '<div class="pna-class-header">'
						+ '<span class="pna-class-name">' + $('<div>').text(mc.ClassName||'').html() + (hasPar ? ' <span class="pna-paragon-dot" title="Paragon"><i class="fas fa-crown"></i></span>' : '') + '</span>'
						+ '<span class="pna-class-level">L' + lvl + (isMax ? ' <i class="fas fa-star" style="color:#dd6b20" title="Max level"></i>' : '') + '</span>'
						+ '</div>'
						+ '<div class="pna-bar-wrap"><div class="pna-bar' + (isMax?' pna-bar-max':'') + '" style="width:' + pct + '%"></div></div>'
						+ '<div class="pna-class-credits">' + total + ' cr' + (!isMax ? ' &middot; ' + next + ' for L' + (lvl+1) : '') + '</div>'
						+ '</div>';
				});
				cpBody.innerHTML = maHtml + '</div>';
			}

			// Recent Sign-ins
			var raBody = document.getElementById('pna-recent-att-body');
			if (raBody) {
				var cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 60);
				var cutStr = cutoff.getFullYear() + '-' + String(cutoff.getMonth()+1).padStart(2,'0') + '-' + String(cutoff.getDate()).padStart(2,'0');
				var recAtt = att.filter(function(a) { return a.Date && a.Date >= cutStr; }).slice(0, 5);
				var months2 = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
				var raHtml = '<div class="pna-card"><div class="pna-card-title"><i class="fas fa-calendar-check"></i> Recent Sign-ins <a class="pna-card-more" href="#" onclick="pnActivateTab(\'attendance\');return false;">All ' + total + ' &rarr;</a></div>';
				if (recAtt.length) {
					recAtt.forEach(function(ra) {
						var d2 = new Date(ra.Date + 'T00:00:00');
						var lbl = months2[d2.getMonth()] + ' ' + d2.getDate();
						raHtml += '<div class="pna-feed-row">'
							+ '<span class="pna-feed-date">' + lbl + '</span>'
							+ '<span class="pna-feed-label">' + $('<div>').text(ra.ClassName||'—').html() + '</span>'
							+ (ra.ParkName ? '<span class="pna-feed-sub">' + $('<div>').text(ra.ParkName).html() + '</span>' : '')
							+ '</div>';
					});
				} else {
					raHtml += '<div style="font-size:12px;color:#718096;line-height:1.5;">No recent sign-ins. Check out the next events and park days in your <a href="' + PnConfig.kingdomUrl + '" style="color:#4299e1;">kingdom</a>.</div>';
				}
				raBody.innerHTML = raHtml + '</div>';
			}
		});
	})();

	// ---- Dues history lazy loading ----
	function pnRenderDuesHtml(dues, isAdmin) {
		if (!dues || !dues.length) return '<div class="pn-dues-modal-empty">No dues records on file</div>';
		var html = '<table class="pn-dues-modal-table"><thead><tr><th>Park</th><th>From</th><th>Paid Through</th><th>Status</th>'
			+ (isAdmin ? '<th></th>' : '') + '</tr></thead><tbody>';
		dues.forEach(function(d) {
			var status;
			if (d.DuesForLife == 1) status = '<span class="pn-dues-life">Lifetime</span>';
			else if (d.Revoked) status = '<span style="color:#e53e3e">Revoked</span>';
			else if (d.DuesUntil && new Date(d.DuesUntil) < new Date()) status = '<span style="color:#999">Expired</span>';
			else status = '<span style="color:#38a169">Active</span>';
			var esc = function(s) { return $('<div>').text(s || '').html(); };
			html += '<tr>'
				+ '<td>' + esc(d.ParkName) + '</td>'
				+ '<td>' + esc(d.DuesFrom || '—') + '</td>'
				+ '<td>' + (d.DuesForLife == 1 ? '—' : esc(d.DuesUntil)) + '</td>'
				+ '<td>' + status + '</td>'
				+ (isAdmin ? '<td>' + (!d.Revoked ? '<button class="pn-dues-revoke-btn" data-dues-id="' + parseInt(d.DuesId) + '">Revoke</button>' : '') + '</td>' : '')
				+ '</tr>';
		});
		return html + '</tbody></table>';
	}
	var pnDuesCache = null;
	function pnLoadDuesInto(elId, isAdmin) {
		var el = document.getElementById(elId);
		if (!el) return;
		if (pnDuesCache !== null) { el.innerHTML = pnRenderDuesHtml(pnDuesCache, isAdmin); return; }
		$.getJSON(PnConfig.uir + 'PlayerAjax/all_dues/' + PnConfig.playerId, function(r) {
			pnDuesCache = (r.status === 0) ? (r.dues || []) : [];
			el.innerHTML = pnRenderDuesHtml(pnDuesCache, isAdmin);
		}).fail(function() { el.innerHTML = '<div class="pn-dues-modal-empty">Unable to load dues history.</div>'; });
	}
	if (typeof pnOpenDuesModal === 'function') {
		var _origDues = pnOpenDuesModal;
		pnOpenDuesModal = function() { _origDues(); pnLoadDuesInto('pn-dues-history-body', true); };
	}
	if (typeof pnOpenDuesHistoryModal === 'function') {
		var _origDuesH = pnOpenDuesHistoryModal;
		pnOpenDuesHistoryModal = function() { _origDuesH(); pnLoadDuesInto('pn-dues-history-modal-body', false); };
	}

	// ---- Notes lazy loading ----
	var pnNotesLoaded = false;
	function pnLoadNotes() {
		if (pnNotesLoaded) return;
		pnNotesLoaded = true;
		var body = document.getElementById('pn-notes-body');
		if (!body) return;
		$.getJSON(PnConfig.uir + 'PlayerAjax/notes/' + PnConfig.playerId, function(r) {
			var notes = (r.status === 0) ? (r.notes || []) : [];
			var countEl = document.getElementById('pn-notes-tab-count');
			if (countEl) countEl.textContent = '(' + notes.length + ')';
			// Infobox is PHP-rendered with notes=0 (lazy load), so swap it here once
			// we know the real count from the AJAX response.
			var _ihas = document.getElementById('pn-notes-infobox-has');
			var _inone = document.getElementById('pn-notes-infobox-none');
			if (_ihas)  _ihas.style.display  = notes.length > 0 ? '' : 'none';
			if (_inone) _inone.style.display = notes.length > 0 ? 'none' : '';
			if (!notes.length) { body.innerHTML = '<div class="pn-empty" id="pn-history-empty">No notes</div>'; return; }
			var esc = function(s) { return $('<div>').text(s || '').html(); };
			var html = '<table class="pn-table display" id="pn-history-table"><thead><tr><th data-sorttype="text">Note</th><th data-sorttype="text">Description</th><th data-sorttype="date">Date</th>'
				+ (PnConfig.canEditAdmin ? '<th class="pn-nosort" style="width:60px"></th>' : '') + '</tr></thead><tbody>';
			notes.forEach(function(n) {
				var nid = parseInt(n.NoteId) || 0;
				var dt = esc(n.Date || '');
				var dc = (n.DateComplete && n.DateComplete !== '0000-00-00') ? (' - ' + esc(n.DateComplete)) : '';
				html += '<tr data-notes-id="' + nid + '">'
					+ '<td>' + esc(n.Note) + '</td>'
					+ '<td>' + esc(n.Description) + '</td>'
					+ '<td class="pn-col-nowrap" data-order="' + esc(n.Date || '') + '">' + dt + dc + '</td>';
				if (PnConfig.canEditAdmin) {
					html += '<td class="pn-award-actions-cell">'
						+ '<button class="pn-award-action-btn pn-award-edit-btn pn-note-edit-btn"'
						+ ' data-notes-id="' + nid + '"'
						+ ' data-note="' + esc(n.Note).replace(/"/g, '&quot;') + '"'
						+ ' data-desc="' + esc(n.Description).replace(/"/g, '&quot;') + '"'
						+ ' data-date="' + esc(n.Date) + '"'
						+ ' data-date-complete="' + esc(n.DateComplete) + '"'
						+ ' title="Edit note"><i class="fas fa-pencil-alt"></i></button> '
						+ '<button class="pn-award-action-btn pn-award-del-btn pn-note-del-btn" data-notes-id="' + nid + '" title="Delete note"><i class="fas fa-trash"></i></button>'
						+ '</td>';
				}
				html += '</tr>';
			});
			body.innerHTML = html + '</tbody></table>';
			pnInitDataTable('#pn-history-table', { order: [[2, 'desc']], filename: 'Notes' });
		}).fail(function() { body.innerHTML = '<div class="pn-empty">Unable to load notes.</div>'; });
	}

	// ---- Recommendations lazy loading ----
	var pnRecsLoaded = false;
	function pnLoadRecs() {
		if (pnRecsLoaded) return;
		pnRecsLoaded = true;
		var body = document.getElementById('pn-recs-body');
		if (!body) return;
		$.getJSON(PnConfig.uir + 'PlayerAjax/recommendations/' + PnConfig.playerId, function(r) {
			if (r.status === 5) { body.innerHTML = '<div class="pn-empty">Log in to see recommendations.</div>'; return; }
			var allRecs = (r.status === 0 && r.recs) ? r.recs.filter(function(x) { return !x.AlreadyHas; }) : [];
			var myRecs  = allRecs.filter(function(x) { return x.RecommendedById == PnConfig.loggedInUserId; });
			var recList = PnConfig.showRecsTab ? allRecs : myRecs;
			var countEl = document.getElementById('pn-recs-tab-count');
			if (countEl) countEl.textContent = '(' + recList.length + ')';
			if (!recList.length) { body.innerHTML = '<div class="pn-empty">There are no open award recommendations for admin.</div>'; return; }
			var hasActions = PnConfig.loggedInUserId > 0;
			var esc = function(s) { return $('<div>').text(s || '').html(); };
			var attr = function(s) { return esc(s).replace(/"/g, '&quot;'); };
			var truncNotes = function(s) {
				var txt = s || '';
				if (txt.length <= 50) return esc(txt);
				return '<span class="pk-rec-notes-short">' + esc(txt.substring(0, 50))
					+ '<span class="pk-rec-notes-ellipsis">&hellip; <button class="pk-rec-expand-btn" type="button">[&hellip;]</button></span>'
					+ '<span class="pk-rec-notes-full" style="display:none">' + esc(txt.substring(50)) + ' <button class="pk-rec-expand-btn pk-rec-collapse-btn" type="button">[&laquo;]</button></span>'
					+ '</span>';
			};
			var html = '<table class="pn-table display" id="pn-rec-table"><thead><tr>'
				+ '<th>Award</th><th>Rank</th><th data-sorttype="date">Date</th><th>Sent By</th><th>Reason</th>'
				+ (hasActions ? '<th class="pn-nosort" style="white-space:nowrap;width:1%">Actions</th>' : '')
				+ '</tr></thead><tbody>';
			recList.forEach(function(rec) {
				var kaid  = parseInt(rec.KingdomAwardId) || 0;
				var recId = parseInt(rec.RecommendationsId) || 0;
				var mid   = parseInt(rec.MundaneId) || 0;
				var rank  = rec.Rank && parseInt(rec.Rank) > 0 ? parseInt(rec.Rank) : '';
				var secCount = parseInt(rec.SecondsCount) || 0;
				var canEditReason = !!rec.ViewerCanEditReason;
				var canSecond = !!rec.ViewerCanSecond;

				// Reason cell — text + (optional) edit-pencil + seconds list
				var reasonCell = esc(rec.Reason);
				if (canEditReason) {
					reasonCell += ' <button class="rs-edit-reason-btn" data-rec="' + recId + '" data-reason="' + attr(rec.Reason) + '" data-award="' + attr(rec.AwardName) + '" data-rstip="Edit your reason"><i class="fas fa-pen"></i></button>';
				}
				if (secCount > 0 && Array.isArray(rec.Seconds)) {
					reasonCell += '<div class="rs-seconds">';
					rec.Seconds.forEach(function(s) {
						var supLink = '<a class="rs-supporter" href="' + PnConfig.uir + 'Player/profile/' + parseInt(s.SupporterMundaneId) + '">' + esc(s.SupporterName) + '</a>';
						var notesPart = (s.Notes && s.Notes.length > 0)
							? '<span class="rs-notes">&mdash; "' + truncNotes(s.Notes) + '"</span>'
							: '';
						// Edit (pencil) is supporter-only — server gates EditSecondNotes that way.
						// Withdraw mirrors recommendation-delete: supporter OR anyone with
						// park-level rec-delete authority (PnConfig.canDeleteRec).
						// Wrap both in rs-second-actions so they always wrap as a unit.
						var actionButtons = '';
						if (s.IsMine) {
							actionButtons += '<button class="rs-second-edit" data-sid="' + parseInt(s.RecommendationSecondsId) + '" data-notes="' + attr(s.Notes) + '" data-rstip="Edit your notes"><i class="fas fa-pen"></i></button>';
						}
						if (s.IsMine || PnConfig.canDeleteRec) {
							var withdrawTip = s.IsMine ? 'Withdraw your second' : 'Remove this second';
							actionButtons += '<button class="rs-second-withdraw" data-sid="' + parseInt(s.RecommendationSecondsId) + '" data-supporter="' + attr(s.SupporterName) + '" data-rstip="' + withdrawTip + '"><i class="fas fa-times"></i></button>';
						}
						var secondButtons = actionButtons ? ' <span class="rs-second-actions">' + actionButtons + '</span>' : '';
						reasonCell += '<div class="rs-second"><i class="fas fa-thumbs-up" style="color:#48bb78;font-size:10px"></i>' + supLink + notesPart + secondButtons + '</div>';
					});
					reasonCell += '</div>';
				}

				html += '<tr data-rec-id="' + recId + '">'
					+ '<td>' + esc(rec.AwardName) + '</td>'
					+ '<td class="pn-col-numeric">' + rank + '</td>'
					+ '<td class="pn-col-nowrap">' + esc(rec.DateRecommended) + '</td>'
					+ '<td><a href="' + PnConfig.uir + 'Player/profile/' + parseInt(rec.RecommendedById) + '">' + esc(rec.RecommendedByName) + '</a></td>'
					+ '<td class="pk-rec-notes">' + reasonCell + '</td>';
				if (hasActions) {
					var actions = '';
					if (secCount > 0) {
						actions += '<span class="rs-seconds-badge" data-rstip="' + secCount + ' supporting ' + (secCount === 1 ? 'second' : 'seconds') + '"><i class="fas fa-thumbs-up"></i>' + secCount + '</span>';
					}
					if (canSecond) {
						actions += '<button class="rs-action-btn" data-rec="' + recId + '" data-award="' + attr(rec.AwardName) + '" data-recipient="' + attr(rec.Persona) + '" data-rstip="Second this recommendation and add your feedback."><i class="fas fa-plus"></i></button>';
					}
					if (PnConfig.canManageAwards && kaid > 0) {
						var rd = JSON.stringify({KingdomAwardId: kaid, Rank: parseInt(rec.Rank)||0, Reason: rec.Reason||'', AwardName: rec.AwardName||''});
						actions += '<button class="pk-btn pk-btn-primary pn-rec-grant-btn" data-rec="' + rd.replace(/"/g, '&quot;') + '"><i class="fas fa-medal"></i> Grant</button> ';
					}
					var canDel = PnConfig.canDeleteRec || rec.RecommendedById == PnConfig.loggedInUserId || mid == PnConfig.loggedInUserId;
					if (canDel) actions += '<button class="pk-rec-dismiss-btn pn-rec-dismiss-btn" data-href="' + PnConfig.uir + 'Player/profile/' + mid + '/deleterecommendation/' + recId + '"><i class="fas fa-times"></i> Delete</button>';
					html += '<td class="pk-rec-actions rs-tip-right" style="white-space:nowrap;text-align:right;width:1%">' + actions + '</td>';
				}
				html += '</tr>';
			});
			body.innerHTML = html + '</tbody></table>';
			pnInitDataTable('#pn-rec-table', { order: [[2, 'desc']], filename: 'Recommendations' });
		}).fail(function() { body.innerHTML = '<div class="pn-empty">Unable to load recommendations.</div>'; });
	}

	// Allow OrkRsCfg.reload (set above) to force a recs reload after seconds actions.
	window.pnReloadRecs = function() { pnRecsLoaded = false; pnLoadRecs(); };
	window.pnReloadNotes = function() { pnNotesLoaded = false; pnLoadNotes(); };

	// Hook tab clicks to trigger lazy loading
	$(document).on('click', '.pn-tab-nav li', function() {
		var tab = $(this).data('tab');
		if (tab === 'history')         pnLoadNotes();
		if (tab === 'recommendations') pnLoadRecs();
	});
});
initEmailSpellCheck('pn-acct-email', 'pn-acct-email-suggestion');
// Username availability check on the Update Account modal. currentValue
// prevents the player's existing username from being flagged as "taken"
// against their own row.
if (typeof initUsernameAvailabilityCheck === 'function' && document.getElementById('pn-acct-username')) {
	window.pnAcctUsernameCheck = initUsernameAvailabilityCheck({
		inputId:      'pn-acct-username',
		statusId:     'pn-acct-username-status',
		submitBtnId:  'pn-acct-save',
		endpointUrl:  'http://127.0.0.1:19080/orkui/index.php?Route=PlayerAjax/check_username',
		gateMode:     'soft',
		currentValue: "admin"	});
	// Reset on modal open so a stale "X is taken" from a previous edit
	// session doesn't linger when the modal is reopened.
	var _origPnOpenAcct = window.pnOpenAccountModal;
	if (typeof _origPnOpenAcct === 'function') {
		window.pnOpenAccountModal = function() {
			var r = _origPnOpenAcct.apply(this, arguments);
			if (window.pnAcctUsernameCheck && window.pnAcctUsernameCheck.reset) window.pnAcctUsernameCheck.reset();
			return r;
		};
	}
}
