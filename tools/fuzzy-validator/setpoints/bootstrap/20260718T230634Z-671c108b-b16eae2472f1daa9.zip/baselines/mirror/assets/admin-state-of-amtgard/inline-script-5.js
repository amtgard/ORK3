
(function () {
  'use strict';

  /* ----------------------------------------------------------------
     Internal state
  ---------------------------------------------------------------- */
  var _sorKingdomsData = [];
  var _sorSortCol      = 'rank';
  var _sorSortDir      = 'asc';
  var _sorHandlersSet  = false;

  /* ----------------------------------------------------------------
     Minimal HTML-escape helper
  ---------------------------------------------------------------- */
  function sorEsc(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ----------------------------------------------------------------
     Format integer with locale-aware thousands separators
  ---------------------------------------------------------------- */
  function sorFmt(n) {
    return parseInt(n, 10).toLocaleString();
  }

  /* ----------------------------------------------------------------
     Return CSS row class for top-5 medal styling
  ---------------------------------------------------------------- */
  function sorRankCls(rank) {
    var r = parseInt(rank, 10);
    return r >= 1 && r <= 5 ? 'sor-rank-' + r : '';
  }

  /* ----------------------------------------------------------------
     Render table body from a (pre-sorted) array of kingdom objects
  ---------------------------------------------------------------- */
  function sorKingdomYoyDelta(row) {
    if (row.yoy_change == null) return '<span style="color:#aaa">&mdash;</span>';
    var v = parseInt(row.yoy_change, 10);
    var clr = v > 0 ? '#27ae60' : (v < 0 ? '#c0392b' : '#888');
    var arrow = v > 0 ? '&#9650;' : (v < 0 ? '&#9660;' : '');
    return '<span style="color:' + clr + '">' + arrow + ' ' + Math.abs(v).toLocaleString('en-US') + '</span>';
  }

  function sorKingdomYoyPct(row) {
    if (row.yoy_pct_change == null) return '<span style="color:#aaa">&mdash;</span>';
    var v = parseFloat(row.yoy_pct_change);
    var clr = v > 0 ? '#27ae60' : (v < 0 ? '#c0392b' : '#888');
    var sign = v > 0 ? '+' : '';
    return '<span style="color:' + clr + '">' + sign + v.toFixed(1) + '%</span>';
  }

  function sorRenderTable(rows) {
    var tbody = document.getElementById('sor-kingdoms-tbody');
    if (!tbody) return;

    // Max pct for bar scaling
    var maxPct = 0.001;
    for (var i = 0; i < rows.length; i++) {
      var p = parseFloat(rows[i].percentage) || 0;
      if (p > maxPct) maxPct = p;
    }

    var html = '';
    for (var i = 0; i < rows.length; i++) {
      var r      = rows[i];
      var rank   = parseInt(r.rank, 10);
      var pct    = parseFloat(r.percentage) || 0;
      var barW   = Math.round((pct / maxPct) * 100);
      var cls    = sorRankCls(rank);

      html += '<tr' + (cls ? ' class="' + cls + '"' : '') + '>';
      html += '<td style="text-align:center"><span class="sor-rank-badge">' + rank + '</span></td>';
      html += '<td class="sor-kingdom-name-cell">' + sorEsc(r.kingdom_name) + '</td>';
      html += '<td class="sor-count-cell">' + sorFmt(r.sign_in_count) + '</td>';
      html += '<td class="sor-pct-cell">'
            +   '<span class="sor-pct-value">' + pct.toFixed(1) + '%</span>'
            +   '<div class="sor-pct-bar-track">'
            +     '<div class="sor-pct-bar-fill" style="width:' + barW + '%"></div>'
            +   '</div>'
            + '</td>';
      html += '<td style="text-align:right">' + sorKingdomYoyDelta(r) + '</td>';
      html += '<td style="text-align:right">' + sorKingdomYoyPct(r) + '</td>';
      html += '</tr>';
    }
    tbody.innerHTML = html;
  }

  /* ----------------------------------------------------------------
     Sort data by column + direction
  ---------------------------------------------------------------- */
  function sorSort(col, dir) {
    var copy = _sorKingdomsData.slice();
    copy.sort(function (a, b) {
      var av, bv;
      if (col === 'name') {
        av = String(a.kingdom_name).toLowerCase();
        bv = String(b.kingdom_name).toLowerCase();
        return dir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
      }
      if (col === 'sign_ins') {
        av = parseInt(a.sign_in_count, 10);
        bv = parseInt(b.sign_in_count, 10);
      } else if (col === 'percentage') {
        av = parseFloat(a.percentage);
        bv = parseFloat(b.percentage);
      } else if (col === 'yoy_change') {
        av = parseInt(a.yoy_change, 10) || 0;
        bv = parseInt(b.yoy_change, 10) || 0;
      } else if (col === 'yoy_pct') {
        av = parseFloat(a.yoy_pct_change) || 0;
        bv = parseFloat(b.yoy_pct_change) || 0;
      } else {
        // rank
        av = parseInt(a.rank, 10);
        bv = parseInt(b.rank, 10);
      }
      return dir === 'asc' ? av - bv : bv - av;
    });
    return copy;
  }

  /* ----------------------------------------------------------------
     Attach click-to-sort on table header cells (once)
  ---------------------------------------------------------------- */
  function sorAttachSort() {
    if (_sorHandlersSet) return;
    _sorHandlersSet = true;

    var ths = document.querySelectorAll('#sor-kingdoms-table thead th[data-col]');
    for (var i = 0; i < ths.length; i++) {
      (function (th) {
        th.addEventListener('click', function () {
          var col = th.getAttribute('data-col');
          if (_sorSortCol === col) {
            _sorSortDir = _sorSortDir === 'asc' ? 'desc' : 'asc';
          } else {
            _sorSortCol = col;
            _sorSortDir = col === 'rank' ? 'asc' : 'desc';
          }

          // Update header indicator classes
          var allThs = document.querySelectorAll('#sor-kingdoms-table thead th');
          for (var j = 0; j < allThs.length; j++) {
            allThs[j].classList.remove('sor-sort-asc', 'sor-sort-desc');
          }
          th.classList.add('sor-sort-' + _sorSortDir);

          sorRenderTable(sorSort(_sorSortCol, _sorSortDir));
        });
      }(ths[i]));
    }
  }

  /* ----------------------------------------------------------------
     Highcharts v3 horizontal bar chart
  ---------------------------------------------------------------- */
  function sorRenderChart(kingdoms) {
    // Alphabetical order for visual consistency
    var sorted = kingdoms.slice().sort(function (a, b) {
      return String(a.kingdom_name).localeCompare(String(b.kingdom_name));
    });

    var categories = [];
    var values     = [];
    for (var i = 0; i < sorted.length; i++) {
      categories.push(sorted[i].kingdom_name);
      values.push(parseFloat(sorted[i].percentage) || 0);
    }

    // Grow chart height proportionally to kingdom count
    var dynHeight = Math.max(300, categories.length * 32 + 80);
    var chartEl   = document.getElementById('sor-kingdoms-chart');
    if (chartEl) chartEl.style.height = dynHeight + 'px';

    // Highcharts v3 API (same as v4/v5 for these features)
    if (typeof Highcharts !== 'undefined') {
      window.sorDestroyChart('sor-kingdoms-chart');
      new Highcharts.Chart({
        chart: {
          renderTo:        'sor-kingdoms-chart',
          type:            'bar',
          backgroundColor: 'transparent',
          style:           { fontFamily: 'inherit' },
          animation:       { duration: 550 },
          marginRight:     60   // room for data labels
        },
        title:    { text: null },
        subtitle: { text: null },
        credits:  { enabled: false },
        exporting: { enabled: false },

        xAxis: {
          categories: categories,
          labels: {
            style:  { fontSize: '11px', color: window.sorThemeColor('--ork-text-secondary', '#4a5568') },
            reserveSpace: true
          },
          lineColor:  window.sorThemeColor('--ork-border', '#e2e8f0'),
          tickColor:  window.sorThemeColor('--ork-border', '#e2e8f0')
        },

        yAxis: {
          title: {
            text:  '% of Total Sign-Ins',
            style: { color: window.sorThemeColor('--ork-text-muted', '#718096'), fontSize: '11px' }
          },
          labels: {
            formatter: function () { return this.value + '%'; },
            style:     { fontSize: '11px', color: window.sorThemeColor('--ork-text-muted', '#718096') }
          },
          gridLineColor: window.sorThemeColor('--ork-border', '#edf2f7'),
          min: 0
        },

        legend: { enabled: true, align: "center", verticalAlign: "bottom",
                  itemStyle: { fontWeight: "600", fontSize: "12px", color: window.sorThemeColor('--ork-text', '#2d3748') } },

        tooltip: {
          formatter: function () {
            return '<b>' + this.x + '</b><br/>Share: <b>' + this.y.toFixed(1) + '%</b>';
          },
          backgroundColor: 'rgba(26,26,26,0.88)',
          style:           { color: '#fff' },
          borderWidth:     0,
          shadow:          false
        },

        plotOptions: {
          bar: {
            dataLabels: {
              enabled:   true,
              formatter: function () { return this.y.toFixed(1) + '%'; },
              style: {
                fontSize:   '11px',
                fontWeight: '600',
                color:      '#4a5568',
                textShadow: 'none'
              }
            },
            colorByPoint: true,
            borderWidth:  0,
            borderRadius: 2,
            pointPadding: 0.06,
            groupPadding: 0.04
          }
        },

        /* 20-color cycle — uses Amtgard-friendly reds/blues then broadens out */
        colors: [
          '#c0392b','#2980b9','#27ae60','#8e44ad','#f39c12',
          '#16a085','#d35400','#2c3e50','#1abc9c','#e74c3c',
          '#3498db','#2ecc71','#9b59b6','#f1c40f','#e67e22',
          '#117a65','#6c3483','#1a252f','#784212','#922b21'
        ],

        series: [{
          name: 'Sign-In Share',
          data: values
        }]
      });
    } else {
      document.getElementById('sor-kingdoms-chart').innerHTML = '<p style="color:#999;padding:20px;text-align:center">Chart unavailable.</p>';
    }
  }

  /* ----------------------------------------------------------------
     PUBLIC: renderSorKingdoms(data)
     Called by the report page orchestrator once AJAX resolves.
  ---------------------------------------------------------------- */
  window.renderSorKingdoms = function (data) {
    var skeleton = document.getElementById('sor-kingdoms-skeleton');
    var content  = document.getElementById('sor-kingdoms-content');

    // Guard: bad payload
    if (!data || !Array.isArray(data.kingdoms) || data.kingdoms.length === 0) {
      if (skeleton) skeleton.style.display = 'none';
      if (content) {
        content.style.display = '';
        content.innerHTML = '<p style="color:#999;padding:30px;text-align:center"><i class="fas fa-info-circle"></i> No data available for the selected period and kingdoms.</p>';
      }
      return;
    }

    _sorKingdomsData = data.kingdoms;

    // 1. Hide skeleton, reveal content
    if (skeleton) skeleton.style.display = 'none';
    if (content)  content.style.display  = '';

    // 2. Hook up column-sort clicks
    sorAttachSort();

    // 3. Render table sorted by rank ascending (default)
    sorRenderTable(sorSort('rank', 'asc'));

    // 4. Render Highcharts bar chart
    sorRenderChart(data.kingdoms);
  };

}());
