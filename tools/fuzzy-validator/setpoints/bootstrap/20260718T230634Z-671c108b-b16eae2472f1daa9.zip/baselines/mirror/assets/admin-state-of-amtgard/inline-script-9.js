
(function () {
  'use strict';

  var LON_COLORS = [
    '#3498db', '#2ecc71', '#e67e22', '#9b59b6',
    '#1abc9c', '#e74c3c', '#f39c12'
  ];

  window.renderSorLongevity = function (data) {
    var skeleton = null; // no dedicated longevity skeleton
    var content  = document.getElementById('sor-players-longevity');
    function showContainer() {
      if (skeleton) skeleton.style.display = 'none';
      if (content)  content.style.display  = '';
    }
    if (!data || !data.longevity) { return; }
    var buckets = data.longevity;
    var total   = 0;
    buckets.forEach(function (b) { total += (b.count || 0); });
    if (total === 0) { return; }

    // Build pie series data
    var pieData = buckets
      .filter(function (b) { return b.count > 0; })
      .map(function (b, i) {
        return {
          name:  b.label,
          y:     b.count,
          color: LON_COLORS[i % LON_COLORS.length]
        };
      });

    // Build legend HTML
    var legendHtml = '';
    pieData.forEach(function (d) {
      var pct = total > 0 ? ((d.y / total) * 100).toFixed(1) : '0';
      legendHtml +=
        '<div class="sor-lon-legend-item">' +
          '<div class="sor-lon-swatch" style="background:' + d.color + '"></div>' +
          '<span class="sor-lon-label">' + d.name + '</span>' +
          '<span class="sor-lon-count">' + d.y.toLocaleString('en-US') + '</span>' +
          '<span class="sor-lon-pct">&nbsp;' + pct + '%</span>' +
        '</div>';
    });
    var legendEl = document.getElementById('sor-longevity-legend');
    if (legendEl) legendEl.innerHTML = legendHtml;

    // Show container BEFORE Highcharts renders so it can measure dimensions (error #13)
    // Ensure the parent players-content is visible before showing longevity
    var playersContent = document.getElementById('sor-players-content');
    if (playersContent) playersContent.style.display = '';
    showContainer();

    // Draw pie chart (Highcharts v3 API)
    if (typeof Highcharts !== 'undefined') {
      window.sorDestroyChart('sor-longevity-chart');
      new Highcharts.Chart({
        chart: {
          renderTo: 'sor-longevity-chart',
          type: 'pie',
          height: 320,
          backgroundColor: 'transparent',
          style: { fontFamily: 'inherit' }
        },
        title:   { text: null },
        credits: { enabled: false },
        legend:  { enabled: false },
        tooltip: {
          backgroundColor: '#1a1a2e',
          borderColor:     '#2980b9',
          borderRadius:    6,
          style:           { color: '#fff', fontSize: '12px' },
          formatter: function () {
            var pct = total > 0 ? ((this.y / total) * 100).toFixed(1) : '0';
            return '<b>' + this.point.name + '</b><br/>' +
                   this.y.toLocaleString('en-US') + ' players (' + pct + '%)';
          }
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            innerSize: '40%',
            dataLabels: {
              enabled: true,
              distance: 16,
              formatter: function () {
                var pct = total > 0 ? ((this.y / total) * 100).toFixed(1) : '0';
                return '<b>' + this.point.name + '</b><br/>' + pct + '%';
              },
              style: { fontSize: '11px', fontWeight: '600', textShadow: 'none', color: window.sorThemeColor('--ork-text', '#333') }
            }
          }
        },
        series: [{ name: 'Players', data: pieData }]
      });
    }
  };

}());
