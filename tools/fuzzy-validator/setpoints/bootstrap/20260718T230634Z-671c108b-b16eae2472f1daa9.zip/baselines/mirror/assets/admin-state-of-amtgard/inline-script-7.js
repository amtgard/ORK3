
(function () {

  /* ------------------------------------------------------------------ */
  /* State                                                                */
  /* ------------------------------------------------------------------ */
  var _sorParksTableData    = [];
  var _sorParksTableSortCol = 0;
  var _sorParksTableSortAsc = true;

  /* ------------------------------------------------------------------ */
  /* Public entry point — called by parent page after AJAX completes      */
  /* ------------------------------------------------------------------ */
  window.renderSorParks = function (data) {
    var skeleton = document.getElementById('sor-parks-skeleton');
    var content  = document.getElementById('sor-parks-content');
    function showError(msg) {
      if (skeleton) skeleton.style.display = 'none';
      if (content)  content.style.display = '';
      var bar = document.getElementById('sor-parks-stats-bar');
      if (bar) bar.innerHTML = '<p style="color:#c0392b;padding:20px">' + msg + '</p>';
    }
    if (!data || !data.parks) { showError('Error loading parks data.'); return; }
    var d = data.parks;
    // Show content BEFORE charts so Highcharts can measure container dimensions (error #13)
    if (skeleton) skeleton.style.display = 'none';
    if (content)  content.style.display  = '';
    try {
      sorParksRenderStats(d);
      sorParksRenderNarrative(d);
      sorParksRenderExpandable('new',  d.new_parks  || [], d.new_by_kingdom  || []);
      sorParksRenderExpandable('lost', d.lost_parks || [], d.lost_by_kingdom || []);
      sorParksRenderRiskAlert(d.downward_trend_parks || []);
      sorParksRenderTable(d.parks_by_kingdom || []);
      sorParksRenderChart(d.parks_by_kingdom || []);
      sorParksRenderNetChart(d);
      sorParksRenderHealthChart(d.parks_by_kingdom || []);
    } catch (e) {
      console.error('Parks render error:', e);
      showError('Parks render error: ' + (e && e.message ? e.message : String(e)));
      return;
    }
  };

  /* ------------------------------------------------------------------ */
  /* 1. Stats bar                                                         */
  /* ------------------------------------------------------------------ */
  function sorParksRenderStats(d) {
    var atRisk  = (d.downward_trend_parks || []).length;
    var netPark = (d.new_parks_count || 0) - (d.lost_parks_count || 0);
    var netMod  = netPark > 0 ? 'sor-parks-stat-new' : (netPark < 0 ? 'sor-parks-stat-lost' : '');
    var netVal  = (netPark > 0 ? '+' : '') + netPark;
    var cards = [
      { label: 'Total Active Parks', value: d.total_active      || 0, mod: '' },
      { label: 'Avg Parks / Kingdom',value: d.avg_per_kingdom   || 0, mod: '' },
      { label: 'Net Park Change',    value: netVal,                   mod: netMod },
      { label: 'New in Period',      value: d.new_parks_count   || 0, mod: 'sor-parks-stat-new' },
      { label: 'Lost in Period',     value: d.lost_parks_count  || 0, mod: 'sor-parks-stat-lost' },
      { label: 'At Risk',            value: atRisk,                   mod: 'sor-parks-stat-risk' }
    ];
    var html = '';
    cards.forEach(function (c) {
      html += '<div class="sor-parks-stat-card ' + c.mod + '">' +
                '<div class="sor-parks-stat-value">' + c.value + '</div>' +
                '<div class="sor-parks-stat-label">'  + c.label + '</div>' +
              '</div>';
    });
    document.getElementById('sor-parks-stats-bar').innerHTML = html;
  }

  /* ------------------------------------------------------------------ */
  /* 2. Narrative paragraph                                               */
  /* ------------------------------------------------------------------ */
  function sorParksRenderNarrative(d) {
    var newCount  = d.new_parks_count  || 0;
    var lostCount = d.lost_parks_count || 0;
    var newByKd   = d.new_by_kingdom   || [];
    var lostByKd  = d.lost_by_kingdom  || [];

    var lines = [];

    /* Opener */
    lines.push(
      '<strong>' + newCount  + ' new park'  + (newCount  !== 1 ? 's' : '') + '</strong> were founded and ' +
      '<strong>' + lostCount + ' park' + (lostCount !== 1 ? 's' : '') + '</strong> were lost during this period.'
    );

    /* New parks by kingdom */
    if (newByKd.length) {
      var parts = newByKd.map(function (k) {
        return '<strong>' + sorEsc(k.count) + '</strong> new park' +
               (k.count !== 1 ? 's were' : ' was') +
               ' founded in <strong>' + sorEsc(k.kingdom_name) + '</strong>';
      });
      lines.push(parts.join('; ') + '.');
    }

    /* Lost parks by kingdom */
    if (lostByKd.length) {
      var lparts = lostByKd.map(function (k) {
        return '<strong>' + sorEsc(k.count) + '</strong> park' +
               (k.count !== 1 ? 's were' : ' was') +
               ' lost in <strong>' + sorEsc(k.kingdom_name) + '</strong>';
      });
      lines.push(lparts.join('; ') + '.');
    }

    document.getElementById('sor-parks-narrative').innerHTML =
      lines.map(function (l) { return '<p>' + l + '</p>'; }).join('');
  }

  /* ------------------------------------------------------------------ */
  /* 2b. Expandable new / lost lists                                      */
  /* ------------------------------------------------------------------ */
  function sorParksRenderExpandable(type, parks, byKingdom) {
    var labelEl   = document.getElementById('sor-parks-' + type + '-toggle-label');
    var bodyEl    = document.getElementById('sor-parks-' + type + '-body');
    var pillClass = (type === 'new') ? 'sor-parks-pill-new' : 'sor-parks-pill-lost';
    var count     = parks.length;
    var verb      = (type === 'new') ? 'new' : 'lost';

    if (labelEl) {
      labelEl.textContent = 'Show ' + count + ' ' + verb + ' park' + (count !== 1 ? 's' : '');
    }

    /* Group by kingdom — preserve insertion order */
    var grouped = {};
    var order   = [];
    parks.forEach(function (p) {
      var kd = p.kingdom_name || 'Unknown';
      if (!grouped[kd]) { grouped[kd] = []; order.push(kd); }
      grouped[kd].push(p.park_name);
    });

    var html = '';
    order.forEach(function (kd) {
      html += '<div class="sor-parks-kingdom-group">' +
                '<div class="sor-parks-kingdom-label">' + sorEsc(kd) + '</div>' +
                '<ul class="sor-parks-park-list">';
      grouped[kd].forEach(function (name) {
        html += '<li><span class="sor-parks-park-pill ' + pillClass + '">' + sorEsc(name) + '</span></li>';
      });
      html += '</ul></div>';
    });

    if (bodyEl) {
      bodyEl.innerHTML = html ||
        '<em style="color:#888;font-size:0.85rem">No parks to display.</em>';
    }
  }

  /* Public toggle — called from inline onclick */
  window.sorParksToggle = function (type) {
    var headerEl = document.getElementById('sor-parks-' + type + '-toggle');
    var bodyEl   = document.getElementById('sor-parks-' + type + '-body');
    if (!headerEl || !bodyEl) { return; }
    var isOpen = bodyEl.classList.contains('sor-parks-visible');
    bodyEl.classList.toggle('sor-parks-visible', !isOpen);
    headerEl.classList.toggle('sor-parks-open', !isOpen);
  };

  /* ------------------------------------------------------------------ */
  /* 3. At-risk alert box                                                 */
  /* ------------------------------------------------------------------ */
  function sorParksRenderRiskAlert(parks) {
    var el = document.getElementById('sor-parks-risk-alert');
    if (!parks || parks.length === 0) { el.innerHTML = ''; return; }

    var rows = parks.map(function (p) {
      var r      = parseFloat(p.spearman_r) || 0;
      var rLabel = r.toFixed(2);
      var badge  = (r < -0.8)
        ? '<span class="sor-parks-risk-badge sor-parks-risk-high">High</span>'
        : '<span class="sor-parks-risk-badge sor-parks-risk-med">Moderate</span>';
      var rSpan  = '<span style="font-size:0.75rem;color:#888;margin-left:4px">r\u00a0=\u00a0' + rLabel + '</span>';
      // Build compact year-by-year sparkline text
      var trendHtml = '&mdash;';
      if (p.trend_years && p.trend_years.length) {
        var maxC = Math.max.apply(null, p.trend_years.map(function(y){return y.count;})) || 1;
        trendHtml = p.trend_years.map(function (y) {
          var ht = Math.max(4, Math.round((y.count / maxC) * 24));
          var clr = y.count <= 5 ? '#e74c3c' : (y.count <= 12 ? '#e67e22' : '#7f8c8d');
          return '<span title="' + y.year + ': ' + y.count + ' sign-ins" style="display:inline-block;width:10px;height:' + ht + 'px;background:' + clr + ';margin:0 1px;vertical-align:bottom;border-radius:2px 2px 0 0"></span>';
        }).join('');
        trendHtml = '<span style="display:inline-flex;align-items:flex-end;height:26px;gap:0">' + trendHtml + '</span>';
      }
      return '<tr>' +
               '<td>' + sorEsc(p.park_name)    + '</td>' +
               '<td>' + sorEsc(p.kingdom_name) + '</td>' +
               '<td style="text-align:right">' +
                 (p.last_year_count != null ? p.last_year_count : '&mdash;') +
               '</td>' +
               '<td style="text-align:center">' + trendHtml + '</td>' +
               '<td style="text-align:center">' + badge + rSpan + '</td>' +
             '</tr>';
    }).join('');

    el.innerHTML =
      '<div class="sor-parks-alert">' +
        '<div class="sor-parks-alert-title">&#9888; At-Risk Parks (' + parks.length + ')</div>' +
        '<div class="sor-parks-alert-subtitle">' +
          'Parks with a statistically declining sign-in trend (Spearman r &lt; &minus;0.5) over the past 5 years, ' +
          'with &le;20 sign-ins in the most recent year. ' +
          '<strong>High risk</strong> = r &lt; &minus;0.8 (steep decline). ' +
          '<strong>Moderate</strong> = &minus;0.8 &le; r &lt; &minus;0.5 (moderate decline).' +
        '</div>' +
        '<table class="sor-parks-risk-table">' +
          '<thead><tr>' +
            '<th>Park</th>' +
            '<th>Kingdom</th>' +
            '<th style="text-align:right">Recent Sign-Ins</th>' +
            '<th style="text-align:center">Year-by-Year</th>' +
            '<th style="text-align:center">Risk Level</th>' +
          '</tr></thead>' +
          '<tbody>' + rows + '</tbody>' +
        '</table>' +
      '</div>';
  }

  /* ------------------------------------------------------------------ */
  /* 4. Parks by Kingdom table                                            */
  /* ------------------------------------------------------------------ */
  function sorParksRenderTable(rows) {
    _sorParksTableData = rows.slice();
    /* Default sort: kingdom name A-Z */
    _sorParksTableSortCol = 0;
    _sorParksTableSortAsc = true;
    sorParksSortAndRender();
  }

  window.sorParksSort = function (col) {
    if (_sorParksTableSortCol === col) {
      _sorParksTableSortAsc = !_sorParksTableSortAsc;
    } else {
      _sorParksTableSortCol = col;
      _sorParksTableSortAsc = (col !== 1 && col !== 2 && col !== 3); /* numeric cols default desc */
    }
    sorParksSortAndRender();
  };

  function sorParksSortAndRender() {
    var col = _sorParksTableSortCol;
    var asc = _sorParksTableSortAsc;

    var sorted = _sorParksTableData.slice().sort(function (a, b) {
      var va, vb;
      switch (col) {
        case 1:
          va = +(a.active_parks  || 0);
          vb = +(b.active_parks  || 0);
          break;
        case 2:
          va = +(a.retired_parks || 0);
          vb = +(b.retired_parks || 0);
          break;
        case 3:
          va = parseFloat(a.ratio);
          vb = parseFloat(b.ratio);
          if (isNaN(va)) { va = -Infinity; }
          if (isNaN(vb)) { vb = -Infinity; }
          break;
        default:
          va = (a.kingdom_name || '').toLowerCase();
          vb = (b.kingdom_name || '').toLowerCase();
      }
      if (va < vb) { return asc ? -1 :  1; }
      if (va > vb) { return asc ?  1 : -1; }
      return 0;
    });

    var html = sorted.map(function (r) {
      var ratio    = parseFloat(r.ratio);
      var ratioStr = isNaN(ratio) ? '&mdash;' : ratio.toFixed(1);
      var ratioCls = isNaN(ratio)
        ? 'sor-parks-ratio-neutral'
        : (ratio >= 1 ? 'sor-parks-ratio-good' : 'sor-parks-ratio-bad');

      return '<tr>' +
               '<td>' + sorEsc(r.kingdom_name || '') + '</td>' +
               '<td style="text-align:right">' + (r.active_parks  || 0) + '</td>' +
               '<td style="text-align:right">' + (r.retired_parks || 0) + '</td>' +
               '<td style="text-align:right" class="' + ratioCls + '">' + ratioStr + '</td>' +
             '</tr>';
    }).join('');

    document.getElementById('sor-parks-table-body').innerHTML = html;

    /* Update sort-arrow classes on headers */
    var ths = document.querySelectorAll('#sor-parks-kingdom-table thead th');
    ths.forEach(function (th, i) {
      th.classList.remove('sor-parks-sort-asc', 'sor-parks-sort-desc');
      if (i === col) {
        th.classList.add(asc ? 'sor-parks-sort-asc' : 'sor-parks-sort-desc');
      }
    });
  }

  /* ------------------------------------------------------------------ */
  /* 5. Grouped bar chart (Highcharts)                                    */
  /* ------------------------------------------------------------------ */
  function sorParksRenderChart(rows) {
    var container = document.getElementById('sor-parks-chart-container');
    if (typeof Highcharts === 'undefined') {
      container.innerHTML =
        '<p style="padding:16px;color:#888;font-size:0.85rem">' +
          'Chart unavailable (Highcharts not loaded).' +
        '</p>';
      return;
    }

    /* Sort alphabetically by kingdom name */
    var sorted = rows.slice().sort(function (a, b) {
      return (a.kingdom_name || '').localeCompare(b.kingdom_name || '');
    });

    var categories  = sorted.map(function (r) { return r.kingdom_name || ''; });
    var activeData  = sorted.map(function (r) { return +(r.active_parks  || 0); });
    var retiredData = sorted.map(function (r) { return +(r.retired_parks || 0); });

    /* Dynamically widen container if many kingdoms */
    var minWidth = Math.max(600, categories.length * 60);
    container.style.width = minWidth + 'px';

    window.sorDestroyChart('sor-parks-chart-container');
    new Highcharts.Chart({

      chart: {
        renderTo: 'sor-parks-chart-container',
        type: 'column',
        height: 350,
        backgroundColor: 'transparent',
        style: { fontFamily: 'inherit' },
        marginBottom: 90
      },
      title:    { text: null },
      subtitle: { text: null },
      credits:  { enabled: false },
      legend: {
        enabled: true,
        align: 'right',
        verticalAlign: 'top',
        itemStyle: { fontWeight: '600', fontSize: '12px' }
      },
      xAxis: {
        categories: categories,
        labels: {
          rotation: -45,
          style: { fontSize: '11px', color: window.sorThemeColor('--ork-text-secondary', '#555') },
          align: 'right'
        },
        crosshair: { color: 'rgba(44,95,110,0.1)' }
      },
      yAxis: {
        min: 0,
        allowDecimals: false,
        title: {
          text: 'Number of Parks',
          style: { fontSize: '11px', color: window.sorThemeColor('--ork-text-muted', '#666') }
        },
        gridLineColor: window.sorThemeColor('--ork-border', '#f0f0f0'),
        labels: { style: { fontSize: '11px', color: window.sorThemeColor('--ork-text-muted', '#666') } }
      },
      tooltip: {
        shared: true,
        headerFormat: '<b>{point.key}</b><br/>',
        pointFormat: '<span style="color:{point.color}">●</span> {series.name}: <b>{point.y}</b><br/>'
      },
      plotOptions: {
        column: {
          grouping: true,
          borderWidth: 0,
          borderRadius: 2,
          pointPadding: 0.1,
          groupPadding: 0.15
        }
      },
      series: [
        { name: 'Active',  data: activeData,  color: '#2c8a7a' },
        { name: 'Retired', data: retiredData, color: '#e57373' }
      ]
    });
  }

  /* ------------------------------------------------------------------ */
  /* 5b. Net Park Change diverging chart                                  */
  /* ------------------------------------------------------------------ */
  function sorParksRenderNetChart(d) {
    var container = document.getElementById('sor-parks-net-chart');
    if (!container) return;
    if (typeof Highcharts === 'undefined') {
      container.innerHTML = '<p style="padding:12px;color:#888">Chart unavailable.</p>';
      return;
    }
    var newMap = {}, lostMap = {};
    (d.new_by_kingdom  || []).forEach(function (k) { newMap[k.kingdom_name]  = k.count; });
    (d.lost_by_kingdom || []).forEach(function (k) { lostMap[k.kingdom_name] = k.count; });
    var allKd = {};
    (d.new_by_kingdom  || []).forEach(function (k) { allKd[k.kingdom_name] = 1; });
    (d.lost_by_kingdom || []).forEach(function (k) { allKd[k.kingdom_name] = 1; });
    var kds = Object.keys(allKd).sort();
    if (kds.length === 0) { container.innerHTML = '<p style="padding:12px;color:#888;text-align:center">No new or lost parks this period.</p>'; return; }
    var netData = kds.map(function (kd) {
      var net = (newMap[kd] || 0) - (lostMap[kd] || 0);
      return { y: net, color: net > 0 ? '#27ae60' : (net < 0 ? '#c0392b' : '#aaa') };
    });
    window.sorDestroyChart('sor-parks-net-chart');
    new Highcharts.Chart({

      chart: { renderTo: 'sor-parks-net-chart', type: 'column', height: 220, backgroundColor: 'transparent', style: { fontFamily: 'inherit' } },
      title:   { text: null }, credits: { enabled: false }, legend: { enabled: false },
      xAxis: { categories: kds, labels: { rotation: -45, style: { fontSize: '10px' }, align: 'right' } },
      yAxis:   { title: { text: 'Net (New − Lost)' }, allowDecimals: false,
                 plotLines: [{ value: 0, color: window.sorThemeColor('--ork-text', '#2d3748'), width: 1.5, zIndex: 4 }] },
      tooltip: { backgroundColor: '#1a1a2e', borderColor: '#c0392b', style: { color: '#fff' },
                 formatter: function () {
                   return '<b>' + this.x + '</b><br/>Net: <b>' + (this.y >= 0 ? '+' : '') + this.y + '</b>';
                 }},
      plotOptions: { column: { borderWidth: 0, borderRadius: 2,
                               dataLabels: { enabled: true, style: { fontSize: '10px', textShadow: 'none' },
                                            formatter: function () { return (this.y > 0 ? '+' : '') + this.y; } } } },
      series: [{ name: 'Net Change', data: netData }]
    });
  }

  /* ------------------------------------------------------------------ */
  /* 5c. Parks health stacked horizontal bar                              */
  /* ------------------------------------------------------------------ */
  function sorParksRenderHealthChart(rows) {
    var container = document.getElementById('sor-parks-health-chart');
    if (!container) return;
    if (typeof Highcharts === 'undefined') {
      container.innerHTML = '<p style="padding:12px;color:#888">Chart unavailable.</p>';
      return;
    }
    var sorted = rows.slice().sort(function (a, b) {
      return (b.active_parks || 0) - (a.active_parks || 0);
    });
    var cats   = sorted.map(function (r) { return r.kingdom_name || ''; });
    var actD   = sorted.map(function (r) { return +(r.active_parks  || 0); });
    var retD   = sorted.map(function (r) { return +(r.retired_parks || 0); });
    window.sorDestroyChart('sor-parks-health-chart');
    new Highcharts.Chart({

      chart: { renderTo: 'sor-parks-health-chart', type: 'bar', height: Math.max(320, cats.length * 22 + 100),
               backgroundColor: 'transparent', style: { fontFamily: 'inherit' } },
      title: { text: null }, credits: { enabled: false },
      legend: { enabled: true, align: 'right', verticalAlign: 'top' },
      xAxis: { categories: cats, labels: { style: { fontSize: '11px' } } },
      yAxis: { min: 0, allowDecimals: false, title: { text: 'Total Parks' } },
      tooltip: { shared: true, backgroundColor: '#1a1a2e', borderColor: '#c0392b',
                 style: { color: '#fff' },
                 formatter: function () {
                   var pts = this.points;
                   var act = pts[0] ? pts[0].y : 0, ret = pts[1] ? pts[1].y : 0;
                   var ratio = ret > 0 ? (act / ret).toFixed(1) + ':1' : 'N/A';
                   return '<b>' + this.x + '</b><br/>'
                     + '<span style="color:#27ae60">&#9679;</span> Active: <b>' + act + '</b><br/>'
                     + '<span style="color:#e57373">&#9679;</span> Retired: <b>' + ret + '</b><br/>'
                     + 'Ratio: <b>' + ratio + '</b>';
                 }},
      plotOptions: { bar: { stacking: 'normal', borderWidth: 0,
                            dataLabels: { enabled: true,
                                         formatter: function () { return this.y > 2 ? this.y : null; },
                                         style: { fontSize: '10px', color: '#fff', textShadow: 'none' } } } },
      series: [
        { name: 'Active',  data: actD, color: '#27ae60' },
        { name: 'Retired', data: retD, color: '#e57373' }
      ]
    });
  }

  /* ------------------------------------------------------------------ */
  /* Utility: HTML-escape                                                 */
  /* ------------------------------------------------------------------ */
  // FIX D: destroy any existing Highcharts instance rendered into the given container
  // before re-rendering, so repeated 'Generate Report' clicks don't stack charts.
  function sorDestroyChart(containerId) {
    if (typeof Highcharts === 'undefined' || !Highcharts.charts) return;
    for (var i = 0; i < Highcharts.charts.length; i++) {
      var c = Highcharts.charts[i];
      if (c && c.renderTo && c.renderTo.id === containerId) {
        try { c.destroy(); } catch (e) { /* swallow */ }
      }
    }
    var el = document.getElementById(containerId);
    if (el) el.innerHTML = '';
  }
  window.sorDestroyChart = sorDestroyChart;

  function sorEsc(str) {
    if (str == null) { return ''; }
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

})();
