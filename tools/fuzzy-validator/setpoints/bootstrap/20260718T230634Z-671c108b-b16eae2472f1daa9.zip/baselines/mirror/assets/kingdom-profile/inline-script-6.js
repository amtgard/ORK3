
// ---- Events: Load-more (next 12-month window) ----
function knLoadMoreEvents(ev) {
	if (ev) ev.preventDefault();
	var wrap = document.getElementById('kn-events-loadmore');
	var link = document.getElementById('kn-events-loadmore-link');
	if (!wrap || !link) return;
	var nextWindow = parseInt(wrap.dataset.nextWindow || '1', 10);
	var kingdomId = (window.KnConfig && KnConfig.kingdomId) || 0;
	var uir       = (window.KnConfig && KnConfig.uir)       || 'http://127.0.0.1:19080/orkui/index.php?Route=';
	if (!kingdomId) return;

	var origHtml = link.innerHTML;
	link.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
	link.style.pointerEvents = 'none';
	link.setAttribute('aria-busy', 'true');

	fetch(uir + 'Kingdom/events_more/' + kingdomId + '?window=' + nextWindow, { credentials: 'same-origin' })
		.then(function(r) {
			if (!r.ok) throw new Error('HTTP ' + r.status);
			return r.json();
		})
		.then(function(data) {
			var table = document.getElementById('kn-events-table');
			var tbody = table ? table.querySelector('tbody') : null;
			if (!tbody) return;

			// Reveal the table if it was hidden (empty-state page)
			if (table.style.display === 'none') table.style.display = '';
			var emptyEl = document.getElementById('kn-events-empty');
			if (emptyEl) emptyEl.style.display = 'none';

			// Append the new rows
			var appended = 0;
			(data.Events || []).forEach(function(e) {
				// Skip duplicates (shouldn't happen with non-overlapping windows, but defensive)
				if (document.querySelector('#kn-events-table tr[data-event-id="' + e.EventId + '"]')) return;
				tbody.appendChild(knBuildEventRow(e, data.FallbackHeraldry, data.Uir || uir));
				appended++;
			});

			// Update count + months in footer
			var countEl  = document.getElementById('kn-events-loadmore-count');
			var pluralEl = document.getElementById('kn-events-loadmore-plural');
			var monthsEl = document.getElementById('kn-events-loadmore-months');
			var prevLoaded = parseInt(wrap.dataset.loadedEventCount || '0', 10);
			var total = prevLoaded + appended;
			wrap.dataset.loadedEventCount = String(total);
			if (countEl)  countEl.textContent  = String(total);
			if (pluralEl) pluralEl.textContent = (total === 1 ? '' : 's');
			if (monthsEl) monthsEl.textContent = String(data.EndMonths);

			wrap.dataset.nextWindow = String(nextWindow + 1);

			// Respect current filter toggles for newly-appended rows
			try {
				if (typeof knFilters === 'object' && knFilters) {
					Object.keys(knFilters).forEach(function(type) {
						if (!knFilters[type]) {
							var rows = tbody.querySelectorAll('tr[data-type="' + type + '"]');
							rows.forEach(function(tr) { tr.style.display = 'none'; });
						}
					});
				}
			} catch (e) { console.warn('[knLoadMoreEvents] filter reapply failed', e); }

			// Re-run pagination if present
			try { if (typeof knPaginate === 'function' && window.jQuery) knPaginate(window.jQuery('#kn-events-table'), 1); } catch(e) {}

			// Calendar view: invalidate so next open re-fetches
			try { if (window.knCalendar) knCalendar.refetchEvents(); } catch(e) {}

			if (!data.HasMore) {
				link.remove();
			} else {
				link.innerHTML = 'Load more <i class="fas fa-chevron-down" style="font-size:10px;margin-left:3px"></i>';
				link.style.pointerEvents = '';
				link.removeAttribute('aria-busy');
			}
		})
		.catch(function(err) {
			console.error('[knLoadMoreEvents]', err);
			link.innerHTML = origHtml;
			link.style.pointerEvents = '';
			link.removeAttribute('aria-busy');
		});
}

function knBuildEventRow(e, fallbackHeraldry, uir) {
	var tr = document.createElement('tr');
	tr.className = 'kn-row-link';
	tr.dataset.type    = e.IsParkEvent ? 'park-event' : 'kingdom-event';
	tr.dataset.eventId = String(e.EventId);
	var detailHref = e.NextDetailId ? (uir + 'Event/detail/' + e.EventId + '/' + e.NextDetailId) : '';
	if (detailHref) tr.setAttribute('onclick', "window.location.href='" + detailHref + "'");

	var nameHtml = detailHref
		? '<a href="' + detailHref + '">' + knEscape(e.Name) + '</a>'
		: knEscape(e.Name);
	var dateHtml = e.NextDateText ? knEscape(e.NextDateText) : '<span style="color:#a0aec0">&mdash;</span>';
	var heraldry = e.HeraldryUrl || fallbackHeraldry;

	tr.innerHTML =
		'<td class="kn-col-nowrap">' + dateHtml + '</td>' +
		'<td class="kn-col-nowrap">' +
			'<img class="kn-thumb ' + (e.IsParkEvent ? 'kn-evt-park' : 'kn-evt-kingdom') +
				'" loading="lazy" src="' + knEscapeAttr(heraldry) +
				'" onerror="this.src=\'' + knEscapeAttr(fallbackHeraldry) + '\'" alt="">' +
			nameHtml +
		'</td>' +
		'<td>' + knEscape(e.ParkName || '') + '</td>' +
		'<td style="text-align:center">' + (e.RsvpGoing > 0 ? e.RsvpGoing : '&mdash;') + '</td>' +
		'<td style="text-align:center">' + (e.RsvpInterested > 0 ? e.RsvpInterested : '&mdash;') + '</td>';
	return tr;
}

function knEscape(s) {
	var d = document.createElement('div');
	d.textContent = (s == null ? '' : String(s));
	return d.innerHTML;
}
function knEscapeAttr(s) {
	return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
