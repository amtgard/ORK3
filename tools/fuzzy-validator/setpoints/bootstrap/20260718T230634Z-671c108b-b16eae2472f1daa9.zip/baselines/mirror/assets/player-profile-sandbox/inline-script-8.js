
// ---- Markdown rendering for About tab ----
(function() {
	var personaEl = document.getElementById('pn-about-persona-rendered');
	var storyEl   = document.getElementById('pn-about-story-rendered');
	function renderMd(raw) {
		if (typeof marked !== 'undefined' && typeof DOMPurify !== 'undefined') {
			return DOMPurify.sanitize(marked.parse(raw || ''));
		}
		return (raw || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
	}
	if (personaEl && PnConfig.aboutPersona) personaEl.innerHTML = renderMd(PnConfig.aboutPersona);
	if (storyEl && PnConfig.aboutStory) storyEl.innerHTML = renderMd(PnConfig.aboutStory);
})();

// ---- Photo Focus (precise pixel positioning) ----
// Mirrors the geometry used by the Design modal canvas (drawFocus): the visible
// circle has diameter = (size/100) * min(imgW, imgH) in image-pixel space, with
// its centre at (fx%, fy%) of the image. We scale the image so that diameter
// fills min(boxW, boxH), then translate the focal point to the box centre.
(function() {
	var imgs = document.querySelectorAll('.pn-avatar img[data-focus-size]');
	function applyFocus(img, animate) {
		var fx = parseFloat(img.dataset.focusX);
		var fy = parseFloat(img.dataset.focusY);
		var fs = parseFloat(img.dataset.focusSize);
		if (isNaN(fx) || isNaN(fy) || isNaN(fs)) return;
		if (!img.naturalWidth || !img.naturalHeight) return;
		var box = img.parentElement;
		// clientWidth/Height exclude the avatar's border; absolutely positioned
		// children measure from the padding edge, so we want content dimensions.
		var cw = box.clientWidth || 102, ch = box.clientHeight || 102;
		var iw = img.naturalWidth, ih = img.naturalHeight;
		var cropDiameter = (Math.max(15, fs) / 100) * Math.min(iw, ih);
		var scale = Math.min(cw, ch) / cropDiameter;
		var rw = iw * scale, rh = ih * scale;
		var fxPx = (fx / 100) * rw;
		var fyPx = (fy / 100) * rh;
		// Set transition BEFORE the geometry changes so resize/rotation eases
		// into the new size instead of snapping. Initial load passes no flag,
		// so the photo is placed instantly (no slide-in flash on page load).
		img.style.transition = animate ? 'width .18s ease, height .18s ease, left .18s ease, top .18s ease' : 'none';
		img.style.position = 'absolute';
		img.style.width  = rw + 'px';
		img.style.height = rh + 'px';
		img.style.left   = (cw / 2 - fxPx) + 'px';
		img.style.top    = (ch / 2 - fyPx) + 'px';
		img.style.objectFit = '';
		img.style.objectPosition = '';
		// .heraldry-img in orkui.css sets max-width:179px / max-height:240px,
		// which would otherwise clamp the zoomed-up image and break the crop.
		img.style.maxWidth = 'none';
		img.style.maxHeight = 'none';
	}
	imgs.forEach(function(img) {
		if (img.complete && img.naturalWidth) applyFocus(img);
		img.addEventListener('load', function() { applyFocus(img); });
	});
	// The geometry is computed from the avatar box's pixel size, which changes
	// across the responsive breakpoint (60px mobile-portrait vs 110px desktop/
	// landscape). Without recomputing on resize/rotation, the inline sizing
	// stays pinned to the old box and the photo renders mis-sized/off-center.
	var _focusTimer;
	window.addEventListener('resize', function() {
		clearTimeout(_focusTimer);
		_focusTimer = setTimeout(function() {
			imgs.forEach(function(img) { if (img.complete && img.naturalWidth) applyFocus(img, true); });
		}, 150);
	});
})();

// ---- Design My Profile Modal ----
(function() {
	if (!PnConfig.canEditDesign) return;
	function gid(id) { return document.getElementById(id); }

	// Open/Close
	window.pnOpenDesignModal = function() {
		gid('pn-design-error').style.display = 'none';
		gid('pn-design-error').textContent = '';
		gid('pn-design-overlay').classList.add('pn-open');
		document.body.style.overflow = 'hidden';
		initFocusTool();
		if (typeof window.pnUpdateDesignTabIndicators === 'function') {
			setTimeout(window.pnUpdateDesignTabIndicators, 50);
		}
	};
	function closeDesign() {
		gid('pn-design-overlay').classList.remove('pn-open');
		document.body.style.overflow = '';
	}
	gid('pn-design-close-btn').addEventListener('click', closeDesign);
	gid('pn-design-cancel').addEventListener('click', closeDesign);
	// Close on overlay click — but only when the press *started* on the overlay.
	// Otherwise drag-selecting text and releasing outside the modal closes it.
	(function() {
		var overlay = gid('pn-design-overlay');
		var pressOnOverlay = false;
		overlay.addEventListener('mousedown', function(e) { pressOnOverlay = (e.target === overlay); });
		overlay.addEventListener('click', function(e) { if (pressOnOverlay && e.target === overlay) closeDesign(); pressOnOverlay = false; });
	})();
	document.addEventListener('keydown', function(e) {
		if ((e.key === 'Escape' || e.keyCode === 27) && gid('pn-design-overlay').classList.contains('pn-open')) closeDesign();
	});

	// Tab switching
	function pnSwitchDesignPanel(name) {
		document.querySelectorAll('.pn-design-tab').forEach(function(t) { t.classList.remove('pn-active'); });
		document.querySelectorAll('.pn-design-panel').forEach(function(p) { p.classList.remove('pn-active'); });
		var tabBtn = document.querySelector('.pn-design-tab[data-panel="' + name + '"]');
		if (tabBtn) tabBtn.classList.add('pn-active');
		var panel = gid('pn-design-' + name);
		if (panel) panel.classList.add('pn-active');
		if (name === 'focus') initFocusTool();
	}
	document.querySelectorAll('.pn-design-tab').forEach(function(tab) {
		tab.addEventListener('click', function() { pnSwitchDesignPanel(tab.dataset.panel); });
	});

	// Mobile scroll indicators on the tab row
	(function() {
		var tabs = gid('pn-design-tabs');
		var left = gid('pn-design-tabs-chev-left');
		var right = gid('pn-design-tabs-chev-right');
		if (!tabs || !left || !right) return;
		function update() {
			var mobile = window.matchMedia('(max-width:600px)').matches;
			if (!mobile) {
				left.classList.remove('pn-show');
				right.classList.remove('pn-show');
				return;
			}
			left.classList.toggle('pn-show', tabs.scrollLeft > 0);
			right.classList.toggle('pn-show', tabs.scrollLeft + tabs.clientWidth < tabs.scrollWidth - 1);
		}
		tabs.addEventListener('scroll', update, { passive: true });
		window.addEventListener('resize', update);
		left.addEventListener('click', function() { tabs.scrollBy({ left: -Math.round(tabs.clientWidth * 0.7), behavior: 'smooth' }); });
		right.addEventListener('click', function() { tabs.scrollBy({ left: Math.round(tabs.clientWidth * 0.7), behavior: 'smooth' }); });
		window.pnUpdateDesignTabIndicators = update;
		update();
	})();

	// About-tab edit pencil — open Design modal focused on the About panel
	var aboutEditBtn = gid('pn-about-edit-btn');
	if (aboutEditBtn) {
		aboutEditBtn.addEventListener('click', function() {
			window.pnOpenDesignModal();
			pnSwitchDesignPanel('about');
		});
	}
	// Welcome card jump links
	document.querySelectorAll('.pn-welcome-card').forEach(function(card) {
		card.addEventListener('click', function() {
			var target = card.dataset.go;
			if (target) pnSwitchDesignPanel(target);
		});
	});

	// Markdown preview toggles
	document.querySelectorAll('.pn-md-toggle-btn').forEach(function(btn) {
		btn.addEventListener('click', function() {
			var field = btn.dataset.field;
			var target = btn.dataset.target;
			var textareaId = 'pn-design-about-' + field;
			var previewId  = textareaId + '-preview';
			var textarea = gid(textareaId);
			var preview  = gid(previewId);
			btn.parentElement.querySelectorAll('.pn-md-toggle-btn').forEach(function(b) { b.classList.remove('pn-active'); });
			btn.classList.add('pn-active');
			if (target === 'preview') {
				textarea.style.display = 'none';
				preview.style.display = '';
				var raw = textarea.value;
				if (typeof marked !== 'undefined' && typeof DOMPurify !== 'undefined') {
					preview.innerHTML = DOMPurify.sanitize(marked.parse(raw || ''));
				} else {
					preview.textContent = raw;
				}
			} else {
				textarea.style.display = '';
				preview.style.display = 'none';
			}
		});
	});

	// Quick Add snippets
	var PN_QUICK_SNIPPETS = {
		findmelinks: {
			position: 'bottom',
			text: [
				'Find me on... (edit the following, add or remove links using the same format, then remove this instruction!)',
				'- [Facebook](https://www.facebook.com/YOURFBHANDLE)',
				'- [Instagram](https://www.instagram.com/YOURIGHANDLE)',
				'- [Amtwiki](https://wiki.amtgard.com/YOURPROFILENAME)',
				'- [Threads](https://www.threads.net/@YOURTHREADSHANDLE)',
				'- [Bluesky](https://bsky.app/profile/YOURBSKYHANDLE)'
			].join('\n')
		},
		signaturequote: {
			position: 'top',
			text: '> "This is my signature quote which I am going to update before saving."\n> -- ' + (PnConfig.playerPersona || 'Your Persona')
		}
	};
	document.querySelectorAll('.pn-md-quick-btn[data-quickadd]').forEach(function(btn) {
		btn.addEventListener('click', function() {
			var key = btn.dataset.quickadd;
			var field = btn.dataset.targetField;
			var snippet = PN_QUICK_SNIPPETS[key];
			var ta = gid('pn-design-about-' + field);
			if (!ta || !snippet) return;
			// Make sure we're on the Write tab so the user sees the insertion.
			var writeBtn = document.querySelector('.pn-md-toggle-btn[data-field="' + field + '"][data-target="edit"]');
			if (writeBtn && !writeBtn.classList.contains('pn-active')) writeBtn.click();
			var existing = ta.value;
			var cursor;
			if (snippet.position === 'top') {
				var suffix = existing.length === 0 ? '' : (existing.startsWith('\n\n') ? '' : (existing.startsWith('\n') ? '\n' : '\n\n'));
				ta.value = snippet.text + suffix + existing;
				cursor = snippet.text.length;
			} else {
				var separator = existing.length === 0 ? '' : (existing.endsWith('\n\n') ? '' : (existing.endsWith('\n') ? '\n' : '\n\n'));
				ta.value = existing + separator + snippet.text;
				cursor = ta.value.length;
			}
			ta.focus();
			ta.setSelectionRange(cursor, cursor);
			ta.dispatchEvent(new Event('input', { bubbles: true }));
		});
	});

	// Color presets
	var allSwatches = document.querySelectorAll('.pn-color-swatch');
	allSwatches.forEach(function(sw) {
		sw.addEventListener('click', function() {
			clearPrideFlag();
			allSwatches.forEach(function(s) { s.classList.remove('pn-selected'); });
			sw.classList.add('pn-selected');
			gid('pn-color-primary').value = sw.dataset.primary;
			gid('pn-color-primary-hex').value = sw.dataset.primary;
			gid('pn-color-accent').value = sw.dataset.accent;
			gid('pn-color-accent-hex').value = sw.dataset.accent;
			if (sw.dataset.secondary) {
				gid('pn-color-secondary').value = sw.dataset.secondary;
				gid('pn-color-secondary-hex').value = sw.dataset.secondary;
				gid('pn-gradient-enabled').checked = true;
			} else {
				gid('pn-color-secondary-hex').value = '';
				gid('pn-gradient-enabled').checked = false;
			}
			updateColorPreview();
		});
	});

	// Color picker sync
	gid('pn-color-primary').addEventListener('input', function() { gid('pn-color-primary-hex').value = this.value; syncPresetSwatch(); updateColorPreview(); });
	gid('pn-color-accent').addEventListener('input', function() { gid('pn-color-accent-hex').value = this.value; syncPresetSwatch(); updateColorPreview(); });
	gid('pn-color-primary-hex').addEventListener('input', function() {
		if (/^#[0-9a-f]{6}$/i.test(this.value)) { gid('pn-color-primary').value = this.value; syncPresetSwatch(); updateColorPreview(); }
	});
	gid('pn-color-accent-hex').addEventListener('input', function() {
		if (/^#[0-9a-f]{6}$/i.test(this.value)) { gid('pn-color-accent').value = this.value; syncPresetSwatch(); updateColorPreview(); }
	});
	gid('pn-color-reset').addEventListener('click', function() {
		clearPrideFlag();
		gid('pn-color-primary').value = '#2c5282'; gid('pn-color-primary-hex').value = '#2c5282';
		gid('pn-color-accent').value = '#4299e1'; gid('pn-color-accent-hex').value = '#4299e1';
		gid('pn-color-secondary-hex').value = ''; gid('pn-color-secondary').value = '#2c5282';
		gid('pn-gradient-enabled').checked = false;
		gid('pn-hero-overlay').value = 'med';
		document.querySelectorAll('.pn-overlay-btn').forEach(function(b) { b.classList.remove('pn-active'); });
		document.querySelector('.pn-overlay-btn[data-overlay="med"]').classList.add('pn-active');
		applyOverlayPreview('med');
		syncPresetSwatch(); updateColorPreview();
	});
	// Secondary color / gradient toggle
	gid('pn-color-secondary').addEventListener('input', function() { gid('pn-color-secondary-hex').value = this.value; updateColorPreview(); });
	gid('pn-color-secondary-hex').addEventListener('input', function() {
		if (/^#[0-9a-f]{6}$/i.test(this.value)) { gid('pn-color-secondary').value = this.value; updateColorPreview(); }
	});
	gid('pn-gradient-enabled').addEventListener('change', function() {
		if (this.checked && !gid('pn-color-secondary-hex').value) {
			gid('pn-color-secondary-hex').value = gid('pn-color-accent').value;
			gid('pn-color-secondary').value = gid('pn-color-accent').value;
		}
		updateColorPreview();
	});
	// Overlay strength buttons
	document.querySelectorAll('.pn-overlay-btn').forEach(function(btn) {
		btn.addEventListener('click', function() {
			document.querySelectorAll('.pn-overlay-btn').forEach(function(b) { b.classList.remove('pn-active'); });
			btn.classList.add('pn-active');
			gid('pn-hero-overlay').value = btn.dataset.overlay;
			applyOverlayPreview(btn.dataset.overlay);
		});
	});
	function syncPresetSwatch() {
		var p = gid('pn-color-primary').value.toLowerCase();
		var a = gid('pn-color-accent').value.toLowerCase();
		var s = (gid('pn-gradient-enabled').checked ? gid('pn-color-secondary').value : '').toLowerCase();
		allSwatches.forEach(function(sw) {
			var matchBase = sw.dataset.primary.toLowerCase() === p && sw.dataset.accent.toLowerCase() === a;
			var swSec = (sw.dataset.secondary || '').toLowerCase();
			sw.classList.toggle('pn-selected', matchBase && swSec === s);
		});
	}
	var _pnPrideGradients = {"pride6":{"name":"6-Color Pride","colors":["#e40303","#ff8c00","#ffed00","#008026","#004dff","#750787"]},"progress":{"name":"Progress Pride","colors":["#000000","#784f17","#5bcffa","#f5a9b8","#ffffff","#e40303","#ff8c00","#ffed00","#008026","#004dff","#750787"]},"gilbert8":{"name":"Gilbert Baker\u0027s 1977 8-Color","colors":["#ff69b4","#e40303","#ff8c00","#ffed00","#008026","#00c0c0","#3f48cc","#750787"]},"philly":{"name":"Philadelphia POC-Inclusive","colors":["#000000","#784f17","#e40303","#ff8c00","#ffed00","#008026","#004dff","#750787"]},"lesbian":{"name":"Lesbian","colors":["#d62900","#ff9b55","#ffffff","#d461a6","#a50062"]},"bisexual":{"name":"Bisexual","colors":["#d60270","#9b4f96","#0038a8"]},"pansexual":{"name":"Pansexual","colors":["#ff218c","#ffd800","#21b1ff"]},"polysexual":{"name":"Polysexual","colors":["#f714ba","#01d66a","#1594f6"]},"asexual":{"name":"Asexual","colors":["#000000","#a3a3a3","#ffffff","#800080"]},"demisexual":{"name":"Demisexual","colors":["#000000","#ffffff","#6e0070","#d2d2d2"]},"aromantic":{"name":"Aromantic","colors":["#3da542","#a7d379","#ffffff","#a9a9a9","#000000"]},"transgender":{"name":"Transgender","colors":["#5bcffa","#f5a9b8","#ffffff","#f5a9b8","#5bcffa"]},"nonbinary":{"name":"Nonbinary","colors":["#fcf434","#ffffff","#9c59d1","#2c2c2c"]},"genderfluid":{"name":"Genderfluid","colors":["#ff75a2","#ffffff","#be18d6","#000000","#333ebd"]},"genderqueer":{"name":"Genderqueer","colors":["#b57edc","#ffffff","#4a8123"]},"intersex":{"name":"Intersex","colors":["#ffd800","#7902aa","#ffd800"]}};
	function applyOverlayPreview(level) {
		var preview = gid('pn-color-hero-preview');
		if (!preview) return;
		var opac = { low: '0.06', med: '0.12', high: '0.22', vignette: '0.12' }[level] || '0.12';
		preview.style.setProperty('--pn-preview-overlay-opacity', opac);
		preview.classList.toggle('pn-preview-vignette', level === 'vignette');
	}
	function updateColorPreview() {
		var preview = gid('pn-color-hero-preview');
		if (!preview) return;
		var prideKey = gid('pn-hero-gradient') ? gid('pn-hero-gradient').value : '';
		var prideActive = !!(prideKey && _pnPrideGradients[prideKey]);
		preview.classList.toggle('pn-hero-pride', prideActive);
		if (prideActive) {
			preview.style.background = 'linear-gradient(90deg, ' + _pnPrideGradients[prideKey].colors.join(', ') + ')';
			return;
		}
		var primary = gid('pn-color-primary').value;
		var gradientOn = gid('pn-gradient-enabled').checked;
		var secondary = gid('pn-color-secondary').value;
		if (gradientOn && secondary) {
			preview.style.background = 'linear-gradient(135deg, ' + primary + ', ' + secondary + ')';
		} else {
			preview.style.background = primary;
		}
	}
	updateColorPreview();
	syncPresetSwatch();
	applyOverlayPreview(gid('pn-hero-overlay') ? gid('pn-hero-overlay').value : 'med');

	// ---- Amtpride Nameplate ----
	var prideSection = gid('pn-amtpride-section');
	var prideToggle  = gid('pn-amtpride-toggle');
	var prideBadge   = gid('pn-amtpride-active-badge');
	var prideClear   = gid('pn-amtpride-clear');
	var prideHidden  = gid('pn-hero-gradient');
	var prideSwatches = document.querySelectorAll('.pn-amtpride-swatch');
	var colorPanel   = document.getElementById('pn-design-colors');
	// Function declarations are hoisted, so the regular swatch/reset handlers
	// (which call clearPrideFlag) keep working even if the Amtpride DOM is
	// missing — clearPrideFlag's own !prideHidden guard short-circuits cleanly.
	function applyPrideFlag(key) {
		if (!prideHidden || !prideBadge || !prideClear || !prideSection || !prideToggle) return;
		prideHidden.value = key || '';
		prideSwatches.forEach(function(sw) {
			sw.classList.toggle('pn-selected', sw.dataset.pride === key);
		});
		if (key) {
			prideBadge.style.display = '';
			prideClear.style.display = '';
			if (colorPanel) colorPanel.classList.add('pn-pride-active');
			prideSection.classList.add('pn-amtpride-open');
			prideToggle.setAttribute('aria-expanded', 'true');
			// Deselect regular presets — they're no longer driving the hero.
			allSwatches.forEach(function(s) { s.classList.remove('pn-selected'); });
		} else {
			prideBadge.style.display = 'none';
			prideClear.style.display = 'none';
			if (colorPanel) colorPanel.classList.remove('pn-pride-active');
			// Going back to the previous color/gradient: the custom color inputs were
			// never overwritten while the flag was active, so re-light whichever preset
			// matches them (if any) to make the restored selection visible.
			syncPresetSwatch();
		}
		updateColorPreview();
	}
	function clearPrideFlag() {
		if (!prideHidden || !prideHidden.value) return;
		// Reset the hidden field directly first — it is the source of truth the save
		// reads. applyPrideFlag('') refreshes the badge/dim/preview too, but its guard
		// can bail before clearing the value if any Amtpride sub-element is missing,
		// which would otherwise let the stale pride key survive into the save.
		prideHidden.value = '';
		applyPrideFlag('');
	}
	// Listener wiring is gated on the Amtpride DOM existing. If a future feature
	// flag hides the subsection, this block skips cleanly and the Name builder /
	// save handler below still run.
	if (prideSection && prideToggle && prideHidden && prideClear) {
		prideSwatches.forEach(function(sw) {
			sw.addEventListener('click', function() {
				var key = sw.dataset.pride;
				applyPrideFlag(prideHidden.value === key ? '' : key);
			});
		});
		prideToggle.addEventListener('click', function() {
			var open = prideSection.classList.toggle('pn-amtpride-open');
			prideToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		});
		prideClear.addEventListener('click', function() { clearPrideFlag(); });
		// Sync dim-state with the initial server-rendered selection.
		if (prideHidden.value && colorPanel) colorPanel.classList.add('pn-pride-active');
	}

	// Name builder
	var prefixSel = gid('pn-name-prefix-select');
	var suffixSel = gid('pn-name-suffix-select');
	var prefixCustom = gid('pn-name-prefix-custom');
	var suffixCustom = gid('pn-name-suffix-custom');
	var coreInput = gid('pn-name-core');
	function updateNamePreview() {
		var prefix = '';
		if (prefixSel.value === '__custom__') { prefix = prefixCustom.value.trim(); }
		else if (prefixSel.value) { prefix = prefixSel.value; }
		var suffix = '';
		if (suffixSel.value === '__custom__') { suffix = suffixCustom.value.trim(); }
		else if (suffixSel.value) { suffix = suffixSel.value; }
		var core = coreInput.value.trim() || PnConfig.playerPersona;
		var useComma = gid('pn-suffix-comma-toggle').classList.contains('pn-active');
		var full = '';
		if (prefix) full += prefix + ' ';
		full += core;
		if (suffix) full += (useComma ? ', ' : ' ') + suffix;
		gid('pn-name-preview').textContent = full;
	}
	gid('pn-suffix-comma-toggle').addEventListener('click', function() {
		this.classList.toggle('pn-active');
		updateNamePreview();
	});
	prefixSel.addEventListener('change', function() {
		var isCustom = this.value === '__custom__';
		prefixCustom.style.display = isCustom ? '' : 'none';
		var warn = gid('pn-name-prefix-warn');
		if (warn) warn.style.display = isCustom ? '' : 'none';
		if (!isCustom) prefixCustom.value = '';
		updateNamePreview();
	});
	suffixSel.addEventListener('change', function() {
		var isCustom = this.value === '__custom__';
		suffixCustom.style.display = isCustom ? '' : 'none';
		var warn = gid('pn-name-suffix-warn');
		if (warn) warn.style.display = isCustom ? '' : 'none';
		if (!isCustom) suffixCustom.value = '';
		updateNamePreview();
	});
	prefixCustom.addEventListener('input', updateNamePreview);
	suffixCustom.addEventListener('input', updateNamePreview);
	coreInput.addEventListener('input', updateNamePreview);

	// Font picker
	var PN_FONTS = [
		{key:'',label:'Default',family:'inherit'},
		{key:'Cinzel',label:'Cinzel',family:'Cinzel'},
		{key:'Cinzel Decorative',label:'Cinzel Deco',family:"'Cinzel Decorative'"},
		{key:'IM Fell English',label:'IM Fell English',family:"'IM Fell English'"},
		{key:'UnifrakturMaguntia',label:'Unifraktur',family:'UnifrakturMaguntia'},
		{key:'Metamorphous',label:'Metamorphous',family:'Metamorphous'},
		{key:'Uncial Antiqua',label:'Uncial Antiqua',family:"'Uncial Antiqua'"},
		{key:'Pirata One',label:'Pirata One',family:"'Pirata One'"},
		{key:'Almendra',label:'Almendra',family:'Almendra'},
		{key:'Pinyon Script',label:'Pinyon Script',family:"'Pinyon Script'"},
		{key:'Great Vibes',label:'Great Vibes',family:"'Great Vibes'"},
	];
	var pnSelectedFont = PnConfig.nameFont || '';
	var pnLoadedFonts = {};
	function pnLoadFont(key) {
		if (!key || pnLoadedFonts[key]) return;
		var link = document.createElement('link');
		link.rel = 'stylesheet';
		link.href = 'https://fonts.googleapis.com/css2?family=' + key.replace(/ /g, '+') + '&display=swap';
		document.head.appendChild(link);
		pnLoadedFonts[key] = true;
	}
	function pnApplyFont(key) {
		var f = null;
		for (var _i = 0; _i < PN_FONTS.length; _i++) { if (PN_FONTS[_i].key === key) { f = PN_FONTS[_i]; break; } }
		if (!f) f = PN_FONTS[0];
		// In-modal previews (.ork-font-sample) always show the chosen font so the
		// designer can see what *other* viewers will experience. The actual hero
		// honors the viewer's own basic/dyslexia accessibility preferences.
		var heroFam = (PnConfig.viewerBasicFonts || PnConfig.viewerDyslexiaFonts) ? 'inherit' : f.family;
		var preview = gid('pn-name-preview');
		var heroPreview = document.querySelector('.pn-hero-preview-name');
		var heroName = gid('pn-hero-persona');
		// setProperty with 'important' is needed so inline styles win over the
		// server-rendered <style>...!important rule that exists once a name font
		// has been saved (see template line ~225).
		if (preview)     preview.style.setProperty('font-family', f.family, 'important');
		if (heroPreview) heroPreview.style.setProperty('font-family', f.family, 'important');
		if (heroName)    heroName.style.setProperty('font-family', heroFam, 'important');
	}
	function pnRenderFontPicker() {
		var container = gid('pn-font-picker');
		if (!container) return;
		var sample = (PnConfig.namePrefix ? PnConfig.namePrefix + ' ' : '') + PnConfig.playerPersona;
		var html = '';
		for (var _j = 0; _j < PN_FONTS.length; _j++) {
			var _f = PN_FONTS[_j];
			var _active = _f.key === pnSelectedFont;
			html += '<div class="pn-font-card' + (_active ? ' pn-active' : '') + '" data-font-key="' + escHtml(_f.key) + '">';
			html += '<div class="pn-font-card-sample ork-font-sample" style="font-family:' + _f.family + '">' + escHtml(sample) + '</div>';
			html += '<div class="pn-font-card-label">' + escHtml(_f.label) + '</div>';
			html += '</div>';
		}
		container.innerHTML = html;
		for (var _k = 1; _k < PN_FONTS.length; _k++) pnLoadFont(PN_FONTS[_k].key);
		container.addEventListener('click', function(e) {
			var card = e.target.closest('.pn-font-card');
			if (!card) return;
			pnSelectedFont = card.getAttribute('data-font-key');
			var cards = container.querySelectorAll('.pn-font-card');
			for (var _m = 0; _m < cards.length; _m++) cards[_m].classList.toggle('pn-active', cards[_m] === card);
			if (pnSelectedFont) pnLoadFont(pnSelectedFont);
			pnApplyFont(pnSelectedFont);
		});
	}
	pnRenderFontPicker();
	var nameShadowCb = gid('pn-name-shadow');
	var heroEl = document.querySelector('.pn-hero');
	if (nameShadowCb && heroEl) {
		nameShadowCb.addEventListener('change', function() {
			heroEl.classList.toggle('pn-hero-name-shadow', nameShadowCb.checked);
		});
	}
	if (pnSelectedFont) { pnLoadFont(pnSelectedFont); pnApplyFont(pnSelectedFont); }
	// Re-render after all fonts land — fonts.ready resolves too early (before downloads finish).
	// fonts.load() per family triggers downloads and resolves only when each is paint-ready.
	if (document.fonts && document.fonts.load) {
		Promise.all([
			document.fonts.load('16px Cinzel'),
			document.fonts.load('16px "Cinzel Decorative"'),
			document.fonts.load('16px "IM Fell English"'),
			document.fonts.load('16px UnifrakturMaguntia'),
			document.fonts.load('16px Metamorphous'),
			document.fonts.load('16px "Uncial Antiqua"'),
			document.fonts.load('16px "Pirata One"'),
			document.fonts.load('16px Almendra'),
			document.fonts.load("16px 'Pinyon Script'"),
			document.fonts.load("16px 'Great Vibes'"),
		]).then(function() { pnRenderFontPicker(); });
	}

	// Photo focus tool
	var focusImg = null, focusCanvas = null, focusCtx = null;
	var focusCircle = { x: PnConfig.photoFocusX, y: PnConfig.photoFocusY, size: PnConfig.photoFocusSize };
	var focusScale = 1, focusImgW = 0, focusImgH = 0;
	var focusInited = false;

	function initFocusTool() {
		if (focusInited || !PnConfig.hasImage) return;
		focusCanvas = gid('pn-focus-canvas');
		if (!focusCanvas) return;
		focusCtx = focusCanvas.getContext('2d');
		var img = new Image();
		img.crossOrigin = 'anonymous';
		img.onload = function() {
			focusImg = img;
			focusImgW = img.width; focusImgH = img.height;
			var maxW = Math.min(400, window.innerWidth - 120);
			var maxH = Math.min(320, window.innerHeight - 340);
			focusScale = Math.min(maxW / img.width, maxH / img.height, 1);
			focusCanvas.width = Math.round(img.width * focusScale);
			focusCanvas.height = Math.round(img.height * focusScale);
			drawFocus();
			bindFocusEvents();
			focusInited = true;
		};
		img.src = PnConfig.imageUrl;
	}

	function drawFocus() {
		if (!focusImg || !focusCtx) return;
		var cw = focusCanvas.width, ch = focusCanvas.height;
		focusCtx.clearRect(0, 0, cw, ch);
		focusCtx.drawImage(focusImg, 0, 0, cw, ch);
		// Dim everything
		focusCtx.fillStyle = 'rgba(0,0,0,0.55)';
		focusCtx.fillRect(0, 0, cw, ch);
		// Cut out circle
		var cx = focusCircle.x / 100 * cw;
		var cy = focusCircle.y / 100 * ch;
		var radius = focusCircle.size / 100 * Math.min(cw, ch) / 2;
		radius = Math.max(20, Math.min(radius, Math.min(cw, ch) / 2));
		focusCtx.save();
		focusCtx.beginPath();
		focusCtx.arc(cx, cy, radius, 0, Math.PI * 2);
		focusCtx.clip();
		focusCtx.drawImage(focusImg, 0, 0, cw, ch);
		focusCtx.restore();
		// Circle border
		focusCtx.beginPath();
		focusCtx.arc(cx, cy, radius, 0, Math.PI * 2);
		focusCtx.strokeStyle = 'rgba(255,255,255,0.9)';
		focusCtx.lineWidth = 2;
		focusCtx.stroke();
		// Resize handle at bottom-right of circle
		var hx = cx + radius * 0.707, hy = cy + radius * 0.707;
		focusCtx.fillStyle = '#fff';
		focusCtx.beginPath();
		focusCtx.arc(hx, hy, 6, 0, Math.PI * 2);
		focusCtx.fill();
		focusCtx.strokeStyle = 'rgba(0,0,0,0.3)';
		focusCtx.lineWidth = 1;
		focusCtx.stroke();
	}

	function bindFocusEvents() {
		var dragging = null;
		function getPos(e) {
			var r = focusCanvas.getBoundingClientRect();
			var src = e.touches ? e.touches[0] : e;
			return { x: src.clientX - r.left, y: src.clientY - r.top };
		}
		function onDown(e) {
			e.preventDefault();
			var pos = getPos(e);
			var cw = focusCanvas.width, ch = focusCanvas.height;
			var cx = focusCircle.x / 100 * cw, cy = focusCircle.y / 100 * ch;
			var radius = focusCircle.size / 100 * Math.min(cw, ch) / 2;
			// Check resize handle
			var hx = cx + radius * 0.707, hy = cy + radius * 0.707;
			if (Math.hypot(pos.x - hx, pos.y - hy) < 12) {
				dragging = { type: 'resize', startSize: focusCircle.size, startDist: Math.hypot(pos.x - cx, pos.y - cy) };
				return;
			}
			// Check if inside circle (move)
			if (Math.hypot(pos.x - cx, pos.y - cy) <= radius) {
				dragging = { type: 'move', ox: focusCircle.x, oy: focusCircle.y, sx: pos.x, sy: pos.y };
			}
		}
		function onMove(e) {
			if (!dragging) return;
			var pos = getPos(e);
			var cw = focusCanvas.width, ch = focusCanvas.height;
			if (dragging.type === 'move') {
				var dx = (pos.x - dragging.sx) / cw * 100;
				var dy = (pos.y - dragging.sy) / ch * 100;
				focusCircle.x = Math.max(0, Math.min(100, dragging.ox + dx));
				focusCircle.y = Math.max(0, Math.min(100, dragging.oy + dy));
			} else if (dragging.type === 'resize') {
				var cx = focusCircle.x / 100 * cw, cy = focusCircle.y / 100 * ch;
				var dist = Math.hypot(pos.x - cx, pos.y - cy);
				var newSize = dragging.startSize * (dist / dragging.startDist);
				focusCircle.size = Math.max(15, Math.min(100, newSize));
			}
			gid('pn-focus-x').value = Math.round(focusCircle.x);
			gid('pn-focus-y').value = Math.round(focusCircle.y);
			gid('pn-focus-size').value = Math.round(focusCircle.size);
			drawFocus();
		}
		function onUp() { dragging = null; }
		focusCanvas.addEventListener('mousedown', onDown);
		focusCanvas.addEventListener('touchstart', onDown, { passive: false });
		window.addEventListener('mousemove', onMove);
		window.addEventListener('touchmove', onMove, { passive: false });
		window.addEventListener('mouseup', onUp);
		window.addEventListener('touchend', onUp);
	}

	// About-section character limit + counter (counter only shows at >= 9,000 chars).
	(function() {
		var ABOUT_FIELDS = [
			{ id: 'pn-design-about-persona', cid: 'pn-design-about-persona-charcount' },
			{ id: 'pn-design-about-story',   cid: 'pn-design-about-story-charcount' }
		];
		var ABOUT_LIMIT = 10000;
		var ABOUT_SHOW_AT = 9000;
		ABOUT_FIELDS.forEach(function(f) {
			var ta = gid(f.id);
			var cc = gid(f.cid);
			if (!ta || !cc) return;
			function update() {
				var n = ta.value.length;
				if (n < ABOUT_SHOW_AT) {
					cc.style.display = 'none';
					cc.classList.remove('pn-char-warn');
					return;
				}
				cc.style.display = '';
				if (n > ABOUT_LIMIT) {
					cc.textContent = (n - ABOUT_LIMIT).toLocaleString() + ' characters over the 10,000-character limit';
					cc.classList.add('pn-char-warn');
				} else {
					cc.textContent = (ABOUT_LIMIT - n).toLocaleString() + ' characters remaining';
					cc.classList.remove('pn-char-warn');
				}
			}
			ta.addEventListener('input', update);
			update();
		});
	})();

	// Save
	gid('pn-design-save').addEventListener('click', function() {
		var btn = this;
		btn.disabled = true;
		btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
		var errEl = gid('pn-design-error');
		errEl.style.display = 'none';
		// Clear any inline profanity errors from a prior save attempt.
		document.querySelectorAll('.pn-profanity-inline-err').forEach(function(el) { el.remove(); });

		var prefix = '';
		if (prefixSel.value === '__custom__') prefix = prefixCustom.value.trim();
		else if (prefixSel.value) prefix = prefixSel.value;
		var suffix = '';
		if (suffixSel.value === '__custom__') suffix = suffixCustom.value.trim();
		else if (suffixSel.value) suffix = suffixSel.value;
		var coreName = coreInput.value.trim();
		if (!coreName) {
			errEl.textContent = 'Core name is required.';
			errEl.style.display = '';
			btn.disabled = false;
			btn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
			return;
		}
		var ABOUT_SAVE_LIMIT = 10000;
		var aboutPersonaVal = gid('pn-design-about-persona').value;
		var aboutStoryVal   = gid('pn-design-about-story').value;
		if (aboutPersonaVal.length > ABOUT_SAVE_LIMIT) {
			pnShowProfanityFieldError('AboutPersona',
				'Your About section is limited to ' + ABOUT_SAVE_LIMIT.toLocaleString() + ' characters. It is currently ' + aboutPersonaVal.length.toLocaleString() + ' characters — trim it before saving.');
			btn.disabled = false;
			btn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
			return;
		}
		if (aboutStoryVal.length > ABOUT_SAVE_LIMIT) {
			pnShowProfanityFieldError('AboutStory',
				'Your My Story section is limited to ' + ABOUT_SAVE_LIMIT.toLocaleString() + ' characters. It is currently ' + aboutStoryVal.length.toLocaleString() + ' characters — trim it before saving.');
			btn.disabled = false;
			btn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
			return;
		}
		var fd = new FormData();
		fd.append('AboutPersona', gid('pn-design-about-persona').value);
		fd.append('AboutStory', gid('pn-design-about-story').value);
		fd.append('ColorPrimary', gid('pn-color-primary').value);
		fd.append('ColorAccent', gid('pn-color-accent').value);
		fd.append('ColorSecondary', gid('pn-gradient-enabled').checked ? gid('pn-color-secondary').value : '');
		fd.append('HeroGradient', (gid('pn-hero-gradient') && gid('pn-hero-gradient').value) || '');
		fd.append('HeroOverlay', gid('pn-hero-overlay').value);
		fd.append('NamePrefix', prefix);
		fd.append('NameSuffix', suffix);
		fd.append('SuffixComma', gid('pn-suffix-comma-toggle').classList.contains('pn-active') ? 1 : 0);
		fd.append('Persona', coreName);
		fd.append('PhotoFocusX', gid('pn-focus-x') ? gid('pn-focus-x').value : PnConfig.photoFocusX);
		fd.append('PhotoFocusY', gid('pn-focus-y') ? gid('pn-focus-y').value : PnConfig.photoFocusY);
		fd.append('PhotoFocusSize', gid('pn-focus-size') ? gid('pn-focus-size').value : PnConfig.photoFocusSize);
		fd.append('ShowBeltline', gid('pn-design-show-beltline').checked ? 1 : 0);
		fd.append('ShowFeastPrefs', gid('pn-design-show-feast-prefs') && gid('pn-design-show-feast-prefs').checked ? 1 : 0);
		fd.append('PronunciationGuide', gid('pn-design-pronunciation').value);
		fd.append('ShowMundaneFirst', gid('pn-design-show-first').checked ? 1 : 0);
		fd.append('ShowMundaneLast', gid('pn-design-show-last').checked ? 1 : 0);
		fd.append('ShowEmail', gid('pn-design-show-email').checked ? 1 : 0);

		// Milestone config
		var msConfig = {};
		var msToggles = document.querySelectorAll('#pn-ms-toggles input[data-ms-type]');
		for (var i = 0; i < msToggles.length; i++) {
			msConfig[msToggles[i].getAttribute('data-ms-type')] = msToggles[i].checked ? 1 : 0;
		}
		var compactEl = gid('pn-ms-compact');
		msConfig['compact_milestones'] = (compactEl && compactEl.checked) ? 1 : 0;
		var newestFirstEl = gid('pn-ms-newest-first');
		msConfig['newest_first'] = (newestFirstEl && newestFirstEl.checked) ? 1 : 0;
		fd.append('MilestoneConfig', JSON.stringify(msConfig));
			fd.append('NameFont', pnSelectedFont || '');

		fd.append('NameShadow', gid('pn-name-shadow') && gid('pn-name-shadow').checked ? 1 : 0);

		// Belt display (Icons tab — Knights only; radios aren't rendered for non-knights)
		var beltRadios = document.querySelectorAll('input[name="pn-design-belt-display"]');
		for (var bi = 0; bi < beltRadios.length; bi++) {
			if (beltRadios[bi].checked) { fd.append('BeltDisplay', beltRadios[bi].value); break; }
		}

		// Inline-render a profanity rejection above the offending field, switching
		// the design modal to that field's tab if needed. Falls back to the
		// generic top-of-modal error slot for other failure types.
		function pnShowProfanityFieldError(fieldName, msg) {
			var fieldMap = {
				'Persona':            { fieldId: 'pn-name-core',              tabPanel: 'name'  },
				'AboutPersona':       { fieldId: 'pn-design-about-persona',   tabPanel: 'about' },
				'AboutStory':         { fieldId: 'pn-design-about-story',     tabPanel: 'about' },
				'NamePrefix':         { fieldId: 'pn-name-prefix-custom',     tabPanel: 'name'  },
				'NameSuffix':         { fieldId: 'pn-name-suffix-custom',     tabPanel: 'name'  },
				'PronunciationGuide': { fieldId: 'pn-design-pronunciation',   tabPanel: 'name'  },
			};
			var spec = fieldMap[fieldName];
			if (!spec) return false;
			var fieldEl = document.getElementById(spec.fieldId);
			if (!fieldEl) return false;
			if (spec.tabPanel) {
				var tabBtn = document.querySelector('.pn-design-tab[data-panel="' + spec.tabPanel + '"]');
				if (tabBtn) tabBtn.click();
			}
			// Custom prefix/suffix inputs are hidden when the user picked a canonical
			// dropdown option — but if the server flagged the field, the offending text
			// is in that hidden input, so reveal it so the inline error has somewhere
			// visible to attach.
			if (fieldEl.style && fieldEl.style.display === 'none') {
				fieldEl.style.display = '';
			}
			var errId = spec.fieldId + '-profanity-err';
			var err = document.getElementById(errId);
			if (!err) {
				err = document.createElement('div');
				err.id = errId;
				err.className = 'pn-form-error pn-profanity-inline-err';
				err.style.marginBottom = '8px';
				fieldEl.parentNode.insertBefore(err, fieldEl);
			}
			err.textContent = msg;
			err.style.display = 'block';
			setTimeout(function() {
				err.scrollIntoView({behavior: 'smooth', block: 'start'});
			}, 50);
			return true;
		}

		fetch(PnConfig.uir + 'PlayerAjax/player/' + PnConfig.playerId + '/updateprofile', { method: 'POST', body: fd })
			.then(function(r) { return r.json(); })
			.then(function(result) {
				if (result && result.status === 0) {
					window.location.reload();
				} else {
					var msg = (result && result.error) ? result.error : 'Save failed.';
					var shown = false;
					if (result && result.field) {
						shown = pnShowProfanityFieldError(result.field, msg);
					}
					if (!shown) {
						errEl.textContent = msg;
						errEl.style.display = 'block';
					}
					btn.disabled = false;
					btn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
				}
			})
			.catch(function(err) {
				errEl.textContent = 'Request failed: ' + err.message;
				errEl.style.display = 'block';
				btn.disabled = false;
				btn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
			});
	});
})();

// ---- Icons tab (Design My Profile) — live preview ----
(function() {
	var preview = document.getElementById('pn-icons-preview');
	if (!preview) return; // non-knight, panel not rendered
	var radios = document.querySelectorAll('input[name="pn-design-belt-display"]');
	function render() {
		var val = 'white';
		for (var i = 0; i < radios.length; i++) { if (radios[i].checked) { val = radios[i].value; break; } }
		preview.innerHTML = '';
		if (val === 'white') {
			var img = document.createElement('img');
			img.src = window.pnWhiteBeltUrl;
			img.alt = 'White Belt';
			preview.appendChild(img);
		} else if (val === 'own') {
			var belts = window.pnOwnBelts || [];
			if (!belts.length) {
				var msg = document.createElement('span');
				msg.className = 'pn-icons-preview-empty';
				msg.textContent = 'No reconciled knighthood awards found.';
				preview.appendChild(msg);
			} else {
				for (var j = 0; j < belts.length; j++) {
					var bi = document.createElement('img');
					bi.src = belts[j].src;
					bi.alt = belts[j].name || '';
					bi.title = belts[j].name || '';
					preview.appendChild(bi);
				}
			}
		} else {
			var none = document.createElement('span');
			none.className = 'pn-icons-preview-empty';
			none.textContent = 'No belt icon';
			preview.appendChild(none);
		}
	}
	for (var i = 0; i < radios.length; i++) { radios[i].addEventListener('change', render); }
	render();
})();

// ---- Milestones Config (Design My Profile) ----
(function() {
	if (!PnConfig.canEditDesign) return;

	// Init toggles from saved config
	var cfg = PnConfig.milestoneConfig || {};
	var compactToggle = document.getElementById('pn-ms-compact');
	if (compactToggle) compactToggle.checked = !!cfg['compact_milestones'];
	var newestFirstToggle = document.getElementById('pn-ms-newest-first');
	if (newestFirstToggle) newestFirstToggle.checked = !!cfg['newest_first'];
	var toggles = document.querySelectorAll('#pn-ms-toggles input[data-ms-type]');
	for (var i = 0; i < toggles.length; i++) {
		var msType = toggles[i].getAttribute('data-ms-type');
		// Default ON if not in config
		if (typeof cfg[msType] !== 'undefined' && !cfg[msType]) {
			toggles[i].checked = false;
		}
	}

	// Render custom milestones list
	var customList = document.getElementById('pn-ms-custom-list');
	var customData = PnConfig.customMilestones || [];
	function renderCustomList() {
		if (!customList) return;
		var newestFirst = !!(newestFirstToggle && newestFirstToggle.checked);
		customData.sort(function(a, b) {
			var ad = a.MilestoneDate || '', bd = b.MilestoneDate || '';
			return newestFirst ? bd.localeCompare(ad) : ad.localeCompare(bd);
		});
		if (customData.length === 0) {
			customList.innerHTML = '<div style="font-size:12px;color:#a0aec0;padding:8px 0">No custom milestones yet.</div>';
			return;
		}
		var html = '';
		for (var i = 0; i < customData.length; i++) {
			var m = customData[i];
			var dateStr = m.MilestoneDate || '';
			if (dateStr && dateStr !== '0000-00-00') {
				var d = new Date(dateStr + 'T00:00:00');
				dateStr = d.toLocaleDateString('en-US', {month:'short',day:'numeric',year:'numeric'});
			}
			html += '<div class="pn-ms-custom-row" data-ms-id="' + m.MilestoneId + '">'
				+ '<i class="fas ' + (m.Icon || 'fa-star').replace(/[^a-z0-9-]/g,'') + '"></i>'
				+ '<span class="pn-ms-custom-desc">' + (m.Description || '').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</span>'
				+ '<span class="pn-ms-custom-date">' + dateStr + '</span>'
				+ '<span class="pn-ms-custom-actions">'
				+ '<button title="Delete" onclick="pnDeleteMilestone(' + m.MilestoneId + ')"><i class="fas fa-trash-alt"></i></button>'
				+ '</span></div>';
		}
		customList.innerHTML = html;
	}
	renderCustomList();
	if (newestFirstToggle) newestFirstToggle.addEventListener('change', renderCustomList);

	// Icon grid selection
	var iconGrid = document.getElementById('pn-ms-icon-grid');
	var selectedIcon = 'fa-star';
	if (iconGrid) {
		iconGrid.addEventListener('click', function(e) {
			var opt = e.target.closest('.pn-ms-icon-opt');
			if (!opt) return;
			var prev = iconGrid.querySelector('.pn-ms-icon-active');
			if (prev) prev.classList.remove('pn-ms-icon-active');
			opt.classList.add('pn-ms-icon-active');
			selectedIcon = opt.getAttribute('data-icon');
		});
	}

	// Add custom milestone
	var addBtn = document.getElementById('pn-ms-add-btn');
	var addErr = document.getElementById('pn-ms-add-error');
	if (addBtn) {
		addBtn.addEventListener('click', function() {
			var desc = document.getElementById('pn-ms-add-desc').value.trim();
			var dt   = document.getElementById('pn-ms-add-date').value;
			var icon = selectedIcon;
			addErr.style.display = 'none';
			if (!desc) { addErr.textContent = 'Description is required.'; addErr.style.display = ''; return; }
			if (!dt)   { addErr.textContent = 'Date is required.'; addErr.style.display = ''; return; }
			addBtn.disabled = true;
			addBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
			var fd = new FormData();
			fd.append('Description', desc);
			fd.append('MilestoneDate', dt);
			fd.append('Icon', icon);
			fetch(PnConfig.uir + 'PlayerAjax/player/' + PnConfig.playerId + '/addmilestone', { method: 'POST', body: fd })
				.then(function(r) { return r.json(); })
				.then(function(result) {
					if (result && result.status === 0) {
						customData.push({ MilestoneId: result.milestoneId, Icon: icon, Description: desc, MilestoneDate: dt });
						renderCustomList();
						document.getElementById('pn-ms-add-desc').value = '';
						document.getElementById('pn-ms-add-date').value = '';
						var prevIcon = iconGrid.querySelector('.pn-ms-icon-active');
						if (prevIcon) prevIcon.classList.remove('pn-ms-icon-active');
						var defIcon = iconGrid.querySelector('[data-icon="fa-star"]');
						if (defIcon) defIcon.classList.add('pn-ms-icon-active');
						selectedIcon = 'fa-star';
					} else {
						addErr.textContent = (result && result.error) || 'Failed to add milestone.';
						addErr.style.display = '';
					}
					addBtn.disabled = false;
					addBtn.innerHTML = '<i class="fas fa-plus"></i> Add';
				})
				.catch(function(e) {
					addErr.textContent = 'Request failed.';
					addErr.style.display = '';
					addBtn.disabled = false;
					addBtn.innerHTML = '<i class="fas fa-plus"></i> Add';
				});
		});
	}

	// Delete custom milestone
	window.pnDeleteMilestone = function(msId) {
		var ms = customData.find(function(m) { return m.MilestoneId === msId; });
		var preview = '';
		if (ms) {
			var dateStr = ms.MilestoneDate || '';
			var humanDate = dateStr;
			if (dateStr && dateStr !== '0000-00-00') {
				var d = new Date(dateStr + 'T00:00:00');
				if (!isNaN(d.getTime())) humanDate = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
			}
			preview = humanDate + ' — ' + (ms.Description || '');
		}
		pnConfirm({
			title:       'Delete Milestone',
			message:     preview ? ('Delete this custom milestone — ' + preview + '?') : 'Delete this custom milestone?',
			confirmText: 'Delete',
			danger:      true
		}, function() {
			var fd = new FormData();
			fd.append('MilestoneId', msId);
			fetch(PnConfig.uir + 'PlayerAjax/player/' + PnConfig.playerId + '/deletemilestone', { method: 'POST', body: fd })
				.then(function(r) { return r.json(); })
				.then(function(result) {
					if (result && result.status === 0) {
						customData = customData.filter(function(m) { return m.MilestoneId !== msId; });
						renderCustomList();
					} else {
						alert((result && result.error) || 'Failed to delete milestone.');
					}
				})
				.catch(function() { alert('Request failed.'); });
		});
	};
})();

// 26-week sparkline (called on load and again after attendance AJAX)
function pnRenderSparkline() {
	var el = document.getElementById('pna-sparkline');
	if (!el) return;
	var dates = (typeof PnConfig !== 'undefined' && PnConfig.attendanceDates) ? PnConfig.attendanceDates : [];
	var attended = {};
	dates.forEach(function(d) { attended[d] = true; });
	var now = new Date(); now.setHours(0,0,0,0);
	var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
	var html = '', mhtml = '', prevMonth = -1;
	for (var w = 25; w >= 0; w--) {
		var wkStart = new Date(now); wkStart.setDate(wkStart.getDate() - (w * 7) - wkStart.getDay());
		var wkEnd   = new Date(wkStart); wkEnd.setDate(wkEnd.getDate() + 6);
		var hit = false;
		for (var d2 = new Date(wkStart); d2 <= wkEnd; d2.setDate(d2.getDate() + 1)) {
			var ds = d2.getFullYear() + '-' + String(d2.getMonth()+1).padStart(2,'0') + '-' + String(d2.getDate()).padStart(2,'0');
			if (attended[ds]) { hit = true; break; }
		}
		var ht = hit ? 34 : 10;
		var cls = hit ? 'pna-spark-on' : 'pna-spark-off';
		var label = 'Week of ' + wkStart.toLocaleDateString('en-US',{month:'short',day:'numeric'});
		html += '<div class="pna-spark-week ' + cls + '" title="' + label + '" style="height:' + ht + 'px"></div>';
		var wkMonth = wkStart.getMonth();
		var lbl = (wkMonth !== prevMonth) ? months[wkMonth] : '';
		mhtml += '<div class="pna-spark-month-lbl">' + lbl + '</div>';
		prevMonth = wkMonth;
	}
	el.innerHTML = html;
	var mel = document.getElementById('pna-spark-months');
	if (mel) mel.innerHTML = mhtml;
}
pnRenderSparkline();

// ---- Dietary Preferences Modal ----
(function() {
	var DP_LOAD_URL = 'http://127.0.0.1:19080/orkui/index.php?Route=PlayerAjax/dietary_preferences/1';
	var DP_SAVE_URL = 'http://127.0.0.1:19080/orkui/index.php?Route=PlayerAjax/save_dietary_preferences';
	var dpLoaded = false;
	var dpDirty  = false;
	var dpSnap   = null; // modal state at open time; restored on discard

	var ALLERGEN_FIELDS = ['AllergenPeanuts','AllergenTreenuts','AllergenWheat','AllergenMilk','AllergenEggs',
	                       'AllergenFish','AllergenShellfish','AllergenSoy','AllergenSesame','AllergenGarlic',
	                       'AllergenGluten','AllergenOnion','AllergenMushroom','AllergenCorn','AllergenCoconut','AllergenCocoa','AllergenNightshades'];

	// ---- DOM helpers (scoped to modal) ----
	function gInModal(sel) { return document.querySelector('#pn-dp-overlay ' + sel); }
	function allInModal(sel) { return document.querySelectorAll('#pn-dp-overlay ' + sel); }

	function dpSetToggle(field, val) {
		var sw = gInModal('.dp-toggle-sw[data-field="' + field + '"]');
		if (sw) sw.classList.toggle('dp-on', !!val);
	}
	function dpToggleValue(field) {
		var sw = gInModal('.dp-toggle-sw[data-field="' + field + '"]');
		return sw ? sw.classList.contains('dp-on') : false;
	}
	function dpSetAllergen(grp, v) {
		v = parseInt(v) || 0;
		grp.querySelectorAll('.dp-al-seg').forEach(function(btn) {
			btn.classList.toggle('dp-active', parseInt(btn.dataset.v) === v);
		});
	}
	function dpGetAllergen(field) {
		var grp = gInModal('.dp-al-slider[data-field="' + field + '"]');
		if (!grp) return 0;
		var active = grp.querySelector('.dp-al-seg.dp-active');
		return active ? parseInt(active.dataset.v) : 0;
	}

	function dpLockPrefs(lock) {
		var body = document.getElementById('dp-prefs-body');
		if (body) body.classList.toggle('dp-locked', !!lock);
	}
	function dpRender(p) {
		dpSetToggle('ShowName',         !p.IsAnonymous);
		dpSetToggle('NoRestrictions',    p.NoRestrictions);
		dpLockPrefs(p.NoRestrictions);
		dpSetToggle('DietVegetarian',    p.DietVegetarian);
		dpSetToggle('DietVegan',         p.DietVegan);
		dpSetToggle('DietHalal',         p.DietHalal);
		dpSetToggle('DietKosher',        p.DietKosher);
		dpSetToggle('DietKeto',          p.DietKeto);
		dpSetToggle('DietPaleo',         p.DietPaleo);
		dpSetToggle('RestrictDairy',     p.RestrictDairy);
		dpSetToggle('RestrictEggs',      p.RestrictEggs);
		dpSetToggle('RestrictFish',      p.RestrictFish);
		dpSetToggle('RestrictHoney',     p.RestrictHoney);
		dpSetToggle('RestrictPoultry',   p.RestrictPoultry);
		dpSetToggle('RestrictBeef',      p.RestrictBeef);
		dpSetToggle('RestrictPork',      p.RestrictPork);
		dpSetToggle('RestrictShellfish', p.RestrictShellfish);
		ALLERGEN_FIELDS.forEach(function(f) {
			var grp = gInModal('.dp-al-slider[data-field="' + f + '"]');
			if (grp) dpSetAllergen(grp, p[f] || 0);
		});
	}

	function dpCollect() {
		var d = {
			IsAnonymous:       dpToggleValue('ShowName')        ? 0 : 1,
			NoRestrictions:    dpToggleValue('NoRestrictions')  ? 1 : 0,
			DietVegetarian:    dpToggleValue('DietVegetarian')  ? 1 : 0,
			DietVegan:         dpToggleValue('DietVegan')       ? 1 : 0,
			DietHalal:         dpToggleValue('DietHalal')       ? 1 : 0,
			DietKosher:        dpToggleValue('DietKosher')      ? 1 : 0,
			DietKeto:          dpToggleValue('DietKeto')        ? 1 : 0,
			DietPaleo:         dpToggleValue('DietPaleo')       ? 1 : 0,
			RestrictDairy:     dpToggleValue('RestrictDairy')   ? 1 : 0,
			RestrictEggs:      dpToggleValue('RestrictEggs')    ? 1 : 0,
			RestrictFish:      dpToggleValue('RestrictFish')    ? 1 : 0,
			RestrictHoney:     dpToggleValue('RestrictHoney')   ? 1 : 0,
			RestrictPoultry:   dpToggleValue('RestrictPoultry') ? 1 : 0,
			RestrictBeef:      dpToggleValue('RestrictBeef') ? 1 : 0,
			RestrictPork:      dpToggleValue('RestrictPork') ? 1 : 0,
			RestrictShellfish: dpToggleValue('RestrictShellfish') ? 1 : 0,
		};
		ALLERGEN_FIELDS.forEach(function(f) { d[f] = dpGetAllergen(f); });
		return d;
	}

	// ---- Summary card ----
	var DIET_LABELS = {DietVegetarian:'Vegetarian',DietVegan:'Vegan',DietHalal:'Halal',DietKosher:'Kosher',DietKeto:'Keto',DietPaleo:'Paleo'};
	var RESTRICT_LABELS = {RestrictBeef:'No Beef',RestrictDairy:'No Dairy',RestrictEggs:'No Eggs',RestrictFish:'No Fish',RestrictHoney:'No Honey',RestrictPork:'No Pork',RestrictPoultry:'No Poultry',RestrictShellfish:'No Shellfish'};
	var ALLERGEN_LABELS = {AllergenPeanuts:'Peanuts',AllergenTreenuts:'Tree Nuts',AllergenWheat:'Wheat',AllergenMilk:'Milk',AllergenEggs:'Eggs',AllergenFish:'Fish',AllergenShellfish:'Shellfish',AllergenSoy:'Soy',AllergenSesame:'Sesame',AllergenGarlic:'Garlic',AllergenGluten:'Gluten',AllergenOnion:'Onion',AllergenMushroom:'Mushroom',AllergenCorn:'Corn',AllergenCoconut:'Coconut',AllergenCocoa:'Cocoa',AllergenNightshades:'Nightshades'};

	function dpUpdateSummary(p) {
		var el = document.getElementById('pna-dp-summary');
		if (!el) return;
		if (p.NoRestrictions) { el.textContent = 'No dietary restrictions.'; return; }
		var parts = [];
		Object.keys(DIET_LABELS).forEach(function(f)     { if (p[f]) parts.push(DIET_LABELS[f]); });
		Object.keys(RESTRICT_LABELS).forEach(function(f) { if (p[f]) parts.push(RESTRICT_LABELS[f]); });
		ALLERGEN_FIELDS.forEach(function(f) {
			if (p[f] >= 2) parts.push(ALLERGEN_LABELS[f] + ' allergy');
			else if (p[f] >= 1) parts.push(ALLERGEN_LABELS[f] + ' sensitivity');
		});
		el.textContent = parts.length ? parts.slice(0,4).join(', ') + (parts.length > 4 ? ' +' + (parts.length - 4) + ' more' : '') : 'No preferences set.';
	}

	// ---- Dirty tracking ----
	function dpMarkDirty() {
		if (!dpDirty) {
			dpDirty = true;
			var warn = document.getElementById('pn-dp-dirty-warn');
			var btn  = document.getElementById('pn-dp-save-btn');
			if (warn) warn.style.display = 'inline';
			if (btn)  btn.disabled = false;
		}
	}
	function dpClearDirty() {
		dpDirty = false;
		var warn = document.getElementById('pn-dp-dirty-warn');
		var btn  = document.getElementById('pn-dp-save-btn');
		if (warn) warn.style.display = 'none';
		if (btn)  { btn.disabled = true; btn.innerHTML = '<i class="fas fa-save"></i> Save'; }
	}

	// ---- Open / close ----
	window.dpOpen = function() {
		var ov = document.getElementById('pn-dp-overlay');
		if (!ov) return;
		dpClearDirty();
		if (dpLoaded) {
			dpSnap = dpCollect();
		}
		ov.classList.add('pn-open');
		if (!dpLoaded) {
			$.getJSON(DP_LOAD_URL, function(r) {
				if (r && r.status === 0 && r.prefs) {
					dpRender(r.prefs);
					dpUpdateSummary(r.prefs);
					dpLoaded = true;
					dpSnap = dpCollect();
					dpClearDirty();
				}
			});
		}
	};

	function dpClose(force) {
		function doClose() {
			document.getElementById('pn-dp-overlay').classList.remove('pn-open');
			var pop = document.getElementById('dp-info-pop');
			if (pop) pop.classList.remove('dp-pop-open');
			if (dpSnap) { dpRender(dpSnap); dpClearDirty(); }
		}
		if (!force && dpDirty) {
			pnConfirm({ title: 'Unsaved Changes', message: 'Close without saving your feast preferences?', confirmText: 'Discard', danger: true }, doClose);
		} else {
			doClose();
		}
	}

	// ---- Save ----
	function dpSave() {
		var btn = document.getElementById('pn-dp-save-btn');
		if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving…'; }
		var data = dpCollect();
		var fd = new FormData();
		Object.keys(data).forEach(function(k) { fd.append(k, data[k]); });
		fetch(DP_SAVE_URL, { method: 'POST', body: fd })
			.then(function(res) { return res.json(); })
			.then(function(r) {
				if (r && r.status === 0) {
					dpSnap = data;
					dpClearDirty();
					dpUpdateSummary(data);
					document.getElementById('pn-dp-overlay').classList.remove('pn-open');
				} else {
					if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> Save'; }
				}
			})
			.catch(function() {
				if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-save"></i> Save'; }
			});
	}

	// ---- Wire modal controls ----
	function dpClearNoRestrictions() {
		if (noRestSw && noRestSw.classList.contains('dp-on')) {
			noRestSw.classList.remove('dp-on');
			dpLockPrefs(false);
		}
	}
	allInModal('.dp-toggle-sw').forEach(function(sw) {
		// Skip NoRestrictions (has its own row-click handler below) AND
		// ShowName (unrelated to dietary state — clicking it should NOT
		// clear No dietary restrictions).
		if (sw.dataset.field === 'NoRestrictions' || sw.dataset.field === 'ShowName') return;
		sw.addEventListener('click', function() { dpClearNoRestrictions(); sw.classList.toggle('dp-on'); dpMarkDirty(); });
	});
	// ShowName toggle: just flip its own state — no side-effects on the
	// rest of the form.
	var showNameSw = gInModal('.dp-toggle-sw[data-field="ShowName"]');
	if (showNameSw) {
		showNameSw.addEventListener('click', function() { showNameSw.classList.toggle('dp-on'); dpMarkDirty(); });
	}
	allInModal('.dp-al-seg').forEach(function(btn) {
		btn.addEventListener('click', function() {
			dpClearNoRestrictions();
			var grp = btn.closest('.dp-al-slider');
			if (grp) { dpSetAllergen(grp, btn.dataset.v); dpMarkDirty(); }
		});
	});

	// No-restrictions master toggle — whole row is clickable
	var noRestSw  = gInModal('.dp-toggle-sw[data-field="NoRestrictions"]');
	var noRestRow = document.getElementById('dp-no-restrict-row');
	if (noRestSw && noRestRow) {
		noRestRow.addEventListener('click', function() {
			var turningOn = !noRestSw.classList.contains('dp-on');
			noRestSw.classList.toggle('dp-on', turningOn);
			if (turningOn) {
				allInModal('.dp-toggle-sw[data-field]').forEach(function(sw) {
					if (sw.dataset.field !== 'ShowName' && sw.dataset.field !== 'NoRestrictions')
						sw.classList.remove('dp-on');
				});
				allInModal('.dp-al-slider').forEach(function(grp) { dpSetAllergen(grp, 0); });
			}
			dpLockPrefs(turningOn);
			dpMarkDirty();
		});
	}
	document.getElementById('pn-dp-close-btn').addEventListener('click',  function() { dpClose(); });
	document.getElementById('pn-dp-cancel-btn').addEventListener('click',  function() { dpClose(); });
	document.getElementById('pn-dp-save-btn').addEventListener('click',    dpSave);
	document.getElementById('pn-dp-overlay').addEventListener('click',     function(e) { if (e.target === this) dpClose(); });
	document.addEventListener('keydown', function(e) {
		if ((e.key === 'Escape' || e.keyCode === 27) && document.getElementById('pn-dp-overlay').classList.contains('pn-open'))
			dpClose();
	});

	// Info popover
	var dpInfoPop = document.getElementById('dp-info-pop');
	allInModal('[data-info-btn]').forEach(function(btn) {
		btn.addEventListener('click', function(e) {
			e.stopPropagation();
			var rect = btn.getBoundingClientRect();
			var isOpen = dpInfoPop.classList.contains('dp-pop-open');
			dpInfoPop.classList.remove('dp-pop-open');
			if (isOpen) return;
			var top  = rect.bottom + 6;
			var left = rect.left;
			if (left + 295 > window.innerWidth - 10) left = window.innerWidth - 305;
			dpInfoPop.style.top  = top  + 'px';
			dpInfoPop.style.left = left + 'px';
			dpInfoPop.classList.add('dp-pop-open');
		});
	});
	document.addEventListener('click', function() { if (dpInfoPop) dpInfoPop.classList.remove('dp-pop-open'); });

	// Pre-load on page load so summary is populated immediately
	$.getJSON(DP_LOAD_URL, function(r) {
		if (r && r.status === 0 && r.prefs) {
			dpRender(r.prefs);
			dpUpdateSummary(r.prefs);
			dpLoaded = true;
			dpSnap = dpCollect();
		}
	});
})();
