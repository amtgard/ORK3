
(function () {
  // ---- Helpers --------------------------------------------------------

  function fmtNum(n, decimals) {
    if (n == null) return "&mdash;";
    if (decimals != null) {
      return parseFloat(n).toLocaleString("en-US", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      });
    }
    return parseInt(n, 10).toLocaleString("en-US");
  }

  function buildCard(value, label, icon, accentClass, tip) {
    return (
      "<div class=\"sor-players-card sor-tip-card " + (accentClass || "") + "\"" +
      (tip ? " data-tip=\"" + tip + "\"" : "") + ">" +
      "<span class=\"sor-players-card-icon\">" + icon + "</span>" +
      "<div class=\"sor-players-card-value\">" + value + "</div>" +
      "<div class=\"sor-players-card-label\">" + label + "</div>" +
      "</div>"
    );
  }

  function buildProseCol(title, stats, isNormal) {
    var s = stats;
    var intro = isNormal
      ? "Among <strong>normal players</strong> (4+ sign-ins), there were <strong>" + fmtNum(s.total_sign_ins) + "</strong> sign-ins recorded for <strong>" + fmtNum(s.count) + "</strong> players."
      : "There were <strong>" + fmtNum(s.total_sign_ins) + "</strong> sign-ins recorded for <strong>" + fmtNum(s.total_players) + "</strong> players this period.";

    var lifespanLine = s.avg_lifespan_years != null
      ? "<br>On average, a player participated for <strong>" + fmtNum(s.avg_lifespan_years, 1) + " years</strong>."
      : "";

    return (
      "<div class=\"sor-players-prose-col\">" +
      "<h4>" + title + "</h4>" +
      "<p>" + intro +
      " On average, a player signed in <strong>" + fmtNum(s.avg_sign_ins, 1) + "</strong> times" +
      " (std dev <strong>&plusmn;" + fmtNum(s.std_dev_sign_ins, 1) + "</strong>)." +
      " The range was <strong>" + fmtNum(s.min_sign_ins) + "</strong> to <strong>" + fmtNum(s.max_sign_ins) + "</strong> sign-ins." +
      lifespanLine +
      "</p>" +
      "<p>Players averaged <strong>" + fmtNum(s.avg_credits, 1) + " credits</strong>" +
      (s.avg_credits_per_week != null
        ? " (<strong>" + fmtNum(s.avg_credits_per_week, 1) + "</strong> credits/week)."
        : ".") +
      "</p>" +
      "</div>"
    );
  }

  // ---- Main render function -------------------------------------------

  window.renderSorPlayers = function (data) {
    var p  = data && data.players;
    var np = p && p.normal_players;
    var ty = p && p.ten_year;
    var tyNp = ty && ty.normal_players;

    // T-5: Null guard
    if (!p || !np || !ty || !tyNp) {
      document.getElementById('sor-players-skeleton').style.display = 'none';
      document.getElementById('sor-players-content').style.display = '';
      document.getElementById('sor-players-period-cards').innerHTML = '<p style="color:#c0392b;padding:20px">Error loading player data.</p>';
      return;
    }

    // --- Period stat cards ---
    var cardsHtml =
      buildCard(fmtNum(p.total_sign_ins), "Total Sign-Ins", "&#9997;", "",
        "Total attendance records in the period. Each park event check-in counts as one sign-in.") +
      buildCard(fmtNum(p.total_players), "Active Players", "&#128101;", "accent-blue",
        "Unique players (mundane IDs) with at least one sign-in during the period.") +
      buildCard(fmtNum(p.avg_sign_ins, 1), "Avg Sign-Ins / Player", "&#128200;", "accent-green",
        "Total sign-ins divided by unique active players. Higher = more frequent attendance.") +
      buildCard(fmtNum(p.normal_players.count), "Normal Players", "&#11088;", "accent-amber",
        "Players with 4+ sign-ins AND 12+ total credits earned. Identifies committed members vs casual visitors.") +
      buildCard((p.total_players > 0 ? ((p.normal_players.count / p.total_players) * 100).toFixed(1) : '0') + '%', "Engagement Rate", "&#127919;", "accent-red",
        "Normal Players / Active Players. What fraction of active players meet the committed-member threshold.");
    document.getElementById("sor-players-period-cards").innerHTML = cardsHtml;

    // --- Prose stats ---
    var allStats = {
      total_sign_ins:       p.total_sign_ins,
      total_players:        p.total_players,
      avg_sign_ins:         p.avg_sign_ins,
      std_dev_sign_ins:     p.std_dev_sign_ins,
      min_sign_ins:         p.min_sign_ins,
      max_sign_ins:         p.max_sign_ins,
      avg_credits:          p.avg_credits,
      avg_credits_per_week: p.avg_credits_per_week
    };
    var normalStats = {
      count:                p.normal_players.count,
      total_sign_ins:       p.normal_players.total_sign_ins,
      avg_sign_ins:         p.normal_players.avg_sign_ins,
      std_dev_sign_ins:     p.normal_players.std_dev_sign_ins,
      min_sign_ins:         p.normal_players.min_sign_ins,
      max_sign_ins:         p.normal_players.max_sign_ins,
      avg_credits:          p.normal_players.avg_credits,
      avg_credits_per_week: p.normal_players.avg_credits_per_week
    };
    document.getElementById("sor-players-prose").innerHTML =
      buildProseCol("All Players", allStats, false) +
      buildProseCol("Normal Players (4+ Sign-Ins)", normalStats, true);

    // --- Show content, hide skeleton before any chart renders (error #13) ---
    document.getElementById("sor-players-skeleton").style.display = "none";
    document.getElementById("sor-players-content").style.display = "";

    // --- Trend chart ---
    var trend       = p.trend_by_year        || [];
    var trendNormal = p.trend_normal_by_year  || [];
    var chartYears  = trend.map(function (r) { return r.year.toString(); });
    var chartValues = trend.map(function (r) { return r.sign_ins; });
    // Build normal-player values aligned to same years
    var normYearMap = {};
    trendNormal.forEach(function (r) { normYearMap[r.year] = r.normal_players; });
    var chartValuesNorm = trend.map(function (r) { return normYearMap[r.year] || 0; });

    if (typeof Highcharts !== 'undefined') {
      window.sorDestroyChart('sor-players-chart');
      new Highcharts.Chart({
        chart: {
          renderTo: "sor-players-chart",
          type: "line",
          height: 300,
          style: { fontFamily: "inherit" },
          backgroundColor: "transparent",
          plotBorderColor: "#e0e0e0",
          spacingTop: 10,
          spacingBottom: 10
        },
        title: { text: null },
        credits: { enabled: false },
        xAxis: {
          categories: chartYears,
          labels: {
            style: { fontSize: "11px", color: "#555" }
          },
          lineColor: "#ddd",
          tickColor: "#ddd"
        },
        yAxis: [
          {
            title: { text: "Annual Sign-Ins", style: { color: "#2980b9", fontSize: "11px" } },
            gridLineColor: "#efefef",
            labels: {
              formatter: function () {
                var v = this.value;
                return v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v;
              },
              style: { fontSize: "11px", color: "#2980b9" }
            },
            min: 0
          },
          {
            title: { text: "Normal Players", style: { color: "#c0392b", fontSize: "11px" } },
            opposite: true,
            gridLineColor: "transparent",
            labels: {
              formatter: function () {
                var v = this.value;
                return v >= 1000 ? (v / 1000).toFixed(1).replace(/\.0$/, '') + 'k' : v;
              },
              style: { fontSize: "11px", color: "#c0392b" }
            },
            min: 0
          }
        ],
        tooltip: {
          shared: true,
          useHTML: true,
          backgroundColor: "#1a1a2e",
          borderColor: "#c0392b",
          borderRadius: 6,
          style: { color: "#fff", fontSize: "12px" },
          formatter: function () {
            var pts = this.points || [];
            var si   = pts[0] ? pts[0].y : 0;
            var norm = pts[1] ? pts[1].y : 0;
            return "<b>" + this.x + "</b><br/>"
              + '<span style="color:#90caf9">●</span> Sign-Ins: <b>' + si.toLocaleString('en-US') + '</b><br/>'
              + '<span style="color:#e67e7e">●</span> Normal Players: <b>' + norm.toLocaleString('en-US') + '</b>';
          }
        },
        plotOptions: {
          series: { animation: { duration: 500 } }
        },
        legend: {
          enabled: true,
          itemStyle: { fontSize: '11px', fontWeight: '600', color: window.sorThemeColor('--ork-text-secondary', '#555') }
        },
        series: [
          { name: "Annual Sign-Ins", type: "areaspline", yAxis: 0, data: chartValues,
            color: "#2980b9", fillOpacity: 0.12, lineWidth: 2,
            marker: { enabled: true, radius: 4, symbol: "circle",
                      fillColor: "#2980b9", lineColor: "#fff", lineWidth: 1 } },
          { name: "Normal Players",  type: "line",       yAxis: 1, data: chartValuesNorm,
            color: "#c0392b", lineWidth: 2.5, dashStyle: "ShortDash",
            marker: { enabled: true, radius: 5, symbol: "circle",
                      fillColor: "#c0392b", lineColor: "#fff", lineWidth: 1.5 } }
        ]
      });
    } else {
      document.getElementById('sor-players-chart').innerHTML = '<p style="color:#999;padding:20px;text-align:center">Chart unavailable.</p>';
    }

    // --- 10-year cards ---
    ty = p.ten_year;
    var tyCardsHtml =
      buildCard(fmtNum(ty.total_sign_ins), "Total Sign-Ins (10 yr)", "&#9997;", "") +
      buildCard(fmtNum(ty.total_players), "Unique Players (10 yr)", "&#128101;", "accent-blue") +
      buildCard(fmtNum(ty.avg_sign_ins, 1), "Avg Sign-Ins / Player", "&#128200;", "accent-green") +
      buildCard(fmtNum(ty.normal_players.count), "Normal Players", "&#11088;", "accent-amber");
    document.getElementById("sor-players-tenyear-cards").innerHTML = tyCardsHtml;

    // --- 10-year prose ---
    var tyAllStats = {
      total_sign_ins:       ty.total_sign_ins,
      total_players:        ty.total_players,
      avg_sign_ins:         ty.avg_sign_ins,
      std_dev_sign_ins:     ty.std_dev_sign_ins,
      min_sign_ins:         ty.min_sign_ins,
      max_sign_ins:         ty.max_sign_ins,
      avg_credits:          ty.avg_credits,
      avg_credits_per_week: ty.avg_credits_per_week,
      avg_lifespan_years:   ty.avg_lifespan_years
    };
    var tyNormalStats = {
      count:                ty.normal_players.count,
      total_sign_ins:       ty.normal_players.total_sign_ins,
      avg_sign_ins:         ty.normal_players.avg_sign_ins,
      std_dev_sign_ins:     ty.normal_players.std_dev_sign_ins,
      min_sign_ins:         ty.normal_players.min_sign_ins,
      max_sign_ins:         ty.normal_players.max_sign_ins,
      avg_credits:          ty.normal_players.avg_credits,
      avg_credits_per_week: ty.normal_players.avg_credits_per_week,
      avg_lifespan_years:   ty.normal_players.avg_lifespan_years
    };
    document.getElementById("sor-players-tenyear-prose").innerHTML =
      buildProseCol("All Players (10 Years)", tyAllStats, false) +
      buildProseCol("Normal Players — 10 Years", tyNormalStats, true);

  };


  // ---- Cohort funnel renderer (called from orchestrator cohorts fetch) ----
  // renderSorCohorts: just show container; chart drawn in sorDrawFunnelChart() after all payloads load
  window.renderSorCohorts = function (data) {
    if (data && data.cohorts) {
      var funnelEl = document.getElementById('sor-players-funnel');
      if (funnelEl) funnelEl.style.display = '';
    }
  };

  window.sorDrawFunnelChart = function () {
    var _p   = window._sorPayloads || {};
    var co   = _p['cohorts'] && _p['cohorts'].cohorts;
    var pPay = _p['players'] && _p['players'].players;
    if (!co || !pPay) return;
    if (typeof Highcharts === 'undefined') return;
    var funnelEl = document.getElementById('sor-players-funnel');
    if (funnelEl) funnelEl.style.display = '';
    var allP  = pPay.total_players || 0;
    var normP = (pPay.normal_players || {}).count || 0;
    var retP  = parseInt(co.returning_players || 0, 10);
    var newP  = parseInt(co.new_players       || 0, 10);
    var funnelData = [
      { name: 'All Active Players',    y: allP,  color: '#90caf9' },
      { name: 'Normal Players (4+ SI)',y: normP, color: '#2980b9' },
      { name: 'Returning Players',     y: retP,  color: '#27ae60' },
      { name: 'New Players',           y: newP,  color: '#f39c12' }
    ];
    var maxV = allP || 1;
    window.sorDestroyChart('sor-players-funnel-chart');
    new Highcharts.Chart({

      chart: { renderTo: 'sor-players-funnel-chart', type: 'bar', height: 140, backgroundColor: 'transparent',
               margin: [4, 120, 24, 170], style: { fontFamily: 'inherit' } },
      title: { text: null }, credits: { enabled: false }, legend: { enabled: false },
      xAxis: { categories: funnelData.map(function (d) { return d.name; }),
               labels: { style: { fontSize: '11px', fontWeight: '600' } } },
      yAxis: { min: 0, max: maxV, visible: false },
      tooltip: { backgroundColor: '#1a1a2e', borderColor: '#c0392b', style: { color: '#fff' },
                 formatter: function () {
                   var pct = maxV > 0 ? ((this.y / maxV) * 100).toFixed(1) : '0';
                   return '<b>' + this.x + '</b><br/>' + this.y.toLocaleString('en-US')
                     + ' players (' + pct + '% of active)';
                 }},
      plotOptions: { bar: { borderWidth: 0, borderRadius: 3,
        dataLabels: { enabled: true, align: 'right', inside: false,
          formatter: function () {
            var pct = maxV > 0 ? ' (' + ((this.y / maxV) * 100).toFixed(0) + '%)' : '';
            return this.y.toLocaleString('en-US') + pct;
          },
          style: { fontSize: '11px', fontWeight: '600', textShadow: 'none', color: window.sorThemeColor('--ork-text', '#333') } } } },
      series: [{ name: 'Players', data: funnelData.map(function (d) { return { y: d.y, color: d.color }; }) }]
    });
  };

  // ---- 10-year toggle ------------------------------------------------
  window.sorPlayersToggleTenYear = function () {
    var btn  = document.getElementById("sor-players-tenyear-btn");
    var body = document.getElementById("sor-players-tenyear-body");
    var isOpen = btn.classList.contains("open");
    if (isOpen) {
      btn.classList.remove("open");
      body.classList.remove("open");
    } else {
      btn.classList.add("open");
      body.classList.add("open");
    }
  };

}());
