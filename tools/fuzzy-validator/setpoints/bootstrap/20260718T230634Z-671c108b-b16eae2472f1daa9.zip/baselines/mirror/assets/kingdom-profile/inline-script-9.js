
/* Recommendation Seconds — shared handlers. Idempotent: safe if included twice. */
(function() {
	if (window.__rsSecondsBound) return;
	window.__rsSecondsBound = true;

	var Cfg = window.OrkRsCfg || { uir: '/orkui/', userId: 0, reload: function() { location.reload(); } };
	if (!Cfg.userId) return;  // anonymous viewers don't get the modals; UI is hidden anyway

	function gid(id) { return document.getElementById(id); }
	function reload() { try { (Cfg.reload || function() { location.reload(); })(); } catch (e) { location.reload(); } }

	// ---- Second / Edit Notes modal ----
	var secOverlay = gid('rs-second-overlay');
	var secNotes   = gid('rs-second-notes');
	var secCount   = gid('rs-second-char-count');
	var secErr     = gid('rs-second-error');
	var secCtx     = gid('rs-second-context');
	var secTitle   = gid('rs-second-title');
	var secSubLbl  = gid('rs-second-submit-label');
	var secMode    = { kind: 'add', recId: 0, secondId: 0 };

	function openSecondModal(opts) {
		if (!secOverlay) return;
		secMode = opts;
		secErr.style.display = 'none';
		secNotes.value = opts.notes || '';
		secCount.textContent = Math.max(0, 400 - secNotes.value.length) + ' characters remaining';
		if (opts.kind === 'add') {
			secTitle.textContent = 'Second this Recommendation';
			secSubLbl.textContent = 'Add Second';
			secCtx.textContent = "You're seconding the recommendation of " + (opts.award || 'this award') + (opts.recipient ? ' for ' + opts.recipient : '') + '. Notes are optional but help the awarding officer.';
		} else {
			secTitle.textContent = 'Edit Your Notes';
			secSubLbl.textContent = 'Save Changes';
			secCtx.textContent = 'Update the notes attached to your second.';
		}
		secOverlay.classList.add('pn-open');
		setTimeout(function() { secNotes.focus(); }, 50);
	}
	function closeSecondModal() { if (secOverlay) secOverlay.classList.remove('pn-open'); }

	if (secNotes) {
		secNotes.addEventListener('input', function() {
			secCount.textContent = Math.max(0, 400 - secNotes.value.length) + ' characters remaining';
		});
	}
	var secCloseBtn = gid('rs-second-close-btn'); if (secCloseBtn) secCloseBtn.addEventListener('click', closeSecondModal);
	var secCancel   = gid('rs-second-cancel');    if (secCancel)   secCancel.addEventListener('click', closeSecondModal);
	if (secOverlay) secOverlay.addEventListener('click', function(e) { if (e.target === secOverlay) closeSecondModal(); });
	document.addEventListener('keydown', function(e) {
		if ((e.key === 'Escape' || e.keyCode === 27) && secOverlay && secOverlay.classList.contains('pn-open')) closeSecondModal();
	});

	function escAttr(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }
	function escHtml(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }

	function buildNotesSpanHtml(notes) {
		if (notes && notes.length > 0) {
			var inner;
			if (notes.length > 50) {
				inner = '<span class="pk-rec-notes-short">' + escHtml(notes.substring(0, 50))
					+ '<span class="pk-rec-notes-ellipsis">&hellip; <button class="pk-rec-expand-btn" type="button">[&hellip;]</button></span>'
					+ '<span class="pk-rec-notes-full" style="display:none">' + escHtml(notes.substring(50)) + ' <button class="pk-rec-expand-btn pk-rec-collapse-btn" type="button">[&laquo;]</button></span>'
					+ '</span>';
			} else {
				inner = escHtml(notes);
			}
			return '<span class="rs-notes">&mdash; "' + inner + '"</span>';
		}
		return '';
	}

	function buildOwnSecondHtml(secondId, notes, supPersona) {
		var supLink = '<a class="rs-supporter" href="' + Cfg.uir + 'Player/profile/' + parseInt(Cfg.userId) + '">' + escHtml(supPersona || 'You') + '</a>';
		var notesPart = buildNotesSpanHtml(notes);
		var actions = '<button class="rs-second-edit" data-sid="' + parseInt(secondId) + '" data-notes="' + escAttr(notes) + '" data-rstip="Edit your notes"><i class="fas fa-pen"></i></button>'
			+ '<button class="rs-second-withdraw" data-sid="' + parseInt(secondId) + '" data-supporter="' + escAttr(supPersona || '') + '" data-rstip="Withdraw your second"><i class="fas fa-times"></i></button>';
		return '<div class="rs-second"><i class="fas fa-thumbs-up" style="color:#48bb78;font-size:10px"></i>' + supLink + notesPart + ' <span class="rs-second-actions">' + actions + '</span></div>';
	}

	function patchSecondNotesEdited(secondId, newNotes) {
		var editBtn = document.querySelector('.rs-second-edit[data-sid="' + parseInt(secondId) + '"]');
		if (!editBtn) return false;
		var secondEl = editBtn.closest('.rs-second');
		if (!secondEl) return false;
		var holder = document.createElement('div');
		holder.innerHTML = buildNotesSpanHtml(newNotes);
		var newNotesEl = holder.firstChild; // null when newNotes is empty (no-comment second)
		var oldNotes = secondEl.querySelector('.rs-notes, .rs-notes-empty');
		if (oldNotes) {
			if (newNotesEl) secondEl.replaceChild(newNotesEl, oldNotes);
			else secondEl.removeChild(oldNotes);
		} else if (newNotesEl) {
			var actions = secondEl.querySelector('.rs-second-actions');
			if (actions) secondEl.insertBefore(newNotesEl, actions);
			else secondEl.appendChild(newNotesEl);
		}
		editBtn.setAttribute('data-notes', newNotes || '');
		return true;
	}

	function patchSecondAdded(recId, secondId, notes, supPersona) {
		var row = document.querySelector('tr[data-rec-id="' + parseInt(recId) + '"]');
		if (!row) return false;
		var seconds = row.querySelector('.rs-seconds');
		if (!seconds) {
			var notesCell = row.querySelector('.pk-rec-notes');
			if (!notesCell) return false;
			seconds = document.createElement('div');
			seconds.className = 'rs-seconds';
			notesCell.appendChild(seconds);
		}
		var holder = document.createElement('div');
		holder.innerHTML = buildOwnSecondHtml(secondId, notes, supPersona);
		seconds.appendChild(holder.firstChild);

		var actionsCell = row.querySelector('.pk-rec-actions');
		var badge = actionsCell ? actionsCell.querySelector('.rs-seconds-badge') : null;
		if (badge) {
			var prior = parseInt((badge.textContent.match(/\d+/) || ['0'])[0], 10);
			var next = prior + 1;
			badge.innerHTML = '<i class="fas fa-thumbs-up"></i>' + next;
			badge.setAttribute('data-rstip', next + ' supporting ' + (next === 1 ? 'second' : 'seconds'));
		} else if (actionsCell) {
			var b = document.createElement('span');
			b.className = 'rs-seconds-badge';
			b.setAttribute('data-rstip', '1 supporting second');
			b.innerHTML = '<i class="fas fa-thumbs-up"></i>1';
			actionsCell.insertBefore(b, actionsCell.firstChild);
		}

		var addBtn = row.querySelector('.rs-action-btn[data-rec="' + parseInt(recId) + '"]');
		if (addBtn) addBtn.style.display = 'none';
		return true;
	}

	function patchSecondWithdrawn(secondId, wasMine) {
		var withdrawBtn = document.querySelector('.rs-second-withdraw[data-sid="' + parseInt(secondId) + '"]');
		if (!withdrawBtn) return false;
		var secondEl = withdrawBtn.closest('.rs-second');
		if (!secondEl) return false;
		var row = withdrawBtn.closest('tr[data-rec-id]');
		var secondsContainer = secondEl.parentNode;
		secondEl.parentNode.removeChild(secondEl);
		if (secondsContainer && secondsContainer.classList.contains('rs-seconds') && !secondsContainer.querySelector('.rs-second')) {
			secondsContainer.parentNode.removeChild(secondsContainer);
		}
		if (row) {
			var actionsCell = row.querySelector('.pk-rec-actions');
			var badge = actionsCell ? actionsCell.querySelector('.rs-seconds-badge') : null;
			if (badge) {
				var prior = parseInt((badge.textContent.match(/\d+/) || ['0'])[0], 10);
				var next = Math.max(0, prior - 1);
				if (next === 0) {
					badge.parentNode.removeChild(badge);
				} else {
					badge.innerHTML = '<i class="fas fa-thumbs-up"></i>' + next;
					badge.setAttribute('data-rstip', next + ' supporting ' + (next === 1 ? 'second' : 'seconds'));
				}
			}
			if (wasMine) {
				var recId = row.getAttribute('data-rec-id');
				var addBtn = row.querySelector('.rs-action-btn[data-rec="' + parseInt(recId) + '"]');
				if (addBtn) addBtn.style.display = '';
			}
		}
		return true;
	}

	var secSubmit = gid('rs-second-submit');
	if (secSubmit) secSubmit.addEventListener('click', function() {
		var notes = secNotes.value || '';
		var url, payload = { notes: notes };
		if (secMode.kind === 'add') url = Cfg.uir + 'PlayerAjax/add_second/' + parseInt(secMode.recId);
		else                        url = Cfg.uir + 'PlayerAjax/edit_second_notes/' + parseInt(secMode.secondId);
		secSubmit.disabled = true;
		jQuery.post(url, payload, function(r) {
			secSubmit.disabled = false;
			if (r.status === 0) {
				if (secMode.kind === 'add') {
					var newSid = parseInt(r.detail, 10) || 0;
					var supPersona = r.supporter_persona || Cfg.userPersona || '';
					var patched = newSid > 0 && patchSecondAdded(secMode.recId, newSid, notes, supPersona);
					closeSecondModal();
					if (!patched) reload();
				} else {
					var patched = patchSecondNotesEdited(secMode.secondId, notes);
					closeSecondModal();
					if (!patched) reload();
				}
			}
			else { secErr.textContent = (r.error || 'Error') + (r.detail ? ': ' + r.detail : ''); secErr.style.display = 'block'; }
		}, 'json').fail(function() {
			secSubmit.disabled = false;
			secErr.textContent = 'Network error — please try again.';
			secErr.style.display = 'block';
		});
	});

	// ---- Edit Reason modal ----
	var erOverlay  = gid('rs-edit-reason-overlay');
	var erText     = gid('rs-edit-reason-text');
	var erCount    = gid('rs-edit-reason-char-count');
	var erErr      = gid('rs-edit-reason-error');
	var erCtx      = gid('rs-edit-reason-context');
	var erRecId    = 0;

	function openEditReason(recId, currentReason, awardName) {
		erRecId = recId;
		erErr.style.display = 'none';
		erText.value = currentReason || '';
		erCount.textContent = Math.max(0, 400 - erText.value.length) + ' characters remaining';
		erCtx.textContent = 'Editing your reason for ' + (awardName || 'this recommendation') + '.';
		erOverlay.classList.add('pn-open');
		setTimeout(function() { erText.focus(); }, 50);
	}
	function closeEditReason() { if (erOverlay) erOverlay.classList.remove('pn-open'); }

	if (erText) {
		erText.addEventListener('input', function() {
			erCount.textContent = Math.max(0, 400 - erText.value.length) + ' characters remaining';
		});
	}
	var erCloseBtn = gid('rs-edit-reason-close-btn'); if (erCloseBtn) erCloseBtn.addEventListener('click', closeEditReason);
	var erCancel   = gid('rs-edit-reason-cancel');    if (erCancel)   erCancel.addEventListener('click', closeEditReason);
	if (erOverlay) erOverlay.addEventListener('click', function(e) { if (e.target === erOverlay) closeEditReason(); });
	document.addEventListener('keydown', function(e) {
		if ((e.key === 'Escape' || e.keyCode === 27) && erOverlay && erOverlay.classList.contains('pn-open')) closeEditReason();
	});

	var erSubmit = gid('rs-edit-reason-submit');
	if (erSubmit) erSubmit.addEventListener('click', function() {
		var reason = (erText.value || '').trim();
		if (!reason.length) { erErr.textContent = 'Reason cannot be empty.'; erErr.style.display = 'block'; return; }
		erSubmit.disabled = true;
		jQuery.post(Cfg.uir + 'PlayerAjax/edit_recommendation_reason/' + parseInt(erRecId), { reason: reason }, function(r) {
			erSubmit.disabled = false;
			if (r.status === 0) { closeEditReason(); reload(); }
			else { erErr.textContent = (r.error || 'Error') + (r.detail ? ': ' + r.detail : ''); erErr.style.display = 'block'; }
		}, 'json').fail(function() {
			erSubmit.disabled = false;
			erErr.textContent = 'Network error — please try again.';
			erErr.style.display = 'block';
		});
	});

	// ---- Delegated click handlers (work for any host page using rs- classes) ----
	jQuery(document).on('click', '.rs-action-btn', function(e) {
		e.preventDefault();
		var btn = e.currentTarget;
		openSecondModal({
			kind: 'add',
			recId:     parseInt(btn.getAttribute('data-rec'))       || 0,
			award:     btn.getAttribute('data-award')                || '',
			recipient: btn.getAttribute('data-recipient')            || '',
			notes:     ''
		});
	});

	jQuery(document).on('click', '.rs-second-edit', function(e) {
		e.preventDefault();
		var btn = e.currentTarget;
		openSecondModal({
			kind: 'edit',
			secondId: parseInt(btn.getAttribute('data-sid')) || 0,
			notes:    btn.getAttribute('data-notes') || ''
		});
	});

	jQuery(document).on('click', '.rs-second-withdraw', function(e) {
		e.preventDefault();
		var btn = e.currentTarget;
		var sid = parseInt(btn.getAttribute('data-sid')) || 0;
		if (!sid) return;
		var isMine = (btn.getAttribute('data-rstip') || '').indexOf('your') !== -1;
		var supporter = btn.getAttribute('data-supporter') || '';
		var doWithdraw = function() {
			btn.disabled = true;
			jQuery.post(Cfg.uir + 'PlayerAjax/withdraw_second/' + sid, {}, function(r) {
				btn.disabled = false;
				if (r.status === 0) {
					var patched = patchSecondWithdrawn(sid, isMine);
					if (!patched) reload();
				}
				else { alert((r.error || 'Error') + (r.detail ? ': ' + r.detail : '')); }
			}, 'json').fail(function() {
				btn.disabled = false;
				alert('Network error — please try again.');
			});
		};
		var adminMsg = supporter
			? 'Remove ' + supporter + '’s second on this recommendation?'
			: 'This second will be removed from the recommendation.';
		var confirmOpts = {
			title: isMine ? 'Withdraw your second?' : 'Remove this second?',
			message: isMine
				? 'Your second on this recommendation will be removed. You can re-add it later if you change your mind.'
				: adminMsg,
			confirmText: isMine ? 'Withdraw' : 'Remove',
			danger: true
		};
		if (typeof window.pnConfirm === 'function') {
			window.pnConfirm(confirmOpts, doWithdraw);
		} else if (confirm(confirmOpts.title)) {
			doWithdraw();
		}
	});

	jQuery(document).on('click', '.rs-edit-reason-btn', function(e) {
		e.preventDefault();
		var btn = e.currentTarget;
		openEditReason(
			parseInt(btn.getAttribute('data-rec')) || 0,
			btn.getAttribute('data-reason') || '',
			btn.getAttribute('data-award')  || ''
		);
	});

	// Expose for hosts that want to refresh manually
	window.OrkRs = { openSecondModal: openSecondModal, openEditReason: openEditReason };
})();
