
(function () {
  'use strict';

  // FIX C: Apply a theme-aware Highcharts default that reads ORK3's CSS vars
  // (`--ork-text*`, `--ork-border`) so chart axes/labels/legend render correctly
  // in both light mode and `html[data-theme="dark"]`. Each chart sets
  // `backgroundColor: 'transparent'` so it inherits the surrounding card surface.
  // The report is fully re-generated on click, so reading vars once at setOptions
  // time is sufficient — no live-toggle re-render needed.
  window.sorThemeColor = function (varName, fallback) {
    try {
      var v = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
      return v || fallback;
    } catch (e) { return fallback; }
  };

  // HTML-escape helper. Two sibling IIFEs define their own local sorEsc, but
  // this orchestrator IIFE (where renderSorAwards lives) was missing one —
  // calling `sorEsc(...)` inside the awards renderer threw a ReferenceError.
  function sorEsc(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  if (typeof Highcharts !== 'undefined' && !window._sorChartThemeApplied) {
    var _axis   = window.sorThemeColor('--ork-text-secondary', '#4a5568');
    var _label  = window.sorThemeColor('--ork-text-muted',     '#718096');
    var _border = window.sorThemeColor('--ork-border',         '#e2e8f0');
    Highcharts.setOptions({
      chart: { backgroundColor: 'transparent' },
      xAxis: { lineColor: _border, tickColor: _border,
               labels: { style: { color: _label } } },
      yAxis: { gridLineColor: _border,
               labels: { style: { color: _label } } },
      legend: { itemStyle:      { color: _axis },
                itemHoverStyle: { color: window.sorThemeColor('--ork-text', '#2d3748') } }
    });
    window._sorChartThemeApplied = true;
  }

  var SOR_BASE_URL = 'http://127.0.0.1:19080/orkui/index.php?Route=AdminAjax/stateofamtgard/';

  // renderSorRetention: new-player conversion & retention KPI panel (no chart).
  window.renderSorRetention = function (data) {
    var content = document.getElementById('sor-players-retention');
    var body    = document.getElementById('sor-retention-body');
    if (!content || !body) return;
    var d = data && data.retention;
    if (!d || !d.headline || !d.headline.cohort) { content.style.display = 'none'; return; }
    var h = d.headline, rj = d.realjoiners || {};
    function pct(v) { return (v === null || v === undefined) ? '—' : (Math.round(v * 10) / 10) + '%'; }
    function num(v) { return (v === null || v === undefined) ? '—' : (Math.round(v * 10) / 10); }
    function n(v)   { return (v || 0).toLocaleString(); }
    function card(value, label) {
      return '<div class="sor-ret-card"><div class="sor-ret-val">' + value + '</div><div class="sor-ret-lbl">' + label + '</div></div>';
    }
    body.innerHTML =
        '<div class="sor-ret-grid">'
      +   card(n(h.cohort),            'new players<br>(mature cohort)')
      +   card(pct(h.pct_one_and_done),'one &amp; done<br>(never returned)')
      +   card(pct(h.pct_realjoin),    'became real joiners<br>(4+ sign-ins)')
      +   card(num(h.median_signins),  'median sign-ins<br>(per player)')
      + '</div>'
      + '<div class="sor-ret-sub">Among real joiners (' + n(rj.n) + '):</div>'
      + '<div class="sor-ret-grid">'
      +   card(pct(rj.active_1yr),              'still active<br>at 1 year')
      +   card(pct(rj.active_2yr),              'still active<br>at 2 years')
      +   card(num(rj.median_tenure_months) + ' mo', 'median tenure<br>(first&rarr;last)')
      +   card(num(rj.median_active_months) + ' mo', 'median active<br>months')
      + '</div>';
    var pc = document.getElementById('sor-players-content');
    if (pc) pc.style.display = '';
    content.style.display = '';
  };

  /* ----------------------------------------------------------------
     Build the query string from current filter values
  ---------------------------------------------------------------- */
  function sorBuildQs() {
    var start = document.getElementById('sor-start').value || '';
    var end   = document.getElementById('sor-end').value   || '';
    var qs = 'start=' + encodeURIComponent(start) + '&end=' + encodeURIComponent(end);

    var sel = document.getElementById('sor-kingdoms');
    if (sel) {
      for (var i = 0; i < sel.options.length; i++) {
        if (sel.options[i].selected) {
          qs += '&kingdoms[]=' + encodeURIComponent(sel.options[i].value);
        }
      }
    }
    return qs;
  }

  /* ----------------------------------------------------------------
     Status helpers
  ---------------------------------------------------------------- */
  var _sorDone     = 0;
  var _sorTotal    = 0; // FIX F: self-incremented in sorFetch, reset to 0 in sorGenerate
  var _sorTimeoutHandle = null; // FIX G: cancelable timeout for hung fetches
  window._sorPayloads = {}; var _sorPayloads = window._sorPayloads;

  function sorSetStatus(msg, cls) {
    var el = document.getElementById('sor-status');
    if (!el) return;
    el.textContent = msg;
    el.className = 'sor-status' + (cls ? ' ' + cls : '');
  }

  function sorSectionDone(section) {
    _sorDone++;
    sorSetStatus('Loading… ' + _sorDone + '/' + _sorTotal + ' complete');
    if (_sorDone >= _sorTotal) {
      // FIX G: report finished naturally — cancel the timeout fallback
      if (_sorTimeoutHandle) { clearTimeout(_sorTimeoutHandle); _sorTimeoutHandle = null; }
      sorSetStatus('Report complete.', 'sor-status-ok');
      var btn = document.getElementById('sor-generate-btn');
      if (btn) btn.disabled = false;
      var pbtn = document.getElementById('sor-print-btn');
      if (pbtn) pbtn.disabled = false; // report is ready → allow Print / Save as PDF
      sorRenderScorecard();
    }
  }

  /* ----------------------------------------------------------------
     Fetch one section
  ---------------------------------------------------------------- */
  function sorFetch(section, qs, renderFn) {
    // _sorTotal is set up-front from the job list in sorGenerate (the pool calls
    // sorFetch gradually, so self-incrementing here made the "x/N" denominator grow).
    // UIR resolves to `.../index.php?Route=` (query-param routing), so the
    // section already sits inside the Route value and additional params must
    // be appended with `&`, not a fresh `?` — using `?` here puts a literal
    // `?` inside the Route value, the section won't match, and $_GET['start']
    // never populates.
    return fetch(SOR_BASE_URL + section + '&' + qs, {credentials: 'same-origin'})
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (data) {
        _sorPayloads[section] = data;
        renderFn(data);
        sorSectionDone(section);
      })
      .catch(function (err) {
        sorSetStatus('Error loading ' + section + ': ' + err.message, 'sor-status-error');
        // Hide skeleton for sections that have one, so they don't hang
        var skMap = { parks: 'sor-parks-skeleton', players: 'sor-players-skeleton',
                      kingdoms: 'sor-kingdoms-skeleton', classes: 'sor-classes-skeleton',
                      longevity: null, cohorts: null, retention: null };
        var sk = skMap[section] && document.getElementById(skMap[section]);
        if (sk) sk.style.display = 'none';
        sorSectionDone(section);
      });
  }

  /* ----------------------------------------------------------------
     Main generate function — exposed globally for inline onclick
  ---------------------------------------------------------------- */
  window.sorGenerate = function () {
    var start = document.getElementById('sor-start').value;
    var end   = document.getElementById('sor-end').value;

    if (!start || !end) {
      sorSetStatus('Please select start and end dates.', 'sor-status-error');
      return;
    }
    if (start > end) {
      sorSetStatus('Start date must be before end date.', 'sor-status-error');
      return;
    }

    // Mirror the server's 12-month cap (production only). Computed via calendar-month
    // math so it matches PHP's strtotime('+12 months'); 0 = unlimited (local/dev).
    var limitMonths = (typeof window.SOR_RANGE_LIMIT_MONTHS === 'number') ? window.SOR_RANGE_LIMIT_MONTHS : 0;
    if (limitMonths > 0) {
      var _sd = new Date(start + 'T00:00:00');
      var _maxEnd = new Date(_sd.getFullYear(), _sd.getMonth() + limitMonths, _sd.getDate());
      if (new Date(end + 'T00:00:00') > _maxEnd) {
        sorSetStatus('The reporting window cannot exceed ' + limitMonths + ' months. Please narrow the date range.', 'sor-status-error');
        return;
      }
    }

    // Check at least one kingdom selected
    var sel = document.getElementById('sor-kingdoms');
    var anySelected = false;
    if (sel) {
      for (var i = 0; i < sel.options.length; i++) {
        if (sel.options[i].selected) { anySelected = true; break; }
      }
    }
    if (!anySelected) {
      sorSetStatus('Please select at least one kingdom.', 'sor-status-error');
      return;
    }

    // Reset counters and show report container
    _sorDone = 0;
    _sorTotal = 0; // reset; set to the job count once the pool is built (below)
    if (_sorTimeoutHandle) { clearTimeout(_sorTimeoutHandle); _sorTimeoutHandle = null; } // FIX G
    window._sorPayloads = {}; _sorPayloads = window._sorPayloads;
    var scEl = document.getElementById('sor-scorecard');
    if (scEl) scEl.style.display = 'none';
    var btn = document.getElementById('sor-generate-btn');
    if (btn) btn.disabled = true;
    var pbtn = document.getElementById('sor-print-btn');
    if (pbtn) pbtn.disabled = true; // re-disable until this run completes
    sorSetStatus('Generating report…');

    // Show report area (sections start in skeleton state)
    document.getElementById('sor-report').style.display = '';

    // Ensure all skeleton loaders are visible and content is hidden
    // T-7: Use explicit IDs instead of attribute selector (avoids matching unrelated skeletons)
    var sorSkeletonIds = ['sor-players-skeleton','sor-kingdoms-skeleton','sor-classes-skeleton','sor-parks-skeleton','sor-awards-skeleton'];
    for (var k = 0; k < sorSkeletonIds.length; k++) { var el = document.getElementById(sorSkeletonIds[k]); if(el) el.style.display = ''; }
    var contents = ['sor-players-content','sor-kingdoms-content','sor-classes-content','sor-parks-content','sor-awards-content'];
    for (var c = 0; c < contents.length; c++) {
      var el = document.getElementById(contents[c]);
      if (el) el.style.display = 'none';
    }

    var qs = sorBuildQs();

    // T-2: Update period subtitle in kingdoms section
    var periodEl = document.getElementById('sor-kingdoms-period');
    if (periodEl) {
      var kStart = document.getElementById('sor-start').value;
      var kEnd   = document.getElementById('sor-end').value;
      periodEl.textContent = kStart + ' — ' + kEnd;
    }

    // Populate print header with report parameters
    var printMeta = document.getElementById('sor-print-meta');
    if (printMeta) {
      var selKd = [];
      if (sel) {
        for (var pi = 0; pi < sel.options.length; pi++) {
          if (sel.options[pi].selected) selKd.push(sel.options[pi].text);
        }
      }
      var kdLabel = (sel && selKd.length === sel.options.length)
        ? 'All Kingdoms'
        : selKd.slice(0, 5).join(', ') + (selKd.length > 5 ? ' (+' + (selKd.length - 5) + ' more)' : '');
      printMeta.textContent = 'Period: ' + start + '—' + end + '  •  Kingdoms: ' + kdLabel;
    }

    // Fire 6 parallel requests
    // Run sections through a small concurrency pool instead of all-at-once.
    // Firing 8 heavy aggregations in parallel saturated the DB on big
    // (all-time / all-kingdom) ranges, so individually-OK queries blew past the
    // timeout. Cap = 3, with heavy sections (classes/parks/players) interleaved
    // among light ones so at most one heavy query runs at a time.
    var SOR_MAX_CONCURRENCY = 3;
    var _sorJobs = [
      ['classes',   window.renderSorClasses],   // heavy
      ['kingdoms',  window.renderSorKingdoms],
      ['cohorts',   window.renderSorCohorts],
      ['parks',     window.renderSorParks],      // heavy
      ['longevity', window.renderSorLongevity],
      ['retention', window.renderSorRetention],
      ['players',   window.renderSorPlayers],    // heavy
      ['awards',    window.renderSorAwards]
    ];
    _sorTotal = _sorJobs.length; // fixed denominator so the "x/N" counter doesn't grow as the pool fires
    var _sorJobIdx = 0;
    function _sorRunNext() {
      if (_sorJobIdx >= _sorJobs.length) return;
      var job = _sorJobs[_sorJobIdx++];
      // sorFetch's .catch resolves, so the promise always settles → queue advances.
      sorFetch(job[0], qs, job[1]).then(_sorRunNext, _sorRunNext);
    }
    for (var _sc = 0; _sc < SOR_MAX_CONCURRENCY && _sc < _sorJobs.length; _sc++) _sorRunNext();

    // FIX G: timeout fallback. If any fetch hangs, force-finish the report with
    // partial data and re-enable the Generate button so the user isn't stuck.
    // Raised to 120s: with the concurrency pool, a full all-time / all-kingdom
    // run is serialized enough to legitimately take ~40-60s on a cold cache.
    _sorTimeoutHandle = setTimeout(function () {
      _sorTimeoutHandle = null;
      if (_sorDone >= _sorTotal) return; // already finished
      sorSetStatus('Some sections timed out — partial data shown.', 'sor-status-error');
      var btn = document.getElementById('sor-generate-btn');
      if (btn) btn.disabled = false;
      var pbtn = document.getElementById('sor-print-btn');
      if (pbtn) pbtn.disabled = false; // allow printing partial results
      try { sorRenderScorecard(); } catch (e) { /* swallow */ }
    }, 120000);
  };

  /* ----------------------------------------------------------------
     Executive Scorecard
  ---------------------------------------------------------------- */
  function sorRenderScorecard() {
    var pData  = _sorPayloads['players'] && _sorPayloads['players'].players;
    var pd     = _sorPayloads['parks']   && _sorPayloads['parks'].parks;
    var co     = _sorPayloads['cohorts'] && _sorPayloads['cohorts'].cohorts;
    var el     = document.getElementById('sor-scorecard');
    if (!el || !pData) return;
    var np       = pData.normal_players || {};
    var eng      = pData.total_players > 0
                   ? ((np.count / pData.total_players) * 100).toFixed(1) : '0.0';
    var netP     = pd ? ((pd.new_parks_count || 0) - (pd.lost_parks_count || 0)) : null;
    var atR      = pd ? (pd.downward_trend_parks || []).length : null;
    function fK(n) {
      // Full comma-separated counts (no "k" abbreviation) — clearer for an exec summary.
      return (parseInt(n, 10) || 0).toLocaleString('en-US');
    }
    function kCard(lbl, val, acc, icon, sub, tip) {
      return '<div class="sor-kpi-card sor-tip-card"' + (tip ? ' data-tip="' + tip + '"' : '') + ' style="border-top-color:' + acc + '">' +
             '<span class="sor-kpi-icon">' + icon + '</span>' +
             '<span class="sor-kpi-value" style="color:' + acc + '">' + val + '</span>' +
             '<span class="sor-kpi-label">' + lbl + '</span>' +
             (sub ? '<span class="sor-kpi-sub">' + sub + '</span>' : '') +
             '</div>';
    }
    var engAcc = parseFloat(eng) >= 40 ? '#27ae60' : (parseFloat(eng) >= 25 ? '#e67e22' : '#c0392b');
    var html =
      kCard('Total Sign-Ins',   fK(pData.total_sign_ins), '#2980b9', '&#9997;',  null,
        'Total attendance records in the period. Each park event check-in = one sign-in.') +
      kCard('Active Players',   fK(pData.total_players),  '#2980b9', '&#128101;',null,
        'Unique players with at least one sign-in during the selected date range.') +
      kCard('Normal Players',   fK(np.count),             '#c0392b', '&#11088;', null,
        'Players with 4+ sign-ins AND 12+ total credits. Filters casual visitors to identify committed members.') +
      kCard('Engagement Rate',  eng + '%',                engAcc,    '&#128200;','normal / all',
        'Normal Players / Active Players. What fraction of active players meet the committed-member threshold.') +
      (pd ? kCard('Active Parks', pd.total_active || 0, '#2c5f6e', '&#127957;', null,
        'Parks with Active status in the selected kingdoms.') : '') +
      (pd && netP !== null ? kCard('Net Park Change', (netP >= 0 ? '+' : '') + netP,
            netP >= 0 ? '#27ae60' : '#c0392b', netP >= 0 ? '&#9650;' : '&#9660;', 'new minus lost',
        'New parks founded minus parks retired during the period.') : '') +
      (pd && atR !== null ? kCard('At-Risk Parks', atR,
            atR === 0 ? '#27ae60' : (atR > 5 ? '#c0392b' : '#e67e22'), '&#9888;&#65039;', 'downward trend',
        'Parks with declining sign-in trend (Spearman r < -0.5 over 5 yrs) AND fewer than 20 sign-ins last year.') : '');
    el.innerHTML = html;
    el.style.display = 'flex';
    if (typeof sorDrawFunnelChart === 'function') sorDrawFunnelChart();
  }


  /* ----------------------------------------------------------------
     Award Grants — render function (called by sorFetch('awards'))
  ---------------------------------------------------------------- */
  // Overall split — matches trend chart palette so Knight/Paragon/Master
  // hold the same color across charts.
  var SOR_AWARDS_OVERALL_COLORS = ['#c0392b', '#2980b9', '#7d3c98'];

  var SOR_AWARDS_KNIGHT_COLORS = [
    '#c0392b', '#d4a017', '#27ae60', '#2980b9', '#7d3c98'
  ];
  var SOR_AWARDS_MASTER_COLORS = [
    '#c0392b', '#e67e22', '#d4a017', '#27ae60', '#16a085',
    '#2980b9', '#5d3fd3', '#8e44ad', '#7f8c8d'
  ];
  var SOR_AWARDS_PARAGON_COLORS = [
    '#c0392b', '#d35400', '#e67e22', '#f39c12', '#d4a017',
    '#a3b117', '#27ae60', '#16a085', '#1abc9c', '#2980b9',
    '#3498db', '#5d3fd3', '#7d3c98', '#8e44ad', '#c44569',
    '#922b21', '#4a5568'
  ];

  function sorAwardsFmtDate(iso) {
    if (!iso) return '';
    /* Accepts "YYYY-MM-DD" or "YYYY-MM-DD HH:MM:SS" */
    var s = String(iso).slice(0, 10);
    var parts = s.split('-');
    if (parts.length !== 3) return sorEsc(iso);
    var y = parseInt(parts[0], 10);
    var m = parseInt(parts[1], 10);
    var d = parseInt(parts[2], 10);
    if (!y || !m || !d) return sorEsc(iso);
    var months = ['Jan','Feb','Mar','Apr','May','Jun',
                  'Jul','Aug','Sep','Oct','Nov','Dec'];
    return months[m - 1] + ' ' + d + ', ' + y;
  }

  function sorAwardsPeeragePill(tier) {
    var t = String(tier || '').toLowerCase();
    var cls = 'sor-awards-peerage-master';
    if (t.indexOf('knight') === 0)  cls = 'sor-awards-peerage-knight';
    else if (t.indexOf('paragon') === 0) cls = 'sor-awards-peerage-paragon';
    return '<span class="sor-awards-peerage-pill ' + cls + '">' + sorEsc(tier || '') + '</span>';
  }

  function sorAwardsRenderKpis(totals) {
    var k = parseInt(totals && totals.knights,  10) || 0;
    var p = parseInt(totals && totals.paragons, 10) || 0;
    var m = parseInt(totals && totals.masters,  10) || 0;
    function kpi(label, value, accent, icon) {
      return '<div class="sor-kpi-card" style="border-top-color:' + accent + '">' +
               '<span class="sor-kpi-icon">' + icon + '</span>' +
               '<span class="sor-kpi-value" style="color:' + accent + '">' + value.toLocaleString('en-US') + '</span>' +
               '<span class="sor-kpi-label">' + label + '</span>' +
             '</div>';
    }
    document.getElementById('sor-awards-kpi-row').innerHTML =
      kpi('Total Knights Granted',  k, '#c0392b', '&#9876;') +
      kpi('Total Paragons Granted', p, '#7d3c98', '&#127942;') +
      kpi('Total Masters Granted',  m, '#2980b9', '&#127891;');

    var ks = document.getElementById('sor-awards-knights-sub');
    var ps = document.getElementById('sor-awards-paragons-sub');
    var ms = document.getElementById('sor-awards-masters-sub');
    if (ks) ks.textContent = k.toLocaleString('en-US') + ' total';
    if (ps) ps.textContent = p.toLocaleString('en-US') + ' total';
    if (ms) ms.textContent = m.toLocaleString('en-US') + ' total';
  }

  /* Strip the peerage prefix so labels stay legible in tightly packed pies
     ("Knight of the Sword" → "Sword", "Paragon Wizard" → "Wizard",
     "Master Rose" → "Rose"). Names without a known prefix (Battlemaster,
     Warlord) are returned unchanged. */
  function sorAwardsShortName(name) {
    return String(name || '').replace(/^(Knight of the |Knight of |Master |Paragon )/i, '');
  }

  function sorAwardsDrawPie(containerId, rows, palette, seriesName) {
    if (typeof Highcharts === 'undefined') return;
    window.sorDestroyChart(containerId);

    /* Drop zero-count slices for clarity. Strip peerage prefix so labels fit. */
    var data = (rows || [])
      .filter(function (r) { return parseInt(r.count, 10) > 0; })
      .map(function (r) {
        var full = String(r.name || '');
        return {
          name:     sorAwardsShortName(full),
          fullName: full,
          y:        parseInt(r.count, 10) || 0
        };
      });

    var container = document.getElementById(containerId);
    if (!container) return;
    if (!data.length) {
      container.innerHTML =
        '<p style="color:#999;padding:40px 12px;text-align:center;font-size:0.85rem">' +
          'No grants in this period.' +
        '</p>';
      return;
    }

    var textColor      = window.sorThemeColor('--ork-text',           '#2d3748');
    var textSecondary  = window.sorThemeColor('--ork-text-secondary', '#4a5568');

    new Highcharts.Chart({
      chart: {
        renderTo:        containerId,
        type:            'pie',
        backgroundColor: 'transparent',
        style:           { fontFamily: 'inherit' },
        animation:       { duration: 550 },
        // Reserve horizontal room so connector legs + labels stay inside the
        // card (otherwise labels like "Battlemaster: 57" get cropped).
        marginLeft:      95,
        marginRight:     95,
        spacingTop:      10,
        spacingBottom:   10
      },
      title:    { text: null },
      subtitle: { text: null },
      credits:  { enabled: false },
      exporting: { enabled: false },
      colors:    palette,

      tooltip: {
        useHTML:         false,
        backgroundColor: 'rgba(26,26,26,0.88)',
        style:           { color: '#fff' },
        borderWidth:     0,
        shadow:          false,
        formatter: function () {
          return '<b>' + (this.point.fullName || this.point.name) + '</b><br/>' +
                 this.y.toLocaleString('en-US') + ' (' +
                 this.percentage.toFixed(1) + '%)';
        }
      },

      plotOptions: {
        pie: {
          allowPointSelect: false,
          cursor:           'pointer',
          borderWidth:      1,
          borderColor:      window.sorThemeColor('--ork-card-bg', '#ffffff'),
          // Reasonable pie size — cards are wider in the 2×2 layout so we
          // can afford a larger pie and still keep the gutters clean.
          size:             '72%',
          dataLabels: {
            enabled:        true,
            useHTML:        false,
            distance:       22,
            connectorWidth: 1,
            connectorPadding: 6,
            softConnector:  true,
            // Allow labels to render even if they would otherwise be clipped
            // — Highcharts auto-vertical-stacks them via softConnector.
            crop:           false,
            overflow:       'allow',
            // Align the label horizontally to the chart's left/right edge so
            // every label on a side starts at the same x — this prevents the
            // staggered cutoff seen with the default radial placement.
            alignTo:        'connectors',
            formatter: function () {
              if (this.percentage < 2) return null;
              return this.point.name + ': ' + this.y;
            },
            style: {
              fontSize:   '13px',
              fontWeight: '600',
              color:      textSecondary,
              textShadow: 'none'
            }
          },
          showInLegend: false
        }
      },

      series: [{
        name: seriesName,
        data: data
      }]
    });
  }

  function sorAwardsDrawTrend(trend) {
    var card      = document.getElementById('sor-awards-trend-card');
    var container = document.getElementById('sor-awards-trend-chart');
    if (!card || !container) return;

    // Hide if missing, empty, or entirely zero
    var hasData = Array.isArray(trend) && trend.length > 0;
    if (hasData) {
      var anyNonZero = false;
      for (var i = 0; i < trend.length; i++) {
        var t = trend[i] || {};
        if ((parseInt(t.knights, 10) || 0) +
            (parseInt(t.masters, 10) || 0) +
            (parseInt(t.paragons, 10) || 0) > 0) {
          anyNonZero = true;
          break;
        }
      }
      hasData = anyNonZero;
    }
    if (!hasData) {
      card.style.display = 'none';
      return;
    }
    card.style.display = '';

    if (typeof Highcharts === 'undefined') return;

    var years    = [];
    var knights  = [];
    var masters  = [];
    var paragons = [];
    for (var j = 0; j < trend.length; j++) {
      var row = trend[j] || {};
      years.push(parseInt(row.year, 10) || 0);
      knights.push(parseInt(row.knights, 10) || 0);
      masters.push(parseInt(row.masters, 10) || 0);
      paragons.push(parseInt(row.paragons, 10) || 0);
    }
    var startYear = years[0];
    var endYear   = years[years.length - 1];

    var textColor      = window.sorThemeColor('--ork-text',           '#2d3748');
    var textSecondary  = window.sorThemeColor('--ork-text-secondary', '#4a5568');
    var textMuted      = window.sorThemeColor('--ork-text-muted',     '#718096');
    var borderColor    = window.sorThemeColor('--ork-border',         '#e2e8f0');

    window.sorDestroyChart('sor-awards-trend-chart');
    new Highcharts.Chart({
      chart: {
        renderTo:        'sor-awards-trend-chart',
        type:            'spline',
        backgroundColor: 'transparent',
        style:           { fontFamily: 'inherit' },
        animation:       { duration: 600 },
        spacingTop:      8,
        spacingBottom:   4
      },
      title: {
        text: '10-Year Peerage Grant Trends',
        style: { fontSize: '0.95rem', fontWeight: '700', color: textColor }
      },
      subtitle: {
        text: startYear + '–' + endYear,
        style: { fontSize: '0.78rem', color: textMuted, letterSpacing: '0.02em' }
      },
      credits:   { enabled: false },
      exporting: { enabled: false },

      xAxis: {
        categories: years.map(function (y) { return String(y); }),
        labels: {
          style: { fontSize: '11px', color: textSecondary }
        },
        lineColor: borderColor,
        tickColor: borderColor
      },
      yAxis: {
        min: 0,
        allowDecimals: false,
        title: {
          text: 'Grants',
          style: { fontSize: '11px', color: textMuted }
        },
        labels: {
          style: { fontSize: '11px', color: textMuted }
        },
        gridLineColor: borderColor
      },

      legend: {
        align: 'center',
        verticalAlign: 'bottom',
        layout: 'horizontal',
        itemStyle: { fontSize: '12px', fontWeight: '600', color: textSecondary },
        itemHoverStyle: { color: textColor }
      },

      tooltip: {
        shared: true,
        useHTML: false,
        backgroundColor: 'rgba(26,26,26,0.88)',
        style:           { color: '#fff', fontSize: '12px' },
        borderWidth:     0,
        shadow:          false,
        headerFormat: '<b>Year {point.key}</b><br/>',
        pointFormat:  '{series.name}: <b>{point.y}</b><br/>'
      },

      plotOptions: {
        series: {
          marker: { enabled: true, radius: 3, symbol: 'circle' },
          lineWidth: 2,
          states: { hover: { lineWidth: 3 } }
        }
      },

      series: [
        { name: 'Knights',  data: knights,  color: '#c0392b' },
        { name: 'Masters',  data: masters,  color: '#7d3c98' },
        { name: 'Paragons', data: paragons, color: '#2980b9' }
      ]
    });
  }

  function sorAwardsRenderKingdomsTable(rows) {
    var tbody = document.getElementById('sor-awards-kingdoms-tbody');
    if (!tbody) return;
    rows = rows || [];
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#999;padding:18px">No peerage grants in this period.</td></tr>';
      return;
    }
    var html = '';
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      html += '<tr>' +
                '<td>' + sorEsc(r.kingdom_name || '') + '</td>' +
                '<td style="text-align:right">' + (parseInt(r.knights,  10) || 0).toLocaleString('en-US') + '</td>' +
                '<td style="text-align:right">' + (parseInt(r.paragons, 10) || 0).toLocaleString('en-US') + '</td>' +
                '<td style="text-align:right">' + (parseInt(r.masters,  10) || 0).toLocaleString('en-US') + '</td>' +
                '<td style="text-align:right"><strong>' + (parseInt(r.total, 10) || 0).toLocaleString('en-US') + '</strong></td>' +
              '</tr>';
    }
    tbody.innerHTML = html;
  }

  window.renderSorAwards = function (data) {
    var skeleton = document.getElementById('sor-awards-skeleton');
    var content  = document.getElementById('sor-awards-content');
    function showError(msg) {
      if (skeleton) skeleton.style.display = 'none';
      if (content)  content.style.display  = '';
      var row = document.getElementById('sor-awards-kpi-row');
      if (row) row.innerHTML = '<p style="color:#c0392b;padding:20px">' + msg + '</p>';
    }
    if (!data || !data.awards) { showError('Error loading awards data.'); return; }
    var a = data.awards;

    /* Show content before charts so Highcharts can measure container dimensions */
    if (skeleton) skeleton.style.display = 'none';
    if (content)  content.style.display  = '';

    try {
      sorAwardsRenderKpis(a.totals || {});
      sorAwardsDrawTrend(a.ten_year_trend || []);
      /* Synthesize an overall-split "pie rows" payload from the totals. */
      var t = a.totals || {};
      var overallRows = [
        { name: 'Knights',  count: parseInt(t.knights,  10) || 0 },
        { name: 'Paragons', count: parseInt(t.paragons, 10) || 0 },
        { name: 'Masters',  count: parseInt(t.masters,  10) || 0 }
      ];
      var overallTotal = overallRows.reduce(function (s, r) { return s + r.count; }, 0);
      var overallSub = document.getElementById('sor-awards-overall-sub');
      if (overallSub) overallSub.textContent = overallTotal.toLocaleString('en-US') + ' total';
      sorAwardsDrawPie('sor-awards-overall-chart',  overallRows,        SOR_AWARDS_OVERALL_COLORS, 'Peerage');
      sorAwardsDrawPie('sor-awards-knights-chart',  a.knights  || [], SOR_AWARDS_KNIGHT_COLORS,  'Knights');
      sorAwardsDrawPie('sor-awards-paragons-chart', a.paragons || [], SOR_AWARDS_PARAGON_COLORS, 'Paragons');
      sorAwardsDrawPie('sor-awards-masters-chart',  a.masters  || [], SOR_AWARDS_MASTER_COLORS,  'Masters');
      sorAwardsRenderKingdomsTable(a.top_kingdoms || []);
    } catch (e) {
      showError('Awards render error: ' + (e && e.message ? e.message : String(e)));
      return;
    }
  };


  // Kingdom multi-select handlers (sorSelectAll / sorClearAll /
  // sorSelectAllExceptFreeholds) live in the standalone <script> block
  // right after the filter card, so they survive errors in this IIFE.

}());
