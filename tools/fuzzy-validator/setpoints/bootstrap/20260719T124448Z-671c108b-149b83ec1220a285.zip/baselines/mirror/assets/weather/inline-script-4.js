
(function() {
	var UIR = 'http://127.0.0.1:19080/orkui/index.php?Route=';
	// Server-computed today in the server's local timezone — use this wherever
	// JS code needs to know "is this date today?". JS's new Date().toISOString()
	// returns UTC and will be off by one for users west of UTC late at night.
	var WX_TODAY = '2026-07-19';
	var wxIcon = function(c) {
		c = +c;
		if (c === 0)                  return '☀️';
		if (c === 1)                  return '🌤️';
		if (c === 2)                  return '⛅';
		if (c === 3)                  return '☁️';
		if (c === 45 || c === 48)     return '🌫️';
		if (c >= 51 && c <= 57)       return '🌦️';
		if (c >= 61 && c <= 67)       return '🌧️';
		if (c >= 71 && c <= 77)       return '❄️';
		if (c >= 80 && c <= 82)       return '🌦️';
		if (c === 85 || c === 86)     return '🌨️';
		if (c >= 95 && c <= 99)       return '⛈️';
		return '🌡️';
	};
	function esc(s) { return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
	function tempPair(f) { var c = Math.round((f - 32) * 5 / 9); return Math.round(f) + '/' + c + '°'; }
	// "(feels 107/41°)" tail when apparent temp diverges by ≥5°F — heat index
	// on hot+humid days, wind chill on cold+windy days. Silent otherwise.
	function feelsTail(f, appF) {
		if (f == null || appF == null) return '';
		if (Math.abs(appF - f) < 5) return '';
		return ' <span class="wx-feels">(feels ' + tempPair(appF) + ')</span>';
	}

	// Kingdom-name shortener mirrors Weather::short_kingdom in PHP
	function shortKingdom(name) {
		if (!name) return '';
		if (/Freeholds/i.test(name)) return '';
		var m = name.match(/^The (.+ Kingdom)$/i);
		if (m) return 'the ' + m[1];
		return name.replace(/^The /i, '').replace(/^(Kingdom|Empire|Principality) of /i, '');
	}

	function rollupKingdoms(map, max) {
		max = max || 5;
		if (!map) return '';
		var arr = Object.keys(map).map(function(k) { return [k, map[k]]; });
		arr.sort(function(a, b) { return b[1] - a[1]; });
		arr = arr.slice(0, max);
		var names = arr.map(function(e) { return shortKingdom(e[0]); }).filter(function(s) { return s; });
		if (names.length === 0) return '';
		if (names.length === 1) return names[0];
		if (names.length === 2) return names[0] + ' and ' + names[1];
		return names.slice(0, -1).join(', ') + ', and ' + names[names.length - 1];
	}

	// JS mirror of $wxKingdomPhrase — see PHP comment.
	function kingdomPhrase(n, map, multiPrefix) {
		if (!map) return '';
		var names = rollupKingdoms(map);
		if (!names) return '';
		var kc = 0;
		for (var k in map) {
			if (Object.prototype.hasOwnProperty.call(map, k) && shortKingdom(k) !== '') kc++;
		}
		if (n === 1 || kc === 1) return ' in ' + names;
		return multiPrefix + names;
	}

	function renderRundown(r, dayLabel) {
		var bc = r.badge_counts || {}, bk = r.badge_kingdoms || {};
		var standout = r.standout_park || null;
		var leadParts = [];
		var noPlay = r.no_play_today;
		var noFlags = Object.keys(bc).length === 0;
		if (noPlay) {
			leadParts.push('No parks have in-person play scheduled for ' + dayLabel + '.');
		} else if (noFlags) {
			leadParts.push('Of the parks playing ' + dayLabel + ', conditions look favorable across the board — no warnings flagged.');
		} else {
			if (bc['Thunderstorms']) {
				var n = bc['Thunderstorms'];
				var suffix = kingdomPhrase(n, bk['Thunderstorms'], ' — primarily in ');
				leadParts.push('Of parks playing ' + dayLabel + ', ' + n + ' ' + (n === 1 ? 'faces' : 'face') + ' thunderstorms' + suffix + '.');
			}
			if (bc['Extreme heat']) {
				var n = bc['Extreme heat'];
				leadParts.push((n === 1 ? 'One park playing ' + dayLabel + ' is' : n + ' parks playing ' + dayLabel + ' are') + ' facing extreme heat.');
			}
			if (bc['Frostbite risk']) {
				var n = bc['Frostbite risk'];
				leadParts.push((n === 1 ? 'One park playing ' + dayLabel + ' is' : n + ' parks playing ' + dayLabel + ' are') + ' under frostbite-risk conditions.');
			}
			if (bc['Severe wind']) {
				var n = bc['Severe wind'];
				var suffix = kingdomPhrase(n, bk['Severe wind'], ', across ');
				leadParts.push('Severe wind gusts (40+ mph / 65+ km/h) at ' + n + ' ' + (n === 1 ? 'park' : 'parks') + ' playing ' + dayLabel + suffix + '.');
			}
			if (bc['Very high UV']) {
				var n = bc['Very high UV'];
				var suffix = kingdomPhrase(n, bk['Very high UV'], ' in ');
				leadParts.push('Very high UV at ' + n + ' ' + (n === 1 ? 'park' : 'parks') + ' playing ' + dayLabel + suffix + '.');
			}
		}

		var standoutLine = '';
		if (standout) {
			var icons = { 'Extreme heat':'🥵', 'Frostbite risk':'🥶', 'Thunderstorms':'⛈️', 'Severe wind':'💨', 'Very high UV':'🌞' };
			var pieces = (standout.flags || []).map(function(f) { return (icons[f] || '⚠️') + ' ' + esc(f); });
			standoutLine = '<a href="' + UIR + 'Park/profile/' + standout.park_id + '" class="wx-jump-park" data-park-id="' + standout.park_id + '" target="_blank" rel="noopener">' + esc(standout.name) + '</a> carries the worst forecast — ' + pieces.join(' · ');
			if (standout.app_hi_f != null) {
				standoutLine += ' (' + tempPair(standout.app_hi_f) + ' apparent).';
			} else {
				standoutLine += '.';
			}
		}

		// Coming-up: ALWAYS today-relative — keep this constant even when pills shift.
		// We don't have the event count in the per-day response (we only computed it
		// for today on initial load), so leave the existing paragraph untouched.

		var html = '';
		if (leadParts.length) html += '<p>' + leadParts.join(' ') + '</p>';
		if (standoutLine)     html += '<p>' + standoutLine + '</p>';
		// "N events in the week ahead" — always relative to "now", shows on
		// every day pill so users see upcoming event concerns regardless of
		// which day they're inspecting.
		if (window.WX_COMING_UP_HTML) {
			html += window.WX_COMING_UP_HTML;
		}
		document.getElementById('wx-rundown-body').innerHTML = html;
	}

	// Severity tier from the highest-severity badge — drives map marker color.
	function rowTier(p) {
		if (!p.forecast || p.forecast.hi_f == null) return 'none';
		if (p.badges && p.badges.length) {
			for (var i = 0; i < p.badges.length; i++) {
				if (p.badges[i].severity === 'warning') return 'warning';
			}
			return 'caution';
		}
		return 'favorable';
	}
	var TIER_COLOR = { warning: '#e53e3e', caution: '#dd6b20', favorable: '#48bb78', none: '#a0aec0' };
	var TIER_ORDER = { warning: 0, caution: 1, favorable: 2, none: 3 };
	function statusText(s) {
		if (s === 'dormant')     return 'no recent activity — weather not tracked';
		if (s === 'no_coords')   return 'park location not set';
		return 'forecast unavailable';
	}

	var wxMap = null, wxTileLayer = null, wxMarkers = [], wxMarkersByPark = {};
	var wxTempMarker = null; // ephemeral marker for event-only venues (no park marker)
	var wxBounds = null;    // last fitted bounds — Esc flies back to this
	var wxZoomedIn = false; // true while user is zoomed into a specific park/event
	var wxOpeningPopup = false; // true in the instant before openPopup fires, so
	                            // popupclose can tell "replaced by another" vs "× clicked"
	var wxFitting = false;  // true during programmatic flyToBounds/fitBounds — suppresses
	                        // the zoomend listener so it doesn't re-show the button
	function setZoomedIn(v) {
		wxZoomedIn = v;
		var btn = document.getElementById('wx-zoom-out');
		if (btn) btn.classList.toggle('visible', !!v);
	}
	function fitWxMap() {
		if (wxMap && wxBounds) {
			wxFitting = true;
			wxMap.flyToBounds(wxBounds, { padding: [30, 30], maxZoom: 9, duration: 0.6 });
			wxMap.once('moveend', function() { wxFitting = false; });
		}
		setZoomedIn(false);
	}
	function isDarkTheme() { return document.documentElement.getAttribute('data-theme') === 'dark'; }
	function wxApplyMapTheme() {
		if (!wxMap) return;
		var url = isDarkTheme()
			? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
			: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png';
		if (wxTileLayer) wxMap.removeLayer(wxTileLayer);
		wxTileLayer = L.tileLayer(url, { maxZoom: 19, subdomains: 'abcd' }).addTo(wxMap);
	}
	function ensureMap() {
		if (wxMap || typeof L === 'undefined') return wxMap;
		wxMap = L.map('wx-map', { zoomControl: true, attributionControl: false }).setView([39.5, -98.35], 4);
		wxApplyMapTheme();
		new MutationObserver(wxApplyMapTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
		onMapReady();
		return wxMap;
	}
	function renderMap(rows, dayLabel) {
		var shortDay = dayLabel === 'today' ? 'Today' : dayLabel.slice(0,1).toUpperCase() + dayLabel.slice(1,3);
		document.getElementById('wx-map-title').textContent = '🗺️ Conditions Map — ' + shortDay;
		if (!ensureMap()) return;
		// Close any open popup and reset zoom state when the user switches dates.
		wxMap.closePopup();
		setZoomedIn(false);
		// Clear old markers
		wxMarkers.forEach(function(m) { wxMap.removeLayer(m); });
		wxMarkers = [];
		wxMarkersByPark = {};
		if (wxTempMarker) { wxMap.removeLayer(wxTempMarker); wxTempMarker = null; }
		// Place worst tiers on top by sorting ascending by TIER_ORDER then adding in order
		// (Leaflet stacks later-added markers above earlier ones)
		var plot = rows.filter(function(p) { return p.lat != null && p.lng != null; })
			.slice()
			.sort(function(a, b) { return TIER_ORDER[rowTier(b)] - TIER_ORDER[rowTier(a)]; });
		var bounds = [];
		plot.forEach(function(p) {
			var tier = rowTier(p);
			var color = TIER_COLOR[tier];
			var marker = L.circleMarker([p.lat, p.lng], {
				radius: tier === 'warning' ? 8 : (tier === 'caution' ? 7 : 6),
				color: color, weight: 1, fillColor: color,
				fillOpacity: tier === 'none' ? 0.4 : 0.8
			}).addTo(wxMap);
			var fc = p.forecast;
			var wxLine = '';
			if (fc && fc.hi_f != null) {
				var loPart = fc.lo_f != null ? ' / L ' + tempPair(fc.lo_f) + feelsTail(fc.lo_f, fc.app_lo_f) : '';
				wxLine = '<div class="wx-pp-wx">' + wxIcon(fc.code) + ' ' + tempPair(fc.hi_f) + feelsTail(fc.hi_f, fc.app_hi_f) + loPart + '</div>';
				wxLine += renderBadgeChips(p.badges);
			} else {
				wxLine = '<div class="wx-pp-meta">' + esc(statusText(p.forecast_status)) + '</div>';
			}
			var k = shortKingdom(p.kingdom_name || '');
			marker.bindPopup(
				'<div class="wx-map-popup">' +
					'<div class="wx-pp-name"><a href="' + UIR + 'Park/profile/' + p.park_id + '" target="_blank" rel="noopener">' + esc(p.park_name) + '</a></div>' +
					(k ? '<div class="wx-pp-meta">' + esc(k) + '</div>' : '') +
					wxLine +
				'</div>'
			);
			var tip = p.park_name;
			if (tier === 'none') tip += ' — ' + statusText(p.forecast_status);
			marker.bindTooltip(tip, { direction: 'top', opacity: 0.9 });
			wxMarkers.push(marker);
			wxMarkersByPark[p.park_id] = marker;
			bounds.push([p.lat, p.lng]);
		});
		if (bounds.length) {
			wxBounds = bounds;
			wxFitting = true;
			wxMap.fitBounds(bounds, { padding: [30, 30], maxZoom: 9 });
			wxMap.once('moveend', function() { wxFitting = false; });
		}
		setTimeout(function() { wxMap.invalidateSize(); }, 50);
	}

	function renderPlay(rows, dayLabel) {
		var shortDay = dayLabel === 'today' ? 'Today' : dayLabel.slice(0,1).toUpperCase() + dayLabel.slice(1,3);
		document.getElementById('wx-play-title').textContent = '🏕️ Play ' + shortDay;
		var body = document.getElementById('wx-play-body');
		if (!rows.length) {
			body.innerHTML = '<div class="wx-empty">No in-person play scheduled.</div>';
			document.getElementById('wx-play-count').textContent = '0 parks';
			ensurePlayToggle(0, 0);
			return;
		}
		var flaggedCount = 0;
		rows.forEach(function(p) { if (p.badges && p.badges.length) flaggedCount++; });
		// Reset the toggle to the default mode for the new day: flagged when
		// any exist, otherwise all. Re-create the button via ensurePlayToggle.
		var existingBtn = document.getElementById('wx-play-toggle');
		if (existingBtn) existingBtn.remove();
		var html = '';
		rows.forEach(function(p, i) {
			var k = shortKingdom(p.kingdom_name || '');
			var fc = p.forecast || null;
			var scheds = (p.schedules || []).map(function(s) {
				var t = '';
				if (s.time) {
					var parts = s.time.split(':');
					var d = new Date(); d.setHours(+parts[0], +parts[1] || 0, 0, 0);
					t = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
				}
				return esc(s.purpose) + (t ? ' at ' + t : '');
			});
			var wx = '';
			if (fc && fc.hi_f != null) {
				var loPart = fc.lo_f != null ? ' · L ' + tempPair(fc.lo_f) + feelsTail(fc.lo_f, fc.app_lo_f) : '';
				wx = '<div class="wx-play-temps">' + wxIcon(fc.code) + ' ' + tempPair(fc.hi_f) + feelsTail(fc.hi_f, fc.app_hi_f) + loPart + '</div>';
				if (p.badges && p.badges.length) {
					wx += '<div class="wx-play-meta">' +
						p.badges.map(function(b) { return '<span class="wx-event-badge wx-event-badge-' + b.severity + '" title="' + esc(b.label) + '"' + wxSafetyAttrs(b.label) + '>' + b.icon + '</span>'; }).join(' ') +
						'</div>';
				}
			} else {
				wx = '<div class="wx-play-empty">' + esc(statusText(p.forecast_status)) + '</div>';
			}
			var coordAttrs = (p.lat != null && p.lng != null)
				? ' data-lat="' + p.lat + '" data-lng="' + p.lng + '"' : '';
			var sev = +p._score || 0;
			var nameAttr = (p.park_name || '').toLowerCase();
			var flag = (p.badges && p.badges.length) ? '1' : '0';
			html += '<div class="wx-play-row" data-park-id="' + p.park_id + '"' +
				' data-park-name="' + esc(nameAttr) + '" data-severity="' + sev + '"' +
				' data-flagged="' + flag + '"' + coordAttrs + '>' +
				'<div class="wx-play-main">' +
					'<div class="wx-play-park"><a href="' + UIR + 'Park/profile/' + p.park_id + '" class="wx-jump" target="_blank" rel="noopener">' + esc(p.park_name) + '</a></div>' +
					'<div class="wx-play-meta">' + scheds.join(' &middot; ') + (k ? ' &middot; ' + esc(k) : '') + '</div>' +
				'</div>' +
				'<div class="wx-play-wx">' + wx + '</div>' +
			'</div>';
		});
		body.innerHTML = html;
		ensurePlayToggle(flaggedCount, rows.length);
		applyPlayState();
	}

	// Label the toggle based on the current mode + whether toggling makes sense.
	// Modes:
	//   "flagged" → show only parks with badges, severity-sorted. Default when
	//               any flagged parks exist.
	//   "all"     → show every park, alphabetical. Default when nothing's flagged.
	// Button only appears when both modes would show different content (i.e.
	// at least one flagged AND at least one unflagged).
	function labelToggle(btn, flaggedCount, total) {
		if (!btn) return;
		var mode = btn.dataset.mode || 'flagged';
		var hasUnflagged = flaggedCount < total;
		if (mode === 'flagged') {
			// Toggle would either reveal unflagged rows OR just re-sort.
			btn.textContent = hasUnflagged ? 'Show all ' + total : 'A–Z';
		} else {
			btn.textContent = hasUnflagged ? 'Show concerns only' : 'By severity';
		}
		btn.classList.toggle('active', mode === 'all');
	}

	function ensurePlayToggle(flaggedCount, total) {
		var controls = document.querySelector('#wx-play .wx-play-controls');
		if (!controls) return;
		var existing = document.getElementById('wx-play-toggle');
		// Hide toggle only when there's nothing flagged — in that case the
		// flagged mode would be empty, so default 'all' (alphabetical) and
		// drop the button.
		if (flaggedCount <= 0) {
			if (existing) existing.remove();
			return;
		}
		if (!existing) {
			existing = document.createElement('button');
			existing.id = 'wx-play-toggle';
			existing.className = 'wx-play-toggle';
			existing.dataset.mode = 'flagged';
			controls.appendChild(existing);
			existing.addEventListener('click', function() {
				existing.dataset.mode = existing.dataset.mode === 'flagged' ? 'all' : 'flagged';
				var rows = document.querySelectorAll('#wx-play-body .wx-play-row');
				var f = 0;
				rows.forEach(function(r) { if (r.dataset.flagged === '1') f++; });
				labelToggle(existing, f, rows.length);
				applyPlayState();
				var body = document.getElementById('wx-play-body');
				if (body) body.scrollTop = 0;
			});
		}
		labelToggle(existing, flaggedCount, total);
	}

	// Single source of truth for play-list visibility/order.
	//   - "flagged" mode (no search): severity-sorted, only data-flagged="1" visible
	//   - "all" mode OR any search: alphabetical, every matching row visible
	function applyPlayState() {
		var body = document.getElementById('wx-play-body');
		if (!body) return;
		var rows = Array.prototype.slice.call(body.querySelectorAll('.wx-play-row'));
		if (!rows.length) return;
		var searchEl = document.getElementById('wx-play-search');
		var query = (searchEl && searchEl.value || '').trim().toLowerCase();
		var toggle = document.getElementById('wx-play-toggle');
		// Default to 'all' when no toggle present (nothing flagged), 'flagged' otherwise.
		var mode = toggle ? toggle.dataset.mode : 'all';
		// Search always shows everything matching, alphabetically — overrides mode.
		var effectiveMode = query ? 'all' : mode;

		rows.sort(function(a, b) {
			if (effectiveMode === 'all') {
				return (a.dataset.parkName || '').localeCompare(b.dataset.parkName || '');
			}
			var ds = (+b.dataset.severity || 0) - (+a.dataset.severity || 0);
			if (ds !== 0) return ds;
			return (a.dataset.parkName || '').localeCompare(b.dataset.parkName || '');
		});
		rows.forEach(function(r) { body.appendChild(r); });

		var flaggedTotal = 0, shown = 0;
		rows.forEach(function(r) {
			if (r.dataset.flagged === '1') flaggedTotal++;
			r.classList.remove('wx-hidden', 'wx-filtered');
			var name = r.dataset.parkName || '';
			var matchesQuery = !query || name.indexOf(query) !== -1;
			if (!matchesQuery) { r.classList.add('wx-filtered'); return; }
			if (effectiveMode === 'flagged' && r.dataset.flagged !== '1') {
				r.classList.add('wx-hidden');
				return;
			}
			shown++;
		});

		// Count: "5 of 162" when filtered, "162 parks" when all, "3 / 162" while searching.
		var countEl = document.getElementById('wx-play-count');
		if (countEl) {
			if (query)                          countEl.textContent = shown + ' / ' + rows.length;
			else if (effectiveMode === 'flagged') countEl.textContent = shown + ' of ' + rows.length;
			else                                countEl.textContent = rows.length + (rows.length === 1 ? ' park' : ' parks');
		}

		// Banner: only visible in flagged mode (not while searching either —
		// search results aren't a "weather concerns" filter).
		var card = document.getElementById('wx-play');
		if (card) card.classList.toggle('is-flagged-mode', effectiveMode === 'flagged');

		// Toggle button: invisible (but space reserved) while searching. The
		// search already shows "all matching parks" regardless of mode, so the
		// button would either be a no-op or set stale state for when the
		// search is cleared. Reserving space prevents header reflow.
		if (toggle) toggle.classList.toggle('wx-invisible', !!query);
	}

	// Filter the events list to only show events that haven't ended before the
	// selected date. Multi-day events remain visible as long as their end date
	// is on or after the selected date.
	function applyEventsFilter(date) {
		var isToday = (date === WX_TODAY);
		var rows = document.querySelectorAll('#upcoming-events .wx-event');
		var shown = 0;
		rows.forEach(function(r) {
			var end = r.dataset.eventEnd || r.dataset.eventStart || '';
			var visible = !end || end >= date;
			r.classList.toggle('wx-hidden', !visible);
			if (visible) shown++;
		});
		var title = document.getElementById('wx-events-title');
		if (title) {
			if (isToday) {
				title.textContent = '📅 Upcoming Events — in the week ahead';
			} else {
				var d = new Date(date + 'T00:00:00');
				var lbl = d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
				title.textContent = '📅 Upcoming Events — from ' + lbl;
			}
		}
		var body = document.querySelector('#upcoming-events .wx-events-body');
		if (body) {
			var emptyEl = body.querySelector('.wx-events-empty-state');
			if (shown === 0 && rows.length > 0) {
				if (!emptyEl) {
					emptyEl = document.createElement('div');
					emptyEl.className = 'wx-empty wx-events-empty-state';
					body.appendChild(emptyEl);
				}
				emptyEl.textContent = 'No events on or after this date.';
			} else if (emptyEl) {
				emptyEl.remove();
			}
		}
	}

	function activatePill(date) {
		document.querySelectorAll('.wx-pill').forEach(function(b) {
			b.classList.toggle('active', b.dataset.date === date);
		});
		document.querySelector('.wx-root').dataset.selectedDate = date;
	}

	function fetchAndRender(date, dayLabel) {
		document.getElementById('wx-play-body').innerHTML = '<div class="wx-loading">Loading…</div>';
		fetch(UIR + 'Weather/day/' + date, { credentials: 'same-origin' })
			.then(function(r) { return r.json(); })
			.then(function(d) {
				if (!d || d.status !== 0) {
					document.getElementById('wx-play-body').innerHTML = '<div class="wx-empty">Could not load weather.</div>';
					return;
				}
				renderRundown(d.rundown || {}, dayLabel);
				renderMap(d.play || [], dayLabel);
				renderPlay(d.play || [], dayLabel);
			})
			.catch(function() {
				document.getElementById('wx-play-body').innerHTML = '<div class="wx-empty">Request failed.</div>';
			});
	}

	document.querySelectorAll('.wx-pill').forEach(function(btn) {
		btn.addEventListener('click', function() {
			var date = this.dataset.date;
			var dayLabel = (date === WX_TODAY) ? 'today' :
				new Date(date + 'T00:00:00').toLocaleDateString([], { weekday: 'long' });
			activatePill(date);
			applyEventsFilter(date);
			fetchAndRender(date, dayLabel);
		});
	});

	// Stash the server-rendered "coming up" paragraph so we can re-insert it
	// when the user comes back to Today after viewing another day.
	(function() {
		var p = document.querySelector('#wx-rundown-body p:last-child');
		if (p && p.querySelector('a[href="#upcoming-events"]')) {
			window.WX_COMING_UP_HTML = p.outerHTML;
		}
	})();

	// Wire the server-rendered header toggle (initial page load — today's data)
	(function() {
		var initialToggle = document.getElementById('wx-play-toggle');
		if (initialToggle) {
			initialToggle.addEventListener('click', function() {
				initialToggle.dataset.mode = initialToggle.dataset.mode === 'flagged' ? 'all' : 'flagged';
				var rows = document.querySelectorAll('#wx-play-body .wx-play-row');
				var f = 0;
				rows.forEach(function(r) { if (r.dataset.flagged === '1') f++; });
				labelToggle(initialToggle, f, rows.length);
				applyPlayState();
				var body = document.getElementById('wx-play-body');
				if (body) body.scrollTop = 0;
			});
		}
		// Search input: debounced filter
		var search = document.getElementById('wx-play-search');
		if (search) {
			var timer = null;
			search.addEventListener('input', function() {
				clearTimeout(timer);
				timer = setTimeout(applyPlayState, 80);
			});
		}
		// Banner "Show all parks" — delegates to the header toggle so a single
		// state owns the mode.
		var modeClear = document.getElementById('wx-play-mode-clear');
		if (modeClear) {
			modeClear.addEventListener('click', function() {
				var t = document.getElementById('wx-play-toggle');
				if (t) t.click();
			});
		}
		// Normalize count text + banner visibility on first paint
		applyPlayState();
		// Apply event date filter for the initially selected date (today on first
		// load, but correct if someone navigates back with a stale pill state).
		applyEventsFilter("2026-07-19");
	})();

	// Esc: close any open popup and fly back to the full-map view.
	document.addEventListener('keydown', function(e) {
		if (e.key !== 'Escape') return;
		if (e.target.closest('input, textarea, [contenteditable]')) return;
		if (wxMap) wxMap.closePopup();
		fitWxMap();
	});

	// "Zoom out" button in the map header — same as Esc.
	document.getElementById('wx-zoom-out').addEventListener('click', function() {
		if (wxMap) wxMap.closePopup();
		fitWxMap();
	});

	// Closing a popup via its × button also zooms back out (only when we
	// triggered the zoom — wxZoomedIn tracks this).
	function onMapReady() {
		// Clear the flag once the new popup is actually open.
		wxMap.on('popupopen', function() { wxOpeningPopup = false; });
		// Only zoom out when the popup was closed by the user (× or Esc), not
		// when it was replaced by another popup (wxOpeningPopup is true then).
		wxMap.on('popupclose', function() {
			if (wxZoomedIn && !wxOpeningPopup) fitWxMap();
		});
		// Show the "zoom out" button whenever the user manually zooms or pans.
		// wxFitting suppresses this during our own programmatic flyToBounds calls.
		wxMap.on('zoomend dragend', function() {
			if (!wxFitting && wxBounds) setZoomedIn(true);
		});
	}

	// Make Leaflet recompute size after the flex layout settles, and on resize.
	window.addEventListener('resize', function() {
		if (wxMap) wxMap.invalidateSize();
	});

	// Render badges as the same colored chips used in the list rows — same
	// emoji, label visible (since the popup has room), severity-tinted background.
	function renderBadgeChips(badges) {
		if (!badges || !badges.length) return '';
		return '<div class="wx-pp-badges">' + badges.map(function(b) {
			return '<span class="wx-event-badge wx-event-badge-' + b.severity + '"' + wxSafetyAttrs(b.label) + '>' + b.icon + ' ' + esc(b.label) + wxSafetyIconHtml(b.label) + '</span>';
		}).join('') + '</div>';
	}

	// Build the same popup body the map markers use, for an event jumped to
	// without a corresponding park marker. Same .wx-map-popup classes →
	// matches the styling, dark-mode rules, etc.
	function buildEventPopup(ev) {
		var fc = ev.forecast;
		var wxLine = '';
		if (fc && fc.hi_f != null) {
			var loPart = fc.lo_f != null ? ' / L ' + tempPair(fc.lo_f) : '';
			wxLine = '<div class="wx-pp-wx">' + wxIcon(fc.code) + ' ' + tempPair(fc.hi_f) + loPart + '</div>';
			wxLine += renderBadgeChips(ev.badges);
		} else {
			wxLine = '<div class="wx-pp-meta">forecast unavailable</div>';
		}
		var parts = [];
		if (ev.park_id && ev.park_name) {
			parts.push('<a href="' + UIR + 'Park/profile/' + ev.park_id + '" target="_blank" rel="noopener">' + esc(ev.park_name) + '</a>');
		}
		var k = shortKingdom(ev.kingdom_name || '');
		if (k) parts.push(esc(k));
		var locLine = parts.length ? '<div class="wx-pp-meta">' + parts.join(' · ') + '</div>' : '';
		var dateLine = '';
		var startStr = ev.event_start ? ev.event_start.slice(0, 10) : '';
		var endStr   = ev.event_end   ? ev.event_end.slice(0, 10)   : startStr;
		if (startStr) {
			var dtS = new Date(startStr + 'T00:00:00');
			if (!isNaN(dtS)) {
				var startLabel = dtS.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
				if (endStr && endStr > startStr) {
					var dtE = new Date(endStr + 'T00:00:00');
					var endLabel = !isNaN(dtE) ? dtE.toLocaleDateString([], { month: 'short', day: 'numeric' }) : '';
					dateLine = '<div class="wx-pp-meta">' + esc(startLabel) + (endLabel ? ' – ' + esc(endLabel) : '') + '</div>';
				} else {
					dateLine = '<div class="wx-pp-meta">' + esc(startLabel) + '</div>';
				}
			}
		}
		return '<div class="wx-map-popup">' +
			'<div class="wx-pp-name"><a href="' + UIR + 'Event/detail/' + ev.event_id + '/' + ev.event_calendardetail_id + '" target="_blank" rel="noopener">' + esc(ev.name) + '</a></div>' +
			dateLine + locLine + wxLine +
		'</div>';
	}

	// Map-jump: clicking a park/event row (or its link) zooms the map instead
	// of navigating away. Modifier-key clicks still follow the link so users
	// can open the profile in a new tab if they want.
	function flyToPark(parkId) {
		var pid = parseInt(parkId, 10);
		var marker = pid ? wxMarkersByPark[pid] : null;
		if (!marker || !wxMap) return false;
		var ll = marker.getLatLng();
		wxMap.flyTo([ll.lat, ll.lng], Math.max(wxMap.getZoom(), 9), { duration: 0.6 });
		setZoomedIn(true);
		setTimeout(function() { wxOpeningPopup = true; marker.openPopup(); }, 650);
		return true;
	}

	function flyToEvent(ev) {
		if (!wxMap || !ev) return false;
		// Anchor the event popup to the host park's marker when that park is
		// playing today (no duplicate pin), otherwise drop a blue marker at
		// the event's own coords (cd.lat/lng or at_park).
		var hostMarker = ev.park_id ? wxMarkersByPark[ev.park_id] : null;
		var ll;
		if (hostMarker) {
			var p = hostMarker.getLatLng();
			ll = [p.lat, p.lng];
		} else if (ev.lat != null && ev.lng != null) {
			ll = [+ev.lat, +ev.lng];
		} else {
			return false;
		}
		wxMap.flyTo(ll, Math.max(wxMap.getZoom(), 9), { duration: 0.6 });
		setZoomedIn(true);
		if (wxTempMarker) { wxMap.removeLayer(wxTempMarker); wxTempMarker = null; }
		var popup = L.popup({ offset: hostMarker ? [0, -8] : [0, 0] })
			.setLatLng(ll)
			.setContent(buildEventPopup(ev));
		if (!hostMarker) {
			// Visual anchor for event-only venues
			wxTempMarker = L.circleMarker(ll, {
				radius: 9, color: '#3182ce', weight: 2, fillColor: '#3182ce', fillOpacity: 0.6
			}).addTo(wxMap);
		}
		setTimeout(function() { wxOpeningPopup = true; popup.openOn(wxMap); }, 650);
		return true;
	}

	function jumpClickHandler(e) {
		// Let modifier-clicks fall through (open in new tab etc.)
		if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;

		// Rundown park link (top-of-page summary)
		var jumpLink = e.target.closest('.wx-jump-park');
		if (jumpLink && jumpLink.dataset.parkId) {
			if (flyToPark(jumpLink.dataset.parkId)) {
				e.preventDefault();
				e.stopPropagation();
			}
			return;
		}

		var row = e.target.closest('.wx-play-row, .wx-event');
		if (!row || !row.closest('.wx-root')) return;
		var handled = false;
		if (row.classList.contains('wx-event')) {
			var cd = parseInt(row.dataset.eventCdId || '0', 10);
			var ev = cd && window.WX_EVENTS ? window.WX_EVENTS[cd] : null;
			if (ev) handled = flyToEvent(ev);
		} else {
			handled = flyToPark(row.dataset.parkId);
		}
		if (handled) {
			e.preventDefault();
			e.stopPropagation();
			var mapEl = document.getElementById('wx-map');
			if (mapEl) {
				var r = mapEl.getBoundingClientRect();
				if (r.top < 0 || r.bottom > window.innerHeight) {
					mapEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
				}
			}
		}
	}
	document.querySelector('.wx-root').addEventListener('click', jumpClickHandler);

	// Render the map for the initial date using the server-supplied play list
	function whenLeafletReady(cb) {
		if (typeof L !== 'undefined') return cb();
		var s = document.querySelector('script[src*="leaflet.js"]');
		if (s) s.addEventListener('load', cb);
		else window.addEventListener('load', cb);
	}
	// Events stay the same across date pills (always next-7-days from now), so
	// dump them once for the click→map-popup flow. Keep as an array (avoids
	// JSON_FORCE_OBJECT recursing into badges) and build the cd_id lookup in JS.
	(function() {
		var rows = [{"event_id":100,"event_calendardetail_id":8010,"name":"Summer Coronation","park_id":7,"park_name":"Granite Spyre","kingdom_name":"The Kingdom of the Wetlands","event_start":"2026-07-19 12:00:00","event_end":"2026-07-19 17:00:00","lat":29.7509283,"lng":-95.6270666,"forecast":null,"badges":[]},{"event_id":16,"event_calendardetail_id":7931,"name":"Summer Coronation","park_id":1,"park_name":"Mordengaard","kingdom_name":"The Kingdom of the Wetlands","event_start":"2026-07-25 11:00:00","event_end":"2026-07-25 16:00:00","lat":30.6109817,"lng":-96.2940354,"forecast":null,"badges":[]}];
		window.WX_EVENTS = {};
		rows.forEach(function(r) { window.WX_EVENTS[r.event_calendardetail_id] = r; });
	})();

	whenLeafletReady(function() {
		var initialPlay = [{"park_id":676,"park_name":"Adari Vaal Keep","kingdom_name":"The Empire of Rivermoor","lat":37.7944806,"lng":-93.5779815,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":441,"park_name":"Aegir's Hall","kingdom_name":"The Kingdom of Westmarch","lat":38.1341477,"lng":-121.2722194,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":551,"park_name":"Aether Glade","kingdom_name":"The Kingdom of the Emerald Hills","lat":35.0916939,"lng":-92.4576137,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1077,"park_name":"Angels' Dusk","kingdom_name":"The Freeholds of Amtgard","lat":34.0754453,"lng":-118.3542672,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1061,"park_name":"Anselheim","kingdom_name":"The Freeholds of Amtgard","lat":35.1247668,"lng":-78.9002757,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1023,"park_name":"Ardent Spire","kingdom_name":"13 Roads","lat":40.1014765,"lng":-88.2502024,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":160,"park_name":"Ashen Hills","kingdom_name":"The Kingdom of the Rising Winds","lat":42.7137093,"lng":-84.4325086,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1114,"park_name":"Avalon","kingdom_name":"The Freeholds of Amtgard","lat":31.3090253,"lng":-94.7342236,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":295,"park_name":"Bandit Flats East","kingdom_name":"The Kingdom of Crystal Groves","lat":39.1225035,"lng":-75.5354228,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":609,"park_name":"Bellhollow","kingdom_name":"The Kingdom of the Nine Blades","lat":43.1371382,"lng":-80.2809574,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":103,"park_name":"Bifost","kingdom_name":"The Celestial Kingdom","lat":30.0062451,"lng":-99.1105684,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":670,"park_name":"Biting Winds","kingdom_name":"The Kingdom of Goldenvale","lat":41.4250948,"lng":-72.8376389,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1035,"park_name":"Black Cat's Luck","kingdom_name":"The Kingdom of Tal Dagore","lat":40.2024674,"lng":-92.5746393,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":422,"park_name":"Black Marsh","kingdom_name":"The Kingdom of the Rising Winds","lat":40.0589829,"lng":-86.4686914,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":49,"park_name":"Blackfire Pass","kingdom_name":"The Kingdom of the Rising Winds","lat":40.0195695,"lng":-83.093173,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":178,"park_name":"Blackfire Valley","kingdom_name":"The Kingdom of the Rising Winds","lat":38.4089424,"lng":-82.4369095,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":638,"park_name":"Blackthorne","kingdom_name":"The Kingdom of Crystal Groves","lat":40.095341,"lng":-76.3983882,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":872,"park_name":"Boarhaven","kingdom_name":"The Kingdom of Westmarch","lat":36.2127439,"lng":-121.1260287,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":947,"park_name":"Bright River","kingdom_name":"The Freeholds of Amtgard","lat":41.6230622,"lng":-83.7045155,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":860,"park_name":"Brutes Bay","kingdom_name":"The Kingdom of Goldenvale","lat":42.3076763,"lng":-71.0461426,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":962,"park_name":"Burning Shores","kingdom_name":"The Kingdom of the Rising Winds","lat":41.5800124,"lng":-81.4192918,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":220,"park_name":"Cloud's Edge","kingdom_name":"The Kingdom of Dragonspine","lat":32.778281,"lng":-108.2759136,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":852,"park_name":"Crescent Valley","kingdom_name":"The Kingdom of Polaris","lat":45.1285359,"lng":-95.0306947,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":383,"park_name":"Crimson Plains","kingdom_name":"The Empire of Rivermoor","lat":46.4038112,"lng":-105.8543314,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1115,"park_name":"Crimson Shore","kingdom_name":"The Freeholds of Amtgard","lat":34.2703607,"lng":-119.2363047,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":880,"park_name":"Dark Lodge Crossing","kingdom_name":"The Kingdom of Northreach","lat":58.3327588,"lng":-134.4736919,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":61,"park_name":"Dark Oasis","kingdom_name":"The Kingdom of Burning Lands","lat":32.748746,"lng":-103.1441757,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":139,"park_name":"Darkwater (FL)","kingdom_name":"The Kingdom of Neverwinter","lat":29.6158369,"lng":-82.418611,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1069,"park_name":"Deo's Vault","kingdom_name":"The Kingdom of Tal Dagore","lat":39.397715,"lng":-92.4215939,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":104,"park_name":"Dragon Skull Keep","kingdom_name":"The Celestial Kingdom","lat":33.2385208,"lng":-97.154795,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":561,"park_name":"Dragon's Hollow","kingdom_name":"The Kingdom of Winters Edge","lat":36.5044471,"lng":-87.2745039,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":779,"park_name":"Dragonrest","kingdom_name":"The Kingdom of Goldenvale","lat":42.6068744,"lng":-76.1862757,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":696,"park_name":"Dragons Creek","kingdom_name":"The Kingdom of Viridian Outlands","lat":48.5386313,"lng":-117.9011515,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":930,"park_name":"Dragons Crossing","kingdom_name":"The Kingdom of Neverwinter","lat":30.8468487,"lng":-83.2852276,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":180,"park_name":"Dragons Forge","kingdom_name":"The Kingdom of Blackspire","lat":45.3711269,"lng":-122.603302,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":36,"park_name":"Dragonspyre","kingdom_name":"Kingdom of the Desert Winds","lat":37.681494,"lng":-113.063001,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1108,"park_name":"Drowned Vale","kingdom_name":"The Freeholds of Amtgard","lat":31.0380334,"lng":-83.0720212,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":808,"park_name":"Dusk Hollow","kingdom_name":"The Kingdom of Blackspire","lat":44.926773,"lng":-123.3224072,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1056,"park_name":"Edgewater Keep","kingdom_name":"The Kingdom of Crystal Groves","lat":40.6884592,"lng":-75.2468957,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":847,"park_name":"Eldamar","kingdom_name":"The Kingdom of Goldenvale","lat":42.898954,"lng":-73.8182425,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":985,"park_name":"Elk Glenn","kingdom_name":"The Kingdom of the Rising Winds","lat":41.6636549,"lng":-86.1177247,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":630,"park_name":"Emerald Cove","kingdom_name":"The Kingdom of Neverwinter","lat":31.840705,"lng":-81.593692,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":549,"park_name":"Emerald Winds","kingdom_name":"The Kingdom of Winters Edge","lat":34.7248321,"lng":-86.5745047,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":347,"park_name":"Empire's Grove","kingdom_name":"The Kingdom of Goldenvale","lat":40.7825355,"lng":-73.9693882,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":512,"park_name":"Ethereal Tides","kingdom_name":"The Kingdom of Polaris","lat":44.0779854,"lng":-92.475974,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1011,"park_name":"Everlyn","kingdom_name":"The Empire of Rivermoor","lat":39.6645594,"lng":-95.5197138,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":192,"park_name":"Fal Dare","kingdom_name":"The Kingdom of Westmarch","lat":39.5363603,"lng":-119.7313833,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":165,"park_name":"Falcon Tor","kingdom_name":"The Kingdom of Tal Dagore","lat":38.9517053,"lng":-92.3340724,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":75,"park_name":"Falling Fire","kingdom_name":"The Kingdom of Neverwinter","lat":27.9158486,"lng":-82.2773466,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":277,"park_name":"Felfrost","kingdom_name":"The Kingdom of the Nine Blades","lat":45.3336382,"lng":-75.6770452,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":146,"park_name":"Five Oaks","kingdom_name":"The Kingdom of the Rising Winds","lat":37.7201242,"lng":-85.8742646,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":699,"park_name":"Fool's Demise","kingdom_name":"The Kingdom of the Wetlands","lat":30.2280912,"lng":-94.2315115,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":673,"park_name":"Forest of Fado","kingdom_name":"The Kingdom of Blackspire","lat":44.6365107,"lng":-123.1059282,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":818,"park_name":"Forsaken Asylum","kingdom_name":"13 Roads","lat":42.2966861,"lng":-89.6212271,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":493,"park_name":"Frozen Coast","kingdom_name":"The Kingdom of Northreach","lat":60.4834225,"lng":-151.0626157,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":895,"park_name":"Gaea's Grove","kingdom_name":"The Kingdom of Tal Dagore","lat":37.8402426,"lng":-90.4956649,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":768,"park_name":"Gators Bight","kingdom_name":"The Kingdom of the Wetlands","lat":31.3468584,"lng":-92.4449363,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":692,"park_name":"Glass Fjord Highlands","kingdom_name":"The Kingdom of Dragonspine","lat":34.5903607,"lng":-112.3155307,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":665,"park_name":"Glittering Vale","kingdom_name":"Kingdom of the Desert Winds","lat":43.6237704,"lng":-116.3464798,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":970,"park_name":"Goblins Hole","kingdom_name":"The Celestial Kingdom","lat":31.4329745,"lng":-97.7452933,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1093,"park_name":"Grandes Fourches","kingdom_name":"The Freeholds of Amtgard","lat":45.414597,"lng":-71.888699,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":7,"park_name":"Granite Spyre","kingdom_name":"The Kingdom of the Wetlands","lat":29.7505044,"lng":-95.6253563,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":76,"park_name":"Greenwood Keep","kingdom_name":"The Kingdom of Northern Lights","lat":47.0214396,"lng":-122.8163948,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":944,"park_name":"Griffin's Heart","kingdom_name":"13 Roads","lat":40.1253836,"lng":-87.6419284,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":101,"park_name":"Griffons Keep","kingdom_name":"The Celestial Kingdom","lat":28.8221748,"lng":-97.0157891,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":714,"park_name":"Grim Garrison","kingdom_name":"The Kingdom of the Rising Winds","lat":37.9842776,"lng":-84.4258293,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":127,"park_name":"Gryphon's Perch","kingdom_name":"The Kingdom of the Rising Winds","lat":39.759042,"lng":-85.963343,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":974,"park_name":"Gryphon's Rest","kingdom_name":"The Freeholds of Amtgard","lat":61.5854988,"lng":-144.4447066,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1102,"park_name":"Harpy Hallow","kingdom_name":"The Freeholds of Amtgard","lat":42.7622261,"lng":-71.0441104,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":857,"park_name":"Haven Hills","kingdom_name":"13 Roads","lat":41.3187786,"lng":-88.7051593,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":901,"park_name":"Heathen's Cove","kingdom_name":"The Kingdom of the Nine Blades","lat":44.2248407,"lng":-76.4904006,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":515,"park_name":"Helheim","kingdom_name":"The Principality of the Crimson Sands","lat":33.298295,"lng":-111.808142,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":555,"park_name":"Hellig Brann","kingdom_name":"The Freeholds of Amtgard","lat":47.9583223,"lng":-117.4825347,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":552,"park_name":"Hermits Hold","kingdom_name":"The Kingdom of Viridian Outlands","lat":47.4220938,"lng":-120.3258451,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":450,"park_name":"Hippos Pond","kingdom_name":"The Celestial Kingdom","lat":30.6525445,"lng":-97.6688139,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":511,"park_name":"Hollow Mountain","kingdom_name":"The Kingdom of Tal Dagore","lat":38.5427032,"lng":-90.9842036,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1070,"park_name":"Hunters Point","kingdom_name":"The Kingdom of Winters Edge","lat":33.8794456,"lng":-84.8324971,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":58,"park_name":"Irongate","kingdom_name":"The Kingdom of the Golden Plains","lat":33.5551856,"lng":-101.8696729,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1020,"park_name":"Ironheade Hills","kingdom_name":"The Kingdom of Blackspire","lat":42.3255371,"lng":-122.8403196,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":8,"park_name":"Ironwood","kingdom_name":"The Kingdom of the Wetlands","lat":30.2897003,"lng":-95.4145526,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":898,"park_name":"Jade Hill","kingdom_name":"The Kingdom of Polaris","lat":42.3721949,"lng":-87.9120123,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":274,"park_name":"King's Point","kingdom_name":"The Kingdom of the Emerald Hills","lat":32.8594272,"lng":-97.1715984,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":865,"park_name":"Kirin Grove","kingdom_name":"The Kingdom of the Rising Winds","lat":38.4735243,"lng":-82.6382155,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":624,"park_name":"Knight's Rest","kingdom_name":"The Kingdom of Tal Dagore","lat":38.5056051,"lng":-90.2893845,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":216,"park_name":"Knoblands","kingdom_name":"The Kingdom of Tal Dagore","lat":37.1903779,"lng":-93.2832856,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":519,"park_name":"Leviathan Keep","kingdom_name":"The Kingdom of Crystal Groves","lat":37.071613,"lng":-76.331417,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1060,"park_name":"Leviathan's Run","kingdom_name":"The Kingdom of Winters Edge","lat":32.81687,"lng":-80.0000216,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":615,"park_name":"Lichwood Grove","kingdom_name":"The Kingdom of the Nine Blades","lat":43.4654532,"lng":-80.5360471,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1043,"park_name":"Lost Cove","kingdom_name":"The Kingdom of Northern Lights","lat":49.3234871,"lng":-124.3090451,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":912,"park_name":"Lost Winds","kingdom_name":"13 Roads","lat":40.4695442,"lng":-89.0052723,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1048,"park_name":"Maple Grove","kingdom_name":"The Freeholds of Amtgard","lat":41.824037,"lng":-86.3691656,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":124,"park_name":"Mithril Hills","kingdom_name":"The Kingdom of Northern Lights","lat":46.1394375,"lng":-122.8899375,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":606,"park_name":"Mountain of the Sixth Dawn","kingdom_name":"The Kingdom of the Rising Winds","lat":38.3727649,"lng":-81.7458845,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":882,"park_name":"Murk Bottom","kingdom_name":"The Kingdom of Neverwinter","lat":30.4585858,"lng":-84.3219912,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":97,"park_name":"Murky Waters","kingdom_name":"The Celestial Kingdom","lat":31.0601171,"lng":-97.6764602,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":60,"park_name":"Nine Willows","kingdom_name":"The Kingdom of the Golden Plains","lat":31.9915875,"lng":-102.092132,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":918,"park_name":"Northern Fields","kingdom_name":"The Empire of Rivermoor","lat":49.87871,"lng":-97.12433,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":846,"park_name":"Northern Grove","kingdom_name":"The Kingdom of Viridian Outlands","lat":53.9084279,"lng":-122.7365855,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":364,"park_name":"Obsidian Gate","kingdom_name":"The Kingdom of Dragonspine","lat":32.2121202,"lng":-110.9254538,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":432,"park_name":"Obsidian Grove","kingdom_name":"The Kingdom of Blackspire","lat":45.661873,"lng":-122.572582,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1112,"park_name":"Orchard Valley","kingdom_name":"The Freeholds of Amtgard","lat":49.884666,"lng":-119.4593733,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":704,"park_name":"Order of the Lost Crossfire","kingdom_name":"13 Roads","lat":41.1454018,"lng":-87.8781733,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1053,"park_name":"Phoenix Hollow","kingdom_name":"The Kingdom of Crystal Groves","lat":39.6179562,"lng":-77.7358418,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":370,"park_name":"Phoenix Summit","kingdom_name":"The Kingdom of Polaris","lat":44.8997917,"lng":-91.9164977,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":70,"park_name":"Phoenix Tears","kingdom_name":"13 Roads","lat":39.8278093,"lng":-89.6522267,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":556,"park_name":"Queens Landing","kingdom_name":"The Empire of Rivermoor","lat":39.1494929,"lng":-94.5684064,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":817,"park_name":"Quixotic Valley","kingdom_name":"The Kingdom of Westmarch","lat":35.1355388,"lng":-118.4778881,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":541,"park_name":"Radiant Valley","kingdom_name":"The Kingdom of Winters Edge","lat":35.9283893,"lng":-84.0458121,"forecast":null,"forecast_status":"unavailable","badges":[]},{"park_id":353,"park_name":"Ragnovik","kingdom_name":"The Kingdom of Neverwinter","lat":29.9933385,"lng":-81.6972507,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":531,"park_name":"Raven's Hollow","kingdom_name":"The Kingdom of the Rising Winds","lat":38.6860401,"lng":-87.5031014,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":771,"park_name":"Raven's Roost","kingdom_name":"The Freeholds of Amtgard","lat":39.2757232,"lng":-121.6599701,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":669,"park_name":"Ravens Cross","kingdom_name":"The Kingdom of the Golden Plains","lat":35.1856176,"lng":-101.8471198,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":605,"park_name":"Ravenstone","kingdom_name":"The Kingdom of Northreach","lat":61.5997222,"lng":-149.1127778,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":435,"park_name":"Rising Sun Station","kingdom_name":"The Kingdom of Crystal Groves","lat":38.9751015,"lng":-77.3374677,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":711,"park_name":"Rivervale Forest","kingdom_name":"The Freeholds of Amtgard","lat":36.7548865,"lng":-95.9163412,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":790,"park_name":"Roaring Plains","kingdom_name":"The Kingdom of Winters Edge","lat":32.5839851,"lng":-85.475585,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":125,"park_name":"Satyr's Crossing","kingdom_name":"The Kingdom of the Rising Winds","lat":40.8811413,"lng":-85.5105277,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1089,"park_name":"Scarlet Ruins","kingdom_name":"The Kingdom of the Emerald Hills","lat":36.0652041,"lng":-90.4900511,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1006,"park_name":"Seaside Keep","kingdom_name":"The Kingdom of Northern Lights","lat":49.2296875,"lng":-123.0196875,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1044,"park_name":"Shade Ashberry","kingdom_name":"The Freeholds of Amtgard","lat":35.9747951,"lng":-94.3146198,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":554,"park_name":"ShadowForge","kingdom_name":"The Kingdom of Winters Edge","lat":36.1641537,"lng":-85.5034442,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":708,"park_name":"Shadowcrest","kingdom_name":"The Kingdom of Neverwinter","lat":31.8696309,"lng":-82.5943026,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":656,"park_name":"Shifting Tides","kingdom_name":"The Kingdom of Neverwinter","lat":25.6943844,"lng":-80.3789098,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1100,"park_name":"Silver Hills","kingdom_name":"The Empire of the Iron Mountains","lat":40.6270531,"lng":-103.2439845,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":709,"park_name":"Silver Riders","kingdom_name":"The Empire of Rivermoor","lat":40.9003799,"lng":-98.3615585,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":514,"park_name":"Skywatch","kingdom_name":"The Kingdom of the Golden Plains","lat":32.4387994,"lng":-99.6942705,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":550,"park_name":"Souls' Crossing","kingdom_name":"The Kingdom of Winters Edge","lat":35.1471133,"lng":-89.9829894,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1118,"park_name":"Specter's Gate","kingdom_name":"The Kingdom of Blackspire","lat":45.1985662,"lng":-123.2163123,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":161,"park_name":"Storm Bridge","kingdom_name":"The Kingdom of the Rising Winds","lat":38.2706196,"lng":-85.741527,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":557,"park_name":"Storm Grove","kingdom_name":"The Kingdom of the Emerald Hills","lat":35.3579352,"lng":-94.3617179,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":589,"park_name":"Stormsurge","kingdom_name":"The Celestial Kingdom","lat":27.8345171,"lng":-97.5551915,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":26,"park_name":"Sun Fall Abbey","kingdom_name":"The Kingdom of the Wetlands","lat":31.6150643,"lng":-94.6440664,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":707,"park_name":"Sylvan Glade","kingdom_name":"The Kingdom of Winters Edge","lat":33.4583779,"lng":-82.0124429,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":198,"park_name":"Syrindale","kingdom_name":"The Kingdom of Goldenvale","lat":43.153263,"lng":-77.527871,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":796,"park_name":"Tanaka's Gift","kingdom_name":"The Kingdom of Polaris","lat":43.0934245,"lng":-87.9028578,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":436,"park_name":"Terra De Votum","kingdom_name":"The Principality of the Crimson Sands","lat":36.067802,"lng":-115.114121,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":343,"park_name":"The Hollow","kingdom_name":"The Kingdom of Northern Lights","lat":47.8780109,"lng":-122.2235935,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":655,"park_name":"The Mire","kingdom_name":"The Kingdom of the Rising Winds","lat":37.9943957,"lng":-87.5637913,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":31,"park_name":"The Northern Holdfast","kingdom_name":"The Empire of the Iron Mountains","lat":40.5820283,"lng":-105.1018799,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":37,"park_name":"The River's End","kingdom_name":"Kingdom of the Desert Winds","lat":40.703252,"lng":-112.020013,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":973,"park_name":"The Roost","kingdom_name":"The Kingdom of the Emerald Hills","lat":33.2148283,"lng":-96.7592692,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":236,"park_name":"Thor's Refuge","kingdom_name":"The Kingdom of Westmarch","lat":38.6294874,"lng":-121.3302609,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1088,"park_name":"Thorbjorn","kingdom_name":"The Freeholds of Amtgard","lat":35.9196027,"lng":-77.5665331,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1018,"park_name":"Thunder Forge","kingdom_name":"The Kingdom of the Emerald Hills","lat":34.6189892,"lng":-98.3923829,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":105,"park_name":"Traitors Gate","kingdom_name":"The Celestial Kingdom","lat":29.5609334,"lng":-98.4456968,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":444,"park_name":"Two Rivers Point","kingdom_name":"The Kingdom of Goldenvale","lat":42.0989995,"lng":-75.9339855,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":210,"park_name":"Valley of the Twin Rivers","kingdom_name":"The Kingdom of the Rising Winds","lat":39.786326,"lng":-84.00914,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":84,"park_name":"Wavehaven","kingdom_name":"The Kingdom of Westmarch","lat":36.9742657,"lng":-122.0549798,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":596,"park_name":"White Oak","kingdom_name":"The Kingdom of Winters Edge","lat":34.1685855,"lng":-84.4583302,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":594,"park_name":"Wickerwood","kingdom_name":"The Celestial Kingdom","lat":26.2510993,"lng":-98.2257411,"forecast":null,"forecast_status":"unavailable","badges":[]},{"park_id":917,"park_name":"Windhaven","kingdom_name":"The Kingdom of Crystal Groves","lat":39.1747236,"lng":-78.1547773,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1091,"park_name":"Wizards Peak","kingdom_name":"The Freeholds of Amtgard","lat":39.2238347,"lng":-106.0020529,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":505,"park_name":"Wolfheim","kingdom_name":"The Kingdom of Polaris","lat":43.1737545,"lng":-89.2350347,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":1092,"park_name":"Wolfs Point","kingdom_name":"The Freeholds of Amtgard","lat":44.5216004,"lng":-89.5397381,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":856,"park_name":"Wolfsbane","kingdom_name":"The Kingdom of the Wetlands","lat":32.5486265,"lng":-92.1653247,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":963,"park_name":"Wolf\u2019s Run","kingdom_name":"The Kingdom of Winters Edge","lat":35.972659,"lng":-86.504076,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":695,"park_name":"Wyvern's Keep","kingdom_name":"The Kingdom of the Wetlands","lat":32.521184,"lng":-94.7897922,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":921,"park_name":"Wyvern's Landing","kingdom_name":"The Kingdom of the Emerald Hills","lat":36.3725114,"lng":-94.3114052,"forecast":null,"forecast_status":"dormant","badges":[]},{"park_id":132,"park_name":"Wyvern's Spur","kingdom_name":"The Kingdom of Westmarch","lat":37.9159112,"lng":-122.3447113,"forecast":null,"forecast_status":"dormant","badges":[]}];
		renderMap(initialPlay, 'today');
	});
})();
